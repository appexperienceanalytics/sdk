//
//  CAMobileWKAnalytics.h
//  CAMobileWKAnalytics
//
//  Created by Suman Cherukuri on 8/2/15.
//  Copyright (c) 2015 CA Technologies. All rights reserved.
//
#ifndef CAMobileWKAnalytics_h
#define CAMobileWKAnalytics_h

#import <Foundation/Foundation.h>

@interface CAMobileWKAnalytics : NSObject

//Use the following constants to send MAA events

extern NSString *const CAMAA_WKIC_BUTTON_PRESSED;
// [CAMobileWKAnalytics sendMAAEvent:CAMAA_WKIC_BUTTON_PRESSED withValue:@"button name"];

extern NSString *const CAMAA_WKIC_SLIDER_ACTION;
// [CAMobileWKAnalytics sendMAAEvent:CAMAA_WKIC_SLIDER_ACTION withFloatValue:value];

extern NSString *const CAMAA_WKIC_SWITCH_ACTION;
// [CAMobileWKAnalytics sendMAAEvent:CAMAA_WKIC_SWITCH_ACTION withBoolValue:value];

//Call the following methods to send events to MAA Collector
+ (BOOL) sendMAAEvent:(NSString *) eventName withValue: (NSString *) value;
+ (BOOL) sendMAAEvent:(NSString *) eventName withFloatValue: (float) value;
+ (BOOL) sendMAAEvent:(NSString *) eventName withBoolValue: (BOOL) value;
+ (BOOL) sendMAAEvent:(NSString *) eventName withValue:(NSString *) value attribs:(NSDictionary *) dictionary;

@end

#endif /* CAMobileWKAnalytics_h */
