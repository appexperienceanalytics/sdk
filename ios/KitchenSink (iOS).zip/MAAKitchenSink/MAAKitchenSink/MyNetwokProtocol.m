//
//  MyNetwokProtocol.m
//  CAMSMDemo
//
//  Created by Nilesh on 3/27/15.
//  Copyright (c) 2015 CA Technologies, Inc. All rights reserved.
//

#import "MyNetwokProtocol.h"

@implementation MyNetwokProtocol

- (id)initWithDelegate:(id<MyNetworkProtocolDelegate>)delegate
{
    self = [super init];

    if (self) {
        _delegate = delegate;
    }

    return self;
}

- (void)performRequest:(NSURLRequest *)request onQueue:(NSOperationQueue *)queue
{
    [NSException raise:@"not implemented" format:nil];
}


//- (BOOL)connection:(NSURLConnection *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)protectionSpace {
//    return [protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust];
//}




- (BOOL)connection:(NSURLConnection *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)space {
    if([[space authenticationMethod] isEqualToString:NSURLAuthenticationMethodServerTrust]) {
        if(YES) {
            return YES; // Self-signed cert will be accepted
        } else {
            return NO;  // Self-signed cert will be rejected
        }
        // Note: it doesn't seem to matter what you return for a proper SSL cert
        //       only self-signed certs
    }
    // If no other authentication is required, return NO for everything else
    // Otherwise maybe YES for NSURLAuthenticationMethodDefault and etc.
    return NO;
}



@end
