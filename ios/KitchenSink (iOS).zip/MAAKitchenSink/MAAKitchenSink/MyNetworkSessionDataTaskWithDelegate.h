//
//  MyNetworkSessionDataTaskWithDelegate.h
//  CAMSMDemo
//
//  Created by Nilesh on 3/27/15.
//  Copyright (c) 2015 CA Technologies, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MyNetwokProtocol.h"

@interface MyNetworkSessionDataTaskWithDelegate : MyNetwokProtocol
- (void)performRequest:(NSURLRequest *)request onQueue:(NSOperationQueue *)queue;
@end
