//
//  MyNetworkSessionDelegate.h
//  CAMSMDemo
//
//  Created by Nilesh on 3/27/15.
//  Copyright (c) 2015 CA Technologies, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MyNetwokProtocol.h"

@interface MyNetworkSessionDelegate : NSObject<NSURLSessionDataDelegate>

- (id)initWithDelegate:(id<MyNetworkProtocolDelegate>)delegate;
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task
didCompleteWithError:(NSError *)error;

@end
