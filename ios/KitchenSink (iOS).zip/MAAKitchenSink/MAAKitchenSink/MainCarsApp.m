//
//  MainCarsApp.m
//  MAAKitchenSink
//
//  Created by Nilesh Agrawal on 6/27/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import "MainCarsApp.h"

@implementation MainCarsApp

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
