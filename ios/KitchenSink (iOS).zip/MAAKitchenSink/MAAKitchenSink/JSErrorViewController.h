//
//  JSErrorViewController.h
//  CAMobileAppAnalytics
//
//  Created by Nilesh Agrawal on 5/24/16.
//  Copyright © 2016 CA Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JSErrorViewController : UIViewController<UIWebViewDelegate>


@end
