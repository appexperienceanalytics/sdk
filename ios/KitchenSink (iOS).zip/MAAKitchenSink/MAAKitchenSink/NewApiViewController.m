//
//  NEWApiViewController.m
//  CAMobileAppAnalytics
//
//  Created by Nilesh Agrawal on 6/18/16.
//  Copyright © 2016 CA Technologies. All rights reserved.
//

#import "NEWApiViewController.h"
#import "CAMDOReporter.h"

@implementation NEWApiViewController

#pragma mark - View Controller Methods
-(void)viewDidLoad{
    [super viewDidLoad];
}


#pragma mark - IBoutlets

- (IBAction)startApplicationTransaction:(id)sender {
    
    NSLog(@"Successful case for startApplicationTransaction");
    [CAMDOReporter startApplicationTransactionWithName:@"Purchases" completionHandler:^(BOOL completed, NSError *error) {
        if(!completed && error!=nil){
            NSLog(@"completed = %@ ERROR = %ld",completed?@"YES":@"NO",(long)error.code);
        }else{
            NSLog(@"completed = %@",completed?@"YES":@"NO");
        }
    }];
    
    NSLog(@"Failure Case for startApplicationTransaction");
    [CAMDOReporter startApplicationTransactionWithName:nil completionHandler:^(BOOL completed, NSError *error) {
        if(!completed && error!=nil){
            NSLog(@"completed = %@ ERROR = %ld",completed?@"YES":@"NO",(long)error.code);
        }else{
            NSLog(@"completed = %@",completed?@"YES":@"NO");
        }
    }];
    
}

- (IBAction)stopApplicationTransaction:(id)sender {
    NSLog(@"Successful case for stopApplicationTransaction");
    [CAMDOReporter stopApplicationTransactionWithName:@"Purchase" completionHandler:^(BOOL completed, NSError *error) {
        if(!completed && error!=nil){
            NSLog(@"completed = %@ ERROR = %ld",completed?@"YES":@"NO",(long)error.code);
        }else{
            NSLog(@"completed = %@",completed?@"YES":@"NO");
        }
    }];
    
    NSLog(@"Failure Case for stopApplicationTransaction");
    [CAMDOReporter stopApplicationTransactionWithName:nil completionHandler:^(BOOL completed, NSError *error) {
        if(!completed && error!=nil){
            NSLog(@"completed = %@ ERROR = %ld",completed?@"YES":@"NO",(long)error.code);
        }else{
            NSLog(@"completed = %@",completed?@"YES":@"NO");
        }
    }];
    
}

- (IBAction)startApplicationTransactionWithService:(id)sender {
     NSLog(@"Successful case for startApplicationTransactionWithService");
    [CAMDOReporter startApplicationTransactionWithName:@"Purchases" service:@"Booking" completionHandler:^(BOOL completed, NSError *error) {
        if(!completed && error!=nil){
            NSLog(@"completed = %@ ERROR = %ld",completed?@"YES":@"NO",(long)error.code);
        }else{
            NSLog(@"completed = %@",completed?@"YES":@"NO");
        }
    }];
    
    NSLog(@"Failure case fr stopApplicationTransactionWithService");
    [CAMDOReporter startApplicationTransactionWithName:nil service:nil completionHandler:^(BOOL completed, NSError *error) {
        if(!completed && error!=nil){
            NSLog(@"completed = %@ ERROR = %ld",completed?@"YES":@"NO",(long)error.code);
        }else{
            NSLog(@"completed = %@",completed?@"YES":@"NO");
        }
    }];
    
}


- (IBAction)stopApplicationTransactionWithFailure:(id)sender {
    NSLog(@"Successful case for stopApplicationTransactionWithFailure");
    [CAMDOReporter stopApplicationTransactionWithName:@"Purchases" failure:@"Booking" completionHandler:^(BOOL completed, NSError *error) {
        if(!completed && error!=nil){
            NSLog(@"completed = %@ ERROR = %ld",completed?@"YES":@"NO",(long)error.code);
        }else{
            NSLog(@"completed = %@",completed?@"YES":@"NO");
        }
    }];
    
    NSLog(@"Failure case for stopApplicationTransaction");
    [CAMDOReporter stopApplicationTransactionWithName:nil failure:nil completionHandler:^(BOOL completed, NSError *error) {
        if(!completed && error!=nil){
            NSLog(@"completed = %@ ERROR = %ld",completed?@"YES":@"NO",(long)error.code);
        }else{
            NSLog(@"completed = %@",completed?@"YES":@"NO");
        }
    }];
    
}


- (IBAction)sendScreenShot:(id)sender {
    NSLog(@"SuccessfulCase for SendScreenshot");
    [CAMDOReporter sendScreenShot:nil withQuality:0.0 completionHandler:^(BOOL completed, NSError *error) {
        if(!completed && error!=nil){
            NSLog(@"completed = %@ ERROR = %ld",completed?@"YES":@"NO",(long)error.code);
        }else{
            NSLog(@"completed = %@",completed?@"YES":@"NO");
        }
    }];
    
}

- (IBAction)viewLoaded:(id)sender {
    NSLog(@"Successful Case for View Loaded");
    [CAMDOReporter viewLoaded:nil loadTime:1314.0 completionHandler:^(BOOL completed, NSError *error) {
        if(!completed && error!=nil){
            NSLog(@"completed = %@ ERROR = %ld",completed?@"YES":@"NO",(long)error.code);
        }else{
            NSLog(@"completed = %@",completed?@"YES":@"NO");
        }
    }];
}

- (IBAction)logNetwork:(id)sender {
    NSLog(@"Successful case for logNetwork");
    [CAMDOReporter logNetworkEvent:@"http://www.ca.com" withStatus:200 withResponseTime:400 withInBytes:1200 withOutBytes:50
                 completionHandler:^(BOOL completed, NSError *error) {
                     if(!completed && error!=nil){
                         NSLog(@"completed = %@ ERROR = %ld",completed?@"YES":@"NO",(long)error.code);
                     }else{
                         NSLog(@"completed = %@",completed?@"YES":@"NO");
                     }
    }];
    
    NSLog(@"Failure case for logNetwork");
    [CAMDOReporter logNetworkEvent:nil withStatus:200 withResponseTime:400 withInBytes:1200 withOutBytes:50 completionHandler:^(BOOL completed, NSError *error) {
        if(!completed && error!=nil){
            NSLog(@"completed = %@ ERROR = %ld",completed?@"YES":@"NO",(long)error.code);
        }else{
            NSLog(@"completed = %@",completed?@"YES":@"NO");
        }
    }];
}

- (IBAction)logNumeric:(id)sender {
    
    NSLog(@"Successful case for logNumeric");
    [CAMDOReporter logNumericMetric:@"NumericMetric" withValue:100 withAttributes:nil completionHandler:^(BOOL completed, NSError *error) {
        if(!completed && error!=nil){
            NSLog(@"completed = %@ ERROR = %ld",completed?@"YES":@"NO",(long)error.code);
        }else{
            NSLog(@"completed = %@",completed?@"YES":@"NO");
        }
    }];
    
    NSLog(@"Failure case for logNumeric");
    [CAMDOReporter logNumericMetric:nil withValue:100 withAttributes:nil completionHandler:^(BOOL completed, NSError *error) {
        if(!completed && error!=nil){
            NSLog(@"completed = %@ ERROR = %ld",completed?@"YES":@"NO",(long)error.code);
        }else{
            NSLog(@"completed = %@",completed?@"YES":@"NO");
        }
    }];

}

- (IBAction)logTextMetric:(id)sender {
    NSLog(@"Successful case for logTextMetric");
    [CAMDOReporter logTextMetric:@"TextMetric" withValue:@"Value" withAttributes:nil completionHandler:^(BOOL completed, NSError *error) {
        if(!completed && error!=nil){
            NSLog(@"completed = %@ ERROR = %ld",completed?@"YES":@"NO",(long)error.code);
        }else{
            NSLog(@"completed = %@",completed?@"YES":@"NO");
        }
    }];
    
    NSLog(@"Failure case for logTextMetric");
    [CAMDOReporter logTextMetric:nil withValue:nil withAttributes:nil completionHandler:^(BOOL completed, NSError *error) {
        if(!completed && error!=nil){
            NSLog(@"completed = %@ ERROR = %ld",completed?@"YES":@"NO",(long)error.code);
        }else{
            NSLog(@"completed = %@",completed?@"YES":@"NO");
        }
    }];
}

- (IBAction)uploadEvents:(id)sender {
    
    NSLog(@"Successful case for uploadEvents");
    [CAMDOReporter uploadEventsWithCompletionHandler:^(NSDictionary *response, NSError *error) {
        if(error!=nil){
            NSLog(@"ERROR = %ld",(long)error.code);
        }
    }];
}

@end
