//
//  UILabel+LabelEffects.m
//  MAAKitchenSink
//
//  Created by Nilesh on 4/21/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import "UILabel+LabelEffects.h"

@implementation UILabel (LabelEffects)

-(void)makeLabelBlack{
        [self setTextColor:[UIColor blackColor]];
}

@end
