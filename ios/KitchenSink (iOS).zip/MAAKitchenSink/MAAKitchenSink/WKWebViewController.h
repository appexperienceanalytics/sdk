//
//  ViewController.h
//  WKWebViewSample
//
//  Created by Suman Cherukuri on 8/24/15.
//  Copyright (c) 2015 CA Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

@interface WKWebViewController : UIViewController <WKScriptMessageHandler, WKUIDelegate>


@end

