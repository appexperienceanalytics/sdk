//
//  MainCarsAppViewController.m
//  MAAKitchenSink
//
//  Created by Nilesh Agrawal on 6/27/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import "MainCarsAppViewController.h"
#import "MainCarsApp.h"
#import "CarsListViewController.h"
#import "BillingInfoViewController.h"
#import "LoanTypesViewController.h"
#import "PersonProfileViewController.h"
#import "UIColor+BFPaperColors.h"


@interface MainCarsAppViewController ()
@property (weak, nonatomic) IBOutlet UICollectionView *maincarsappCollectionView;

@property (weak, nonatomic) IBOutlet UIView *titleView;
@end

@implementation MainCarsAppViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setUpView];
    
    // Do any additional setup after loading the view.
//    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
//    CGFloat width = (CGRectGetWidth(self.view.frame));
//    CGFloat height = (CGRectGetHeight(self.view.frame));
//    [flowLayout setItemSize:CGSizeMake(width, height/7)];
//    [flowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
//    
//    flowLayout.minimumInteritemSpacing = 10.0f;
//    flowLayout.minimumLineSpacing=10.0f;
//    0
   // [_maincarsappCollectionView setCollectionViewLayout:flowLayout];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - View 
-(void)setUpView{
    [_titleView setBackgroundColor:[UIColor paperColorBlue500]];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 4;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    MainCarsApp *activityViewCell = nil;
    //Cell from the prototype
        if(indexPath.row == 0){
            activityViewCell=[collectionView dequeueReusableCellWithReuseIdentifier:@"MainCarsAppCell" forIndexPath:indexPath];
            activityViewCell.ivCarFeature.image = [UIImage imageNamed:@"old_car"];
            activityViewCell.lCarAppFeature.text = @"View Cars";
    }else if(indexPath.row == 1){
            activityViewCell =[collectionView dequeueReusableCellWithReuseIdentifier:@"purchaseCarCell" forIndexPath:indexPath];
            activityViewCell.ivCarFeature.image = [UIImage imageNamed:@"carpurchase"];
            activityViewCell.lCarAppFeature.text = @"Car Purchase";
    }else if(indexPath.row ==2){
        activityViewCell =[collectionView dequeueReusableCellWithReuseIdentifier:@"carsLoanCell" forIndexPath:indexPath];
            activityViewCell.ivCarFeature.image = [UIImage imageNamed:@"loan"];
            activityViewCell.lCarAppFeature.text = @"Car Loan";
    }else if(indexPath.row == 3){
            activityViewCell =[collectionView dequeueReusableCellWithReuseIdentifier:@"personProfileCell" forIndexPath:indexPath];
            activityViewCell.ivCarFeature.image = [UIImage imageNamed:@"feedback"];
            activityViewCell.lCarAppFeature.text = @"User Feedback";
    }
        activityViewCell.layer.borderWidth=1;
        activityViewCell.layer.borderColor=[UIColor blackColor].CGColor;
    
    return activityViewCell;
}

/*
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.row ==0){
         [self performSegueWithIdentifier:@"MasterToCars" sender:nil];
    }else if(indexPath.row ==1){
        [self performSegueWithIdentifier:@"MasterToPurchase" sender:nil];
    }else if(indexPath.row ==2 ){
        [self performSegueWithIdentifier:@"MasterToLoan" sender:nil];
    }else if(indexPath.row ==3){
         [self performSegueWithIdentifier:@"MasterToFeedback" sender:nil];
    }
}
 */

/*
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    if([segue.identifier isEqualToString:@"MasterToCars"]){
        NSIndexPath *indexPath = [_maincarsappCollectionView indexPathsForSelectedItems].firstObject;
        if(indexPath.row == 0){
            CarsListViewController *carsListViewController = segue.destinationViewController;
        }
    }
    
    if([segue.identifier isEqualToString:@"MasterToPurchase"]){
        NSIndexPath *indexPath = [_maincarsappCollectionView indexPathsForSelectedItems].firstObject;
        if(indexPath.row == 1){
          BillingInfoViewController   *carsListViewController = segue.destinationViewController;
        }
    }
    
    
    if([segue.identifier isEqualToString:@"MasterToLoan"]){
        NSIndexPath *indexPath = [_maincarsappCollectionView indexPathsForSelectedItems].firstObject;
        if(indexPath.row == 2){
            
         LoanTypesViewController *carsListViewController = segue.destinationViewController;
        }
    }
    
    if([segue.identifier isEqualToString:@"MasterToFeedback"]){
        NSIndexPath *indexPath = [_maincarsappCollectionView indexPathsForSelectedItems].firstObject;
        if(indexPath.row == 3){
            PersonProfileViewController  *carsListViewController = segue.destinationViewController;
        }
    }

}
*/

@end
