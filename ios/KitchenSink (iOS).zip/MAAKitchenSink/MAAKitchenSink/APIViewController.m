//
//  APIViewController.m
//  CAMAADemoApp
//
//  Created by Nilesh on 4/5/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import "APIViewController.h"
#import "CMPopTipView.h"
#import "UIView+ViewEffects.h"
#import "UIButton+ButtonEffects.h"
#import "UILabel+LabelEffects.h"
#import "FXBlurView.h"
//TAG:DECTRAINING
//#import "CAMDOReporter.h"

#import "UIColor+BFPaperColors.h"

#define foo4random() (1.0 * (arc4random() % ((unsigned)RAND_MAX + 1)) / RAND_MAX)

static const CGFloat KEYBOARD_ANIMATION_DURATION = 0.3;
static const CGFloat MINIMUM_SCROLL_FRACTION = 0.2;
static const CGFloat MAXIMUM_SCROLL_FRACTION = 0.8;
static const CGFloat PORTRAIT_KEYBOARD_HEIGHT = 216;
static const CGFloat LANDSCAPE_KEYBOARD_HEIGHT = 162;

static Boolean allowLogin = NO;
@interface APIViewController ()
@property (weak, nonatomic) IBOutlet FXBlurView *blurView;
@property CGFloat animatedDistance;
/*TextFields*/
@property (weak, nonatomic) IBOutlet UITextField *tfCustomerID;
@property (weak, nonatomic) IBOutlet UITextField *tfLocationCountry;
@property (weak, nonatomic) IBOutlet UITextField *tfLocationZipCode;
@property (weak, nonatomic) IBOutlet UITextField *tfStartApplicationTransactionTransactionName;
@property (weak, nonatomic) IBOutlet UITextField *tfUserName;
@property (weak, nonatomic) IBOutlet UITextField *tfPassword;

@property (weak, nonatomic) IBOutlet UITextField *sessionEventName;
@property (weak, nonatomic) IBOutlet UITextField *sessionEventValue;
@property (weak, nonatomic) IBOutlet UITextField *sessionEventDataType;
@property (weak, nonatomic) IBOutlet UITextField *sessionInfoName;
@property (weak, nonatomic) IBOutlet UITextField *sessionInfoValue;
@property (weak, nonatomic) IBOutlet UITextField *sessionInfoDataType;


/*Buttons*/
@property (weak, nonatomic) IBOutlet UIButton *bSetCustomerID;
@property (weak, nonatomic) IBOutlet UIButton *bSetCustomerLocation;
@property (weak, nonatomic) IBOutlet UIButton *bAddSessionEvent;
@property (weak, nonatomic) IBOutlet UIButton *bStartApplicationTransaction;
@property (weak, nonatomic) IBOutlet UIButton *bSetSessionInfo;
@property (weak, nonatomic) IBOutlet UIButton *bLogin;
@property (weak, nonatomic) IBOutlet UIButton *bEndApplicationTransaction;
@property (weak, nonatomic) IBOutlet UIButton *bSessionInfo;
@property (weak, nonatomic) IBOutlet UIButton *bEnableSDK;
@property (weak, nonatomic) IBOutlet UIButton *bDisableSDK;


/*Set Info Buttons */
@property (weak, nonatomic) IBOutlet UIButton *bInfoCustomerID;
@property (weak, nonatomic) IBOutlet UIButton *bInfoSetCustomerLocation;
@property (weak, nonatomic) IBOutlet UIButton *bInfoSessionEvent;
@property (weak, nonatomic) IBOutlet UIButton *bInfoStartApplication;

/*View  Title*/
@property (weak, nonatomic) IBOutlet UIView *APItitle;

/*Views*/
@property (weak, nonatomic) IBOutlet UIView *vAPIView;
@property (weak, nonatomic) IBOutlet UIView *vTransactionView;

/*Labels*/
@property (weak, nonatomic) IBOutlet UILabel *lCustomerID;
@property (weak, nonatomic) IBOutlet UILabel *lCustomerLcoation;
@property (weak, nonatomic) IBOutlet UILabel *lSessionEvent;
@property (weak, nonatomic) IBOutlet UILabel *lStartApplicationTransaction;
@property (weak, nonatomic) IBOutlet UILabel *lEndApplicationTransaction;
@property (weak, nonatomic) IBOutlet UILabel *lSessionInfo;



/*IgnoreViews*/
@property (weak, nonatomic) IBOutlet UIView *ignoreView1;
@property (weak, nonatomic) IBOutlet UIView *ignoreView2;
@property (weak, nonatomic) IBOutlet UIView *ignoreView3;
@property (weak, nonatomic) IBOutlet UIView *ignoreView4;
@property (weak, nonatomic) IBOutlet UIView *ignoreView5;
@property (weak, nonatomic) IBOutlet UIView *ignoreView6;
@property (weak, nonatomic) IBOutlet UIView *ignoreView7;
@property (weak, nonatomic) IBOutlet UIView *ignoreView8;



/*Pop View Controller. */
@property (nonatomic, strong)	NSArray			*colorSchemes;
@property (nonatomic, strong)	NSDictionary	*contents;
@property (nonatomic, strong)	id				currentPopTipViewTarget;
@property (nonatomic, strong)	NSDictionary	*titles;
@property (nonatomic, strong)	NSMutableArray	*visiblePopTipViews;



@end

@implementation APIViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
   // [self setupBlurBackground];
    [self setUpView];
}


-(void)setUpView{

    /*Setup Views*/
    [_vAPIView setUpTransperantViewBlackBorder];
    [_vTransactionView setUpTransperantViewBlackBorder];

    /*Setup Ignore Views*/
    [_ignoreView1 hideIgnoreView];
    [_ignoreView2 hideIgnoreView];
    [_ignoreView3 hideIgnoreView];
    [_ignoreView4 hideIgnoreView];
    [_ignoreView5 hideIgnoreView];
    [_ignoreView6 hideIgnoreView];
    [_ignoreView7 hideIgnoreView];
    [_ignoreView8 hideIgnoreView];

    /*Setup Label*/
    [_lCustomerID makeLabelBlack];
    [_lCustomerLcoation makeLabelBlack];
    [_lSessionEvent makeLabelBlack];
    [_lStartApplicationTransaction makeLabelBlack];
    [_lEndApplicationTransaction makeLabelBlack];

    /*Setup Buttons*/
    [_bSetCustomerID makePaperButton];
    [_bSetCustomerLocation makePaperButton];
    [_bAddSessionEvent makePaperButton];
    [_bStartApplicationTransaction makePaperButton];
    [_bEndApplicationTransaction makePaperButton];
    [_bLogin makePaperButton];
    [_bSessionInfo makePaperButton];
    [_bEnableSDK makePaperButton];
    [_bDisableSDK makePaperButton];
    
    /*
     // No border, no shadow, floatingPlaceholderEnabled
     textField4.layer.borderColor = UIColor.clearColor().CGColor
     textField4.floatingPlaceholderEnabled = true
     textField4.placeholder = "Github"
     textField4.tintColor = UIColor.MKColor.Blue
     textField4.rippleLocation = .Right
     textField4.cornerRadius = 0
     textField4.bottomBorderEnabled = true
     */
    _APItitle.backgroundColor = [UIColor paperColorBlue];
    
    _tfCustomerID.delegate = self;
    _tfLocationCountry.delegate = self;
    _tfLocationZipCode.delegate = self;
    _tfStartApplicationTransactionTransactionName.delegate = self;
    _tfUserName.delegate = self;
    _tfPassword.delegate = self;

    _sessionEventName.delegate = self;
    _sessionEventValue.delegate = self;
    _sessionEventDataType.delegate = self;
    _sessionInfoName.delegate = self;
    _sessionInfoValue.delegate = self;
    _sessionInfoDataType.delegate = self;
    

    /*Setup PopViewController*/
    [self setupPopViewController];
}


#pragma mark - TextField Delegate

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    
    
    CGRect textFieldRect =
    [self.view.window convertRect:textField.bounds fromView:textField];
    CGRect viewRect =
    [self.view.window convertRect:self.view.bounds fromView:self.view];
    CGFloat midline = textFieldRect.origin.y + 0.5 * textFieldRect.size.height;
    CGFloat numerator =
    midline - viewRect.origin.y
    - MINIMUM_SCROLL_FRACTION * viewRect.size.height;
    CGFloat denominator =
    (MAXIMUM_SCROLL_FRACTION - MINIMUM_SCROLL_FRACTION)
    * viewRect.size.height;
    CGFloat heightFraction = numerator / denominator;
    if (heightFraction < 0.0)
    {
        heightFraction = 0.0;
    }
    else if (heightFraction > 1.0)
    {
        heightFraction = 1.0;
    }
    UIInterfaceOrientation orientation =
    [[UIApplication sharedApplication] statusBarOrientation];
    if (orientation == UIInterfaceOrientationPortrait ||
        orientation == UIInterfaceOrientationPortraitUpsideDown)
    {
        _animatedDistance = floor(PORTRAIT_KEYBOARD_HEIGHT * heightFraction);
    }
    else
    {
        _animatedDistance = floor(LANDSCAPE_KEYBOARD_HEIGHT * heightFraction);
    }
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y -= _animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [self.view setFrame:viewFrame];
    [UIView commitAnimations];
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y += _animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    [self.view setFrame:viewFrame];
    [UIView commitAnimations];
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField {

    [_tfCustomerID resignFirstResponder];
    [_tfLocationCountry resignFirstResponder];
    [_tfLocationZipCode resignFirstResponder];
    [_tfStartApplicationTransactionTransactionName resignFirstResponder];
    [_tfUserName resignFirstResponder];
    [_tfPassword resignFirstResponder];

    [_sessionEventName resignFirstResponder];
    [_sessionEventValue resignFirstResponder];
    [_sessionEventDataType resignFirstResponder];
    [_sessionInfoName resignFirstResponder];
    [_sessionInfoValue resignFirstResponder];
    [_sessionInfoDataType resignFirstResponder];

    
    return NO;
}


#pragma mark - API Methods

- (IBAction)setCustomerID:(id)sender {
    if(![_tfCustomerID.text isEqualToString:@""]){
        //TAG:DECTRAINING
//        [[CAMDOReporter sharedInstance ]setSessionInfoOf:CAMAA_CUSTOMER_ID withName:@"ID" withValue:_tfCustomerID.text];
        
    }
}

- (IBAction)setCustomerLocation:(id)sender {
    if(![[_tfLocationCountry text] isEqualToString:@""] && ![[_tfLocationZipCode text] isEqualToString:@""] ){
    NSMutableDictionary *location = [[NSMutableDictionary alloc] init];

    [location setValue:[_tfLocationCountry text] forKey:@"Country"];
    [location setValue:[_tfLocationZipCode text] forKey:@"Zipcode"];
        //TAG:DECTRAINING
//    [[CAMDOReporter sharedInstance] setCustomerLocation:location];
    }
}

- (IBAction)addSessionEvent:(id)sender {
    // ExampleOfAddSession Event.
    if(![_sessionEventName.text isEqualToString:@""] &&
       ![_sessionEventValue.text isEqualToString:@""] &&
       ![_sessionEventDataType.text isEqualToString:@""]
       ){
        //TAG:DECTRAINING
//        [[CAMDOReporter sharedInstance ]addSessionEventOf:_sessionEventDataType.text withName:_sessionEventName.text withValue:_sessionEventValue.text];
    }
}

-(IBAction)addSEssionInfo:(id)sender{

    //Example of add Sessio Info
    if(![_sessionInfoName.text isEqualToString:@""] &&
       ![_sessionInfoValue.text isEqualToString:@""] &&
       ![_sessionInfoDataType.text isEqualToString:@""]){
        //TAG:DECTRAINING
//        [[CAMDOReporter sharedInstance ]setSessionInfoOf:_sessionInfoDataType.text withName:_sessionInfoName.text withValue:_sessionInfoValue.text];
    }
}

- (IBAction)startApplicationTransaction:(id)sender {
    if(![[_tfStartApplicationTransactionTransactionName text] isEqualToString:@""]){
//    [CAMDOReporter startApplicationTransactionWithName:[_tfStartApplicationTransactionTransactionName text] completionHandler:^(BOOL completed, NSError *error) {
        
//        }];
    }
}


- (IBAction)endApplicationTransaction:(id)sender {
   // [[CAMDOReporter sharedInstance] stopApplicationTransaction:_tfStartApplicationTransactionTransactionName.text];
}

- (IBAction)login:(id)sender {
    if([_tfUserName.text isEqualToString:@"mdoadmin"] && [_tfPassword.text isEqualToString:@"mdoadmin"]){
        allowLogin = YES;
    }
}


- (IBAction)enableSDK:(id)sender {
    //TAG:DECTRAINING
//    [CAMDOReporter enableSDK];
    UIAlertController * alert=   [UIAlertController
                                  alertControllerWithTitle:@"CAMAASDK Enabled"
                                  message:@"CA MAA SDK is Enabled.  Plesase restart the APP to make it effective"
                                  preferredStyle:UIAlertControllerStyleAlert];

    UIAlertAction* ok = [UIAlertAction
                         actionWithTitle:@"OK"
                         style:UIAlertActionStyleDefault
                         handler:^(UIAlertAction * action)
                         {
                             [alert dismissViewControllerAnimated:YES completion:nil];

                         }];

    [alert addAction:ok];


    [self presentViewController:alert animated:YES completion:nil];
}

- (IBAction)disableSDK:(id)sender {
    //TAG:DECTRAINING
//    [CAMDOReporter disableSDK];
    UIAlertController * alert=   [UIAlertController
                                  alertControllerWithTitle:@"CAMAASDK Disabled"
                                  message:@"CA MAA SDK is Disabled.  Plesase restart the APP to make it effective"
                                  preferredStyle:UIAlertControllerStyleAlert];

    UIAlertAction* ok = [UIAlertAction
                         actionWithTitle:@"OK"
                         style:UIAlertActionStyleDefault
                         handler:^(UIAlertAction * action)
                         {
                             [alert dismissViewControllerAnimated:YES completion:nil];

                         }];

    [alert addAction:ok];

    [self presentViewController:alert animated:YES completion:nil];
}




#pragma  mark - view setup methods

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/



-(void)setupPopViewController{
    self.visiblePopTipViews = [NSMutableArray array];

    self.contents = [NSDictionary dictionaryWithObjectsAndKeys:
                     // Rounded rect buttons
                     @"[[CAMDOReporter sharedInstance] setSessionInfoOf:CAMAA_CUSTOMER_ID withName:@\"ID\" withValue:@\"John1234\"];", [NSNumber numberWithInt:6],
                     @"-(void)setCustomerLocation:(NSDictionary *) locationInfo;", [NSNumber numberWithInt:7],
                     @"- (void) addSessionEventOf:(NSString *)name withValue:(NSString *)value withDataType:(NSString *) dataType; \n\n- (void) addSessionEventOf:(NSString *)name  withValue:(NSString *) value withDataType:(NSString *)dataType withAttributes:(NSMutableDictionary *)attributes;"
                     , [NSNumber numberWithInt:8],
                     @"- (void) setSessionInfoOf:(NSString *)name withValue:(NSString *)value withDataType:(NSString *)dataType;", [NSNumber numberWithInt:9],
                     @"+ (void) enableSDK;\n+ (void) disableSDK;", [NSNumber numberWithInt:10],
                     @"Demonstrates a work flow for custom transactions - \n1 : Start the transaction after giving some name for the transaction. \n2 : Add some events, by logging in \nUsername \"mdoamdin\" \nPassword : \"mdoadmin\" \n3. End the transactions", [NSNumber numberWithInt:11],
                     nil];
    self.titles = [NSDictionary dictionaryWithObjectsAndKeys:
                   @"CustomerID", [NSNumber numberWithInt:6],
                   @"CustomerLocation", [NSNumber numberWithInt:7],
                   @"SessionEvent",[NSNumber numberWithInt:8],
                   @"SessionInfo",[NSNumber numberWithInt:9],
                   @"Sleep Switch",[NSNumber numberWithInt:10],
                   @"Transactions",[NSNumber numberWithInt:11],
                   nil];

    // Array of (backgroundColor, textColor) pairs.
    // NSNull for either means leave as default.
    // A color scheme will be picked randomly per CMPopTipView.
    self.colorSchemes = [NSArray arrayWithObjects:
                         [NSArray arrayWithObjects:[NSNull null], [NSNull null], nil],
                         [NSArray arrayWithObjects:[UIColor colorWithRed:134.0/255.0 green:74.0/255.0 blue:110.0/255.0 alpha:1.0], [NSNull null], nil],
                         [NSArray arrayWithObjects:[UIColor darkGrayColor], [NSNull null], nil],
                         [NSArray arrayWithObjects:[UIColor lightGrayColor], [UIColor darkTextColor], nil],
                         [NSArray arrayWithObjects:[UIColor orangeColor], [UIColor blueColor], nil],
                         [NSArray arrayWithObjects:[UIColor colorWithRed:220.0/255.0 green:0.0/255.0 blue:0.0/255.0 alpha:1.0], [NSNull null], nil],
                         nil];

}



#pragma mark - PopView Controller

- (void)dismissAllPopTipViews
{
    while ([self.visiblePopTipViews count] > 0) {
        CMPopTipView *popTipView = [self.visiblePopTipViews objectAtIndex:0];
        [popTipView dismissAnimated:YES];
        [self.visiblePopTipViews removeObjectAtIndex:0];
    }
}

- (IBAction)openPopUp:(id)sender
{
    [self dismissAllPopTipViews];

    if (sender == self.currentPopTipViewTarget) {
        // Dismiss the popTipView and that is all
        self.currentPopTipViewTarget = nil;
    }
    else {
        NSString *contentMessage = nil;
        UIView *contentView = nil;
        NSNumber *key = [NSNumber numberWithInteger:[(UIView *)sender tag]];
        id content = [self.contents objectForKey:key];
        if ([content isKindOfClass:[UIView class]]) {
            contentView = content;
        }
        else if ([content isKindOfClass:[NSString class]]) {
            contentMessage = content;
        }
        else {
            contentMessage = @"A CMPopTipView can automatically point to any view or bar button item.";
        }
        NSArray *colorScheme = [self.colorSchemes objectAtIndex:3];
        UIColor *backgroundColor = [colorScheme objectAtIndex:0];
        UIColor *textColor = [colorScheme objectAtIndex:1];

        NSString *title = [self.titles objectForKey:key];

        CMPopTipView *popTipView;
        if (contentView) {
            popTipView = [[CMPopTipView alloc] initWithCustomView:contentView];
        }
        else if (title) {
            popTipView = [[CMPopTipView alloc] initWithTitle:title message:contentMessage];
        }
        else {
            popTipView = [[CMPopTipView alloc] initWithMessage:contentMessage];
        }
        popTipView.delegate = self;

        /* Some options to try.
         */
        //popTipView.disableTapToDismiss = YES;
        //popTipView.preferredPointDirection = PointDirectionUp;
        //popTipView.hasGradientBackground = NO;
        //popTipView.cornerRadius = 2.0;
        //popTipView.sidePadding = 30.0f;
        //popTipView.topMargin = 20.0f;
        //popTipView.pointerSize = 50.0f;
        //popTipView.hasShadow = NO;

        if (backgroundColor && ![backgroundColor isEqual:[NSNull null]]) {
            popTipView.backgroundColor = backgroundColor;
        }
        if (textColor && ![textColor isEqual:[NSNull null]]) {
            popTipView.textColor = textColor;
        }

        popTipView.animation = arc4random() % 2;
        popTipView.has3DStyle = (BOOL)(arc4random() % 2);

        popTipView.dismissTapAnywhere = YES;
        [popTipView autoDismissAnimated:YES atTimeInterval:3.0];

        if ([sender isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)sender;
            [popTipView presentPointingAtView:button inView:self.view animated:YES];
        }
        else {
            UIBarButtonItem *barButtonItem = (UIBarButtonItem *)sender;
            [popTipView presentPointingAtBarButtonItem:barButtonItem animated:YES];
        }

        [self.visiblePopTipViews addObject:popTipView];
        self.currentPopTipViewTarget = sender;
    }
}


#pragma mark - CMPopTipViewDelegate methods
- (void)popTipViewWasDismissedByUser:(CMPopTipView *)popTipView
{
    [self.visiblePopTipViews removeObject:popTipView];
    self.currentPopTipViewTarget = nil;
}


#pragma mark - UIViewController methods
- (void)willAnimateRotationToInterfaceOrientation:(__unused UIInterfaceOrientation)toInterfaceOrientation duration:(__unused NSTimeInterval)duration
{
    for (CMPopTipView *popTipView in self.visiblePopTipViews) {
        id targetObject = popTipView.targetObject;
        [popTipView dismissAnimated:NO];

        if ([targetObject isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)targetObject;
            [popTipView presentPointingAtView:button inView:self.view animated:NO];
        }
        else {
            UIBarButtonItem *barButtonItem = (UIBarButtonItem *)targetObject;
            [popTipView presentPointingAtBarButtonItem:barButtonItem animated:NO];
        }
    }
}


@end
