//
//  UIButton+ButtonEffects.h
//  MAAKitchenSink
//
//  Created by Nilesh on 4/21/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (ButtonEffects)

-(void)makePaperButton;

@end
