//
//  UIButton+ButtonEffects.m
//  MAAKitchenSink
//
//  Created by Nilesh on 4/21/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import "UIButton+ButtonEffects.h"
#import "BFPaperButton.h"
#import "UIColor+BFPaperColors.h"
@implementation UIButton (ButtonEffects)

-(void)makePaperButton{
    
   
    
}


/*
 -(void)makeTransperantBlackBorderButtons{
 self.layer.backgroundColor = [UIColor clearColor].CGColor;
 self.layer.borderWidth = 1;
 self.layer.cornerRadius =5;
 //button.layer.borderColor = [UIColor whiteColor].CGColor;
 self.layer.borderColor = [UIColor blackColor].CGColor;
 [self setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
 }
 
 */
@end
