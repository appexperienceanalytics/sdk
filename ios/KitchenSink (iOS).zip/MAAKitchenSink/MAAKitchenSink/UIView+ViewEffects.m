//
//  UIView+ViewEffects.m
//  MAAKitchenSink
//
//  Created by Nilesh on 4/21/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import "UIView+ViewEffects.h"

@implementation UIView (ViewEffects)

-(void)hideIgnoreView{
    //view.layer.borderColor = [UIColor whiteColor].CGColor;
    self.layer.borderColor = [UIColor clearColor].CGColor;
    self.layer.backgroundColor=[UIColor clearColor].CGColor;
}

-(void)setupPartitionView{
    self.layer.borderWidth = 1;
    //view.layer.borderColor = [UIColor whiteColor].CGColor;
    self.layer.borderColor = [UIColor blackColor].CGColor;
    //[view setBackgroundColor:[UIColor whiteColor]];
    [self setBackgroundColor:[UIColor blackColor]];
    //[view setTintColor:[UIColor whiteColor]];
    [self setTintColor:[UIColor blackColor]];
    self.layer.backgroundColor=[UIColor clearColor].CGColor;
}

-(void)setUpTransperantViewBlackBorder{
    self.backgroundColor = [UIColor whiteColor];
    self.layer.borderColor = [UIColor grayColor].CGColor;
    self.layer.borderWidth = 1.0f;
}

-(void)setSqaureView{
    self.layer.borderWidth = 1;
    //view.layer.borderColor = [UIColor whiteColor].CGColor;
    self.layer.borderColor = [UIColor blackColor].CGColor;
    self.layer.backgroundColor=[UIColor clearColor].CGColor;
}

-(void) makeSquareTransperant{
    //self.layer.borderWidth = ;
    //view.layer.borderColor = [UIColor whiteColor].CGColor;
    self.layer.borderColor = [UIColor blackColor].CGColor;
    self.layer.backgroundColor=[UIColor clearColor].CGColor;
}
@end
