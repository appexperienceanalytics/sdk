//
//  TransactionEventsViewController.m
//  CAMAADemoApp
//
//  Created by Nilesh on 4/5/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import "TransactionEventsViewController.h"
#import "CMPopTipView.h"
#import "UIView+ViewEffects.h"
#import "UIButton+ButtonEffects.h"
#import "UILabel+LabelEffects.h"
#import "FXBlurView.h"

#define foo4random() (1.0 * (arc4random() % ((unsigned)RAND_MAX + 1)) / RAND_MAX)
@interface TransactionEventsViewController ()
@property (weak, nonatomic) IBOutlet FXBlurView *blurView;

/*Label */
@property (weak, nonatomic) IBOutlet UILabel *lGenerateUIEvents;
@property (weak, nonatomic) IBOutlet UILabel *levent1;
@property (weak, nonatomic) IBOutlet UILabel *levent2;
@property (weak, nonatomic) IBOutlet UILabel *levent3;
@property (weak, nonatomic) IBOutlet UILabel *lGenerateNetworkEvent;
@property (weak, nonatomic) IBOutlet UILabel *lStatus;
@property (weak, nonatomic) IBOutlet UILabel *lGoBack;

/*Buttons */
@property (weak, nonatomic) IBOutlet UIButton *bPingGoogleCom;
@property (weak, nonatomic) IBOutlet UIButton *bButton;
@property (weak, nonatomic) IBOutlet UISlider *sliderEvent;
@property (weak, nonatomic) IBOutlet UIView *vGenerateUIEvents;
@property (weak, nonatomic) IBOutlet UIView *vNetworkEvents;

/*Segment Control*/
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentControlEvent;

@property (nonatomic, strong)	NSArray			*colorSchemes;
@property (nonatomic, strong)	NSDictionary	*contents;
@property (nonatomic, strong)	id				currentPopTipViewTarget;
@property (nonatomic, strong)	NSDictionary	*titles;
@property (nonatomic, strong)	NSMutableArray	*visiblePopTipViews;
/*Ignore Views */
@property (weak, nonatomic) IBOutlet UIView *ignoreView1;
@property (weak, nonatomic) IBOutlet UIView *ignoreView2;
@property (weak, nonatomic) IBOutlet UIView *ignoreView3;
@property (weak, nonatomic) IBOutlet UIView *ignoreView4;
@property (weak, nonatomic) IBOutlet UIView *ignoreView5;
@property (weak, nonatomic) IBOutlet UIView *ignoreView6;

@end

@implementation TransactionEventsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    //[self setupBlurBackground];
    [self setupView];
}


-(void)setupView{
    [_ignoreView1 hideIgnoreView];
    [_ignoreView2 hideIgnoreView];
    [_ignoreView3 hideIgnoreView];
    [_ignoreView4 hideIgnoreView];
    [_ignoreView5 hideIgnoreView];
    [_ignoreView6 hideIgnoreView];

    [_segmentControlEvent setTintColor:[UIColor whiteColor]];

    [_bPingGoogleCom makePaperButton];
    [_bButton makePaperButton];

    [_lGenerateNetworkEvent makeLabelBlack];
    [_levent1 makeLabelBlack];
    [_levent2 makeLabelBlack];
    [_levent3 makeLabelBlack];
    [_lStatus makeLabelBlack];
    [_lGoBack makeLabelBlack];
    [_lGenerateNetworkEvent makeLabelBlack];
    [_lGenerateUIEvents makeLabelBlack];

    [_vGenerateUIEvents setUpTransperantViewBlackBorder];
    [_vNetworkEvents setUpTransperantViewBlackBorder];
    [self setupPopViewController];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/



#pragma mark - Pop View Controller

-(void)setupPopViewController{
    self.visiblePopTipViews = [NSMutableArray array];

    self.contents = [NSDictionary dictionaryWithObjectsAndKeys:
                     // Rounded rect buttons
                     @"Generate UI Events.", [NSNumber numberWithInt:14],
                     @"Generate Some Network Events", [NSNumber numberWithInt:15],
                     nil];
    self.titles = [NSDictionary dictionaryWithObjectsAndKeys:
                   @"Info", [NSNumber numberWithInt:14],
                   @"Info", [NSNumber numberWithInt:15],
                   nil];

    // Array of (backgroundColor, textColor) pairs.
    // NSNull for either means leave as default.
    // A color scheme will be picked randomly per CMPopTipView.
    self.colorSchemes = [NSArray arrayWithObjects:
                         [NSArray arrayWithObjects:[NSNull null], [NSNull null], nil],
                         [NSArray arrayWithObjects:[UIColor colorWithRed:134.0/255.0 green:74.0/255.0 blue:110.0/255.0 alpha:1.0], [NSNull null], nil],
                         [NSArray arrayWithObjects:[UIColor darkGrayColor], [NSNull null], nil],
                         [NSArray arrayWithObjects:[UIColor lightGrayColor], [UIColor darkTextColor], nil],
                         [NSArray arrayWithObjects:[UIColor orangeColor], [UIColor blueColor], nil],
                         [NSArray arrayWithObjects:[UIColor colorWithRed:220.0/255.0 green:0.0/255.0 blue:0.0/255.0 alpha:1.0], [NSNull null], nil],
                         nil];

}



#pragma mark - PopView Controller

- (void)dismissAllPopTipViews
{
    while ([self.visiblePopTipViews count] > 0) {
        CMPopTipView *popTipView = [self.visiblePopTipViews objectAtIndex:0];
        [popTipView dismissAnimated:YES];
        [self.visiblePopTipViews removeObjectAtIndex:0];
    }
}

- (IBAction)openPopUp:(id)sender
{
    [self dismissAllPopTipViews];

    if (sender == self.currentPopTipViewTarget) {
        // Dismiss the popTipView and that is all
        self.currentPopTipViewTarget = nil;
    }
    else {
        NSString *contentMessage = nil;
        UIView *contentView = nil;
        NSNumber *key = [NSNumber numberWithInteger:[(UIView *)sender tag]];
        id content = [self.contents objectForKey:key];
        if ([content isKindOfClass:[UIView class]]) {
            contentView = content;
        }
        else if ([content isKindOfClass:[NSString class]]) {
            contentMessage = content;
        }
        else {
            contentMessage = @"A CMPopTipView can automatically point to any view or bar button item.";
        }
        NSArray *colorScheme = [self.colorSchemes objectAtIndex:3];
        UIColor *backgroundColor = [colorScheme objectAtIndex:0];
        UIColor *textColor = [colorScheme objectAtIndex:1];

        NSString *title = [self.titles objectForKey:key];

        CMPopTipView *popTipView;
        if (contentView) {
            popTipView = [[CMPopTipView alloc] initWithCustomView:contentView];
        }
        else if (title) {
            popTipView = [[CMPopTipView alloc] initWithTitle:title message:contentMessage];
        }
        else {
            popTipView = [[CMPopTipView alloc] initWithMessage:contentMessage];
        }
        popTipView.delegate = self;

        /* Some options to try.
         */
        //popTipView.disableTapToDismiss = YES;
        //popTipView.preferredPointDirection = PointDirectionUp;
        //popTipView.hasGradientBackground = NO;
        //popTipView.cornerRadius = 2.0;
        //popTipView.sidePadding = 30.0f;
        //popTipView.topMargin = 20.0f;
        //popTipView.pointerSize = 50.0f;
        //popTipView.hasShadow = NO;

        if (backgroundColor && ![backgroundColor isEqual:[NSNull null]]) {
            popTipView.backgroundColor = backgroundColor;
        }
        if (textColor && ![textColor isEqual:[NSNull null]]) {
            popTipView.textColor = textColor;
        }

        popTipView.animation = arc4random() % 2;
        popTipView.has3DStyle = (BOOL)(arc4random() % 2);

        popTipView.dismissTapAnywhere = YES;
        [popTipView autoDismissAnimated:YES atTimeInterval:3.0];

        if ([sender isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)sender;
            [popTipView presentPointingAtView:button inView:self.view animated:YES];
        }
        else {
            UIBarButtonItem *barButtonItem = (UIBarButtonItem *)sender;
            [popTipView presentPointingAtBarButtonItem:barButtonItem animated:YES];
        }

        [self.visiblePopTipViews addObject:popTipView];
        self.currentPopTipViewTarget = sender;
    }
}


#pragma mark - CMPopTipViewDelegate methods

- (void)popTipViewWasDismissedByUser:(CMPopTipView *)popTipView
{
    [self.visiblePopTipViews removeObject:popTipView];
    self.currentPopTipViewTarget = nil;
}


#pragma mark - UIViewController methods

- (void)willAnimateRotationToInterfaceOrientation:(__unused UIInterfaceOrientation)toInterfaceOrientation duration:(__unused NSTimeInterval)duration
{
    for (CMPopTipView *popTipView in self.visiblePopTipViews) {
        id targetObject = popTipView.targetObject;
        [popTipView dismissAnimated:NO];

        if ([targetObject isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)targetObject;
            [popTipView presentPointingAtView:button inView:self.view animated:NO];
        }
        else {
            UIBarButtonItem *barButtonItem = (UIBarButtonItem *)targetObject;
            [popTipView presentPointingAtBarButtonItem:barButtonItem animated:NO];
        }
    }
}

- (IBAction)pingGoogle:(id)sender {

    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setHTTPMethod:@"GET"];
    [request setURL:[NSURL URLWithString:@"http://www.google.com"]];
    NSError *error = [[NSError alloc] init];
    NSHTTPURLResponse *responseCode = nil;
    [NSURLConnection sendSynchronousRequest:request returningResponse:&responseCode error:&error];
    long responsecode = [responseCode statusCode];
    NSString *ouput = [NSString stringWithFormat:@" Status Code: %lu",responsecode];
    NSLog(@"output %@",ouput);
    [_lStatus setText:ouput];
}



@end
