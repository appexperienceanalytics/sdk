//
//  MyNetworkNSURLConnectionDelegate.m
//  CAMSMDemo
//
//  Created by Nilesh on 3/27/15.
//  Copyright (c) 2015 CA Technologies, Inc. All rights reserved.
//

#import "MyNetworkNSURLConnectionDelegate.h"
#import "MyNetwokProtocol.h"

@interface MyNetworkNSURLConnectDelegate : NSObject
@property (nonatomic,strong) NSURLResponse *response;
@property (nonatomic,strong) id<MyNetworkProtocolDelegate> delegate;

- (id)initWithNetworkApiDelegate:(id<MyNetworkProtocolDelegate>)delegate;
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error;
- (void)connectionDidFinishLoading:(NSURLConnection *)connection;
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response;
@end

@implementation MyNetworkNSURLConnectionDelegate
- (void)performRequest:(NSURLRequest *)request onQueue:(NSOperationQueue *)queue;
{
    MyNetworkNSURLConnectDelegate *delegate = [[MyNetworkNSURLConnectDelegate alloc] initWithNetworkApiDelegate:self.delegate];
    NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:request
                                                            delegate:delegate
                                                    startImmediately:NO];
    [conn setDelegateQueue:queue];
    [conn start];
}

@end

@implementation MyNetworkNSURLConnectDelegate

- (id)initWithNetworkApiDelegate:(id<MyNetworkProtocolDelegate>)delegate{
    self = [super init];
    if (self) {
        _delegate = delegate;
    }
    return self;
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    [_delegate requestCompletedWithResponse:_response andError:error];

}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection{
    [_delegate requestCompletedWithResponse:_response andError:nil];
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
     _response = response;
}


@end
