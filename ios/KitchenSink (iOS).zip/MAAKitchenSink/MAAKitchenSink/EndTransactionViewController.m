//
//  EndTransactionViewController.m
//  MAAKitchenSink
//
//  Created by Nilesh Agrawal on 6/27/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//
//TAG:DECTRAINING
//#import "CAMDOReporter.h"

#import "EndTransactionViewController.h"
#import "UIColor+BFPaperColors.h"
//#import <CAMobileAppAnalytics/CAMDOReporter.h>
#import "APIViewController.h"

@interface EndTransactionViewController ()<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UIButton *bEndTransaction;

@property (weak, nonatomic) IBOutlet UITextField *endTransactionTextField;

@property (weak, nonatomic) IBOutlet UIView *endTransaction;
@end

@implementation EndTransactionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self SetupView];
    
}

-(void)SetupView{
    [_endTransaction setBackgroundColor:[UIColor paperColorBlue500]];
    [_bEndTransaction setBackgroundColor:[UIColor paperColorBlue500]];
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)endTransaction:(id)sender {
    
//    
//    for(UIViewController *viewController in self.navigationController.viewControllers){
//        NSLog(@"-> %@ ->",viewController);
//    }

    
//    if(![_endTransactionTextField.text isEqualToString:@""]){
////        [CAMDOReporter stopApplicationTransactionWithName:_endTransactionTextField.text completionHandler:^(BOOL completed, NSError *error) {
//            
//        }];
            [self.navigationController popToRootViewControllerAnimated:YES];
       
//    }
}


@end
