//
//  UIView+ViewEffects.h
//  MAAKitchenSink
//
//  Created by Nilesh on 4/21/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (ViewEffects)
-(void)hideIgnoreView;
-(void)setupPartitionView;
-(void)setUpTransperantViewBlackBorder;
-(void)setSqaureView;
-(void) makeSquareTransperant;
@end


