//
//  MyNetwokProtocol.h
//  CAMSMDemo
//
//  Created by Nilesh on 3/27/15.
//  Copyright (c) 2015 CA Technologies, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol MyNetworkProtocolDelegate
-(void)requestCompletedWithResponse:(NSURLResponse *)response
                           andError:(NSError *)error;
@end

@interface MyNetwokProtocol : NSObject

@property (nonatomic, strong) id<MyNetworkProtocolDelegate> delegate;
- (id)initWithDelegate:(id<MyNetworkProtocolDelegate>)delegate;
- (void)performRequest:(NSURLRequest *)request onQueue:(NSOperationQueue *)queue;
@end
