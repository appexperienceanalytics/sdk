//
//  ViewController.m
//  WKWebViewSample
//
//  Created by Suman Cherukuri on 8/24/15.
//  Copyright (c) 2015 CA Inc. All rights reserved.
//

#import "WKWebViewController.h"

@interface WKWebViewController ()
@property (strong, nonatomic) WKWebView *webView;
@end

@implementation WKWebViewController

#pragma mark - View Controller Methods
- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadWKWebView];
}


#pragma mark - WKWebView Methods
-(void)loadWKWebView{
    WKWebViewConfiguration *configuration = [[WKWebViewConfiguration alloc] init];
    WKUserContentController *controller = [[WKUserContentController alloc] init];
    configuration.userContentController = controller;
    
    NSURL *url = [[NSBundle mainBundle] URLForResource:@"index" withExtension:@"html"];
    _webView = [[WKWebView alloc] initWithFrame:self.view.frame configuration:configuration];
    [_webView setUIDelegate:self];
    [_webView loadRequest:[NSURLRequest requestWithURL:url]];
    [self.view addSubview:_webView];
}

- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    if ([message.name isEqualToString:@"camaa"]) {
        @try {
            NSLog(@"Received event %@", message.body);
            
            NSDictionary *data = message.body;
            NSString *action = [data objectForKey:@"action"];
            
            if (action == nil) {
                NSLog(@"Reeived nil action from JS.  returning...");
                return;
            }
            if ([action caseInsensitiveCompare:@"setSessionInfo"] == NSOrderedSame) {
                NSString *type = [data objectForKey:@"type"];
                NSString *name = [data objectForKey:@"name"];
                NSString *value = [data objectForKey:@"value"];
                if (type == nil || name == nil || value == nil) {
                    NSLog(@"Insufficient data for setSessionInfo: type=%@, name=%@, value=%@", type, name, value);
                    return;
                }
            }
            
            // check if we need to callback into JS
            NSString *callback = [data objectForKey:@"callback"];
            if (callback != nil) {
                NSString *jsTemplate = @"%@(\"%@\", \"%@\");";
                NSString *jsCall = [NSString stringWithFormat:jsTemplate, callback, action, @"true"];
                [_webView evaluateJavaScript:jsCall completionHandler:nil];
            }
        }
        @catch(NSException *e) {
            
        }
    }
}

- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)())completionHandler
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:message
                                                                             message:nil
                                                                      preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:@"OK"
                                                        style:UIAlertActionStyleCancel
                                                      handler:^(UIAlertAction *action) {
                                                          completionHandler();
                                                      }]];
    [self presentViewController:alertController animated:YES completion:^{}];
}
@end
