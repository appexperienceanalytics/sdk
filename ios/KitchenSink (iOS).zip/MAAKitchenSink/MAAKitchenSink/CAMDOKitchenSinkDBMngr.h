//
//  CAMDOKitchenSinkDBMngr.h
//  CAMobileAppAnalytics
//
//  Created by Nilesh on 3/7/16.
//  Copyright © 2016 CA Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CAMDOKitchenSinkDBMngr : NSObject
+ (CAMDOKitchenSinkDBMngr *) sharedDatabase;
-(void)addTestDataWithTestName:(NSString *)testData withTester:(NSString *)tester;


@end
