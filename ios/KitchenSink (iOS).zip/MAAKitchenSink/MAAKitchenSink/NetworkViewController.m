//
//  SecondViewController.m
//  CAMAADemoApp
//
//  Created by Nilesh on 4/4/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import "NetworkViewController.h"
#import "MyNetwokProtocol.h"
#import "MyNetworkConnectionWithAsyncHandler.h"
#import "MyNetworkNSURLConnectionDelegate.h"
#import "MyNetworkSessionDataTaskWithDelegate.h"
#import "MyNetworkSessionDataTaskWithHandler.h"
#import "MyNetworkSessionDelegate.h"
#import "MyNetworkSessionDownloadTaskWithHandler.h"
#import "MyNetworkSyncHandler.h"
#import "CMPopTipView.h"
#import "UIView+ViewEffects.h"
//#import "UIButton+ButtonEffects.h"
#import "UILabel+LabelEffects.h"
#import "FXBlurView.h"
#import "UIColor+BFPaperColors.h"
#import "BFPaperButton.h"
#import "TNRectangularRadioButtonData.h"
#import "TNRadioButtonGroup.h"
#import "FUIAlertView.h"
#import "UIColor+FlatUI.h"
#import "UIFont+FlatUI.h"


#define foo4random() (1.0 * (arc4random() % ((unsigned)RAND_MAX + 1)) / RAND_MAX)
static const CGFloat KEYBOARD_ANIMATION_DURATION = 0.3;
static const CGFloat MINIMUM_SCROLL_FRACTION = 0.2;
static const CGFloat MAXIMUM_SCROLL_FRACTION = 0.8;
static const CGFloat PORTRAIT_KEYBOARD_HEIGHT = 216;
static const CGFloat LANDSCAPE_KEYBOARD_HEIGHT = 162;

@interface NetworkViewController ()<UIAlertViewDelegate>
@property (weak, nonatomic) IBOutlet FXBlurView *blurView;

@property (weak, nonatomic) IBOutlet UIView *view5;
@property (weak, nonatomic) IBOutlet UIView *view6;

/* Views */
@property (weak, nonatomic) IBOutlet UIView *vprotocolView;
@property (weak, nonatomic) IBOutlet UIView *vGETPOSTRequest;

/* Labels */
@property (weak, nonatomic) IBOutlet UILabel *lprotocols;
@property (weak, nonatomic) IBOutlet UILabel *lconnectionType;
@property (weak, nonatomic) IBOutlet UILabel *lDataSize;
@property (weak, nonatomic) IBOutlet UILabel *lGETLabel;
@property (weak, nonatomic) IBOutlet UILabel *lPostLabel;
@property (weak, nonatomic) IBOutlet UILabel *lOutputConsoleTitle;
@property (weak, nonatomic) IBOutlet UILabel *lStatusCode;

/* TextView */
@property (weak, nonatomic) IBOutlet UITextView *ConsoleTextView;


/* -------- Buttons */
@property (weak, nonatomic) IBOutlet BFPaperButton *get1KB;
@property (weak, nonatomic) IBOutlet BFPaperButton *get10KB;
@property (weak, nonatomic) IBOutlet BFPaperButton *get100KB;
@property (weak, nonatomic) IBOutlet BFPaperButton *get1MB;
@property (weak, nonatomic) IBOutlet BFPaperButton *post1KB;
@property (weak, nonatomic) IBOutlet BFPaperButton *post10KB;
@property (weak, nonatomic) IBOutlet BFPaperButton *post100KB;
@property (weak, nonatomic) IBOutlet BFPaperButton *post1MB;
@property (weak, nonatomic) IBOutlet BFPaperButton *bGet;
@property (weak, nonatomic) IBOutlet BFPaperButton *bSelectNetwork;




/* -------- PickerView */
@property (weak, nonatomic) IBOutlet UIPickerView *connectionPickerView;
/* -------- SegmentControl */
@property (weak, nonatomic) IBOutlet UISegmentedControl *httpProcotoclSegment;
/* -------- Text Field URL*/
@property (weak, nonatomic) IBOutlet UITextField *tfURLField;


/* ---- Class Properties------*/
@property (nonatomic,retain) NSURLConnection *conn;
@property (nonatomic,retain) NSString *protocol;
@property (nonatomic, strong) NSArray *networkAPIs;


@property (nonatomic,strong) NSString *httpString;
@property (nonatomic,strong) NSString *dataSizeString;
@property (nonatomic,strong) NSString *connectionString;
@property (nonatomic,strong) NSString *requestString;

@property (nonatomic, strong) NSOperationQueue *queue;
@property (nonatomic) NSInteger updatedRowIndex;
@property (nonatomic,strong) NSMutableString *output;
@property NSArray *pickerData;

/*private class method */
-(void)updateTextView;

/*Pop View Controller */
@property (nonatomic, strong)	NSArray			*colorSchemes;
@property (nonatomic, strong)	NSDictionary	*contents;
@property (nonatomic, strong)	id				currentPopTipViewTarget;
@property (nonatomic, strong)	NSDictionary	*titles;
@property (nonatomic, strong)	NSMutableArray	*visiblePopTipViews;



@property (nonatomic, strong) TNRadioButtonGroup *requestGroup;
@property (nonatomic,strong) TNRadioButtonGroup *dataSizeGroup;
@property (nonatomic,strong) TNRadioButtonGroup *protocolGroup;
@property (nonatomic,strong) TNRadioButtonGroup *connectionGroup;

@property (weak, nonatomic) IBOutlet UIView *networkTitleView;

/*Radio Views */
@property (weak, nonatomic) IBOutlet UIView *dataSizeView;
@property (weak, nonatomic) IBOutlet UIView *requestTypeView;
@property (weak, nonatomic) IBOutlet UIView *connectionView;
@property (weak, nonatomic) IBOutlet UIView *protocolView;

@property (weak, nonatomic) IBOutlet BFPaperButton *bMakeRequest;



/* Animated Distance*/
@property CGFloat animatedDistance;



/*Views*/



@end


@implementation NetworkViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    // Do any additional setup after loading the view, typically from a nib.
    //[self setupBlurBackground];


    [self setupView];

    _pickerData = @[@"[NSURLConnection connectionWithRequest]",@"[NSURLConnection sendAsynchronousRequest]",@"[NSURLConnection sendSynchronousRequest]",@"[NSURLSession dataTask]",@"[NSURLSession downloadTask]",@"[NSURLSession dataTask:WithDelegate]"];

        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 1;

    _networkAPIs = @[
                     [[MyNetworkNSURLConnectionDelegate alloc] initWithDelegate:self],
                     [[MyNetworkConnectionWithAsyncHandler alloc] initWithDelegate:self],
                     [[MyNetworkSyncHandler alloc] initWithDelegate:self],
                     [[MyNetworkSessionDataTaskWithHandler alloc] initWithDelegate:self],
                     [[MyNetworkSessionDownloadTaskWithHandler alloc] initWithDelegate:self],
                     [[MyNetworkSessionDataTaskWithDelegate alloc] initWithDelegate:self]
                     ];

    _protocol = @"http";


    _tfURLField.delegate = self;
    self.connectionPickerView.dataSource = self;
    self.connectionPickerView.delegate = self;
    
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];

    _updatedRowIndex = 0;
    _httpString = @"http";
    _requestString = @"GET";
    _dataSizeString = @"1KB";
    
}
-(void)setupView{
    
    /*Title Bar */
    [_networkTitleView setBackgroundColor:[UIColor paperColorBlue]];
    
    /*Setup the View */
    [_vprotocolView setUpTransperantViewBlackBorder];
    [_vGETPOSTRequest setUpTransperantViewBlackBorder];
    
    [_protocolView setBackgroundColor:[UIColor whiteColor]];
    [_requestTypeView setBackgroundColor:[UIColor whiteColor]];
    [_view5 setBackgroundColor:[UIColor whiteColor]];
    [_view6 setBackgroundColor:[UIColor whiteColor]];
    
    /* Remove the unwanted Views*/
    [self makePaperButton:_bGet];
    [self makePaperButton:_bMakeRequest];
    /*PopViewcontrollers*/
    [self setupPopViewController];
    
    /*Labels*/
    [_lprotocols makeLabelBlack];
    [_lconnectionType makeLabelBlack];
    [_lDataSize makeLabelBlack];
    [_lGETLabel makeLabelBlack];
    [_lPostLabel makeLabelBlack];
    [_lOutputConsoleTitle makeLabelBlack];
    [_lStatusCode makeLabelBlack];

    /*Segment */
    [_httpProcotoclSegment setTintColor:[UIColor blackColor]];
    [_requestTypeView addSubview:[self addRequestTypeGroup]];
    [_dataSizeView addSubview:[self addDataSizeTypeGroup]];
    [_connectionView addSubview:[self addConnectionType]];
    [_protocolView addSubview:[self addProtocolGroup]];
    
   /// [self setFloatingTextField:_tfURLField];
    
}


#pragma mark - network methods
- (void) performCommand:(NSString *)command withDataSize:(NSString *)dataSize
{
    NSString *action = command;
    NSString *modifier = dataSize;

    //GET
    //http://httpbin.org/bytes/:n

    //POST
    //http://httpbin.org/post

    //GET delay
    //http://httpbin.org/delay/:n

    //GET codes
    //http://httpbin.org/status/:code

    NSLog(@"ACTION = %@, MODIFIER = %@", action, modifier);

    NSString *url = @"";
    long bytes = 1;
    //int latency = 0;
    //TODO: Need to work on this...
    //NSString *http = [self.protocol lowercaseString];

    if([dataSize isEqualToString:@"1KB"]){
        bytes = 1024;
    }else if([dataSize isEqualToString:@"10KB"]){
        bytes = 1024 *10;
    }else if ([dataSize isEqualToString:@"100KB"]){
        bytes = 1024 *100;
    }else if([dataSize isEqualToString:@"1MB"]){
        bytes = 1024 *1000;
    }

    NSString *http = _httpString;

    if([action isEqualToString:@"GET"] || [action isEqualToString:@"POST"] )
    {
        if([action isEqualToString:@"GET"])
        {
            url = [NSString stringWithFormat:@"%@://httpbin.org/bytes/%lu",http,  bytes];
        }
        else
        {
            url = [NSString stringWithFormat:@"%@://httpbin.org/post", http];
        }
    }

    //    else if([action isEqualToString:@"Do"])
    //    {
    //        url = [NSString stringWithFormat:@"%@://httpbin.org/status/%@",http, modifier];
    //        action = @"GET";
    //    }

    NSLog(@"URL = %@", url);
    NSLog(@"action = %@", action);
    NSLog(@"Bytes = %lu", bytes);

    NSMutableURLRequest *reg = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    if([action isEqualToString:@"POST"])
    {
        [reg setHTTPMethod:@"POST"];

        if(bytes == 1)
        {
            [reg setHTTPBody:[@"HELLO WORLD" dataUsingEncoding:NSUTF8StringEncoding]];
        }
        else
        {
            NSMutableData* theData = [NSMutableData dataWithCapacity:bytes];
            for( unsigned int i = 0 ; i < bytes/4 ; ++i )
            {
                u_int32_t randomBits = arc4random();
                [theData appendBytes:(void*)&randomBits length:4];
            }
            [reg setHTTPBody:theData];
        }
    }

    [[self selectedNetworkApi] performRequest:reg onQueue:_queue];
}


- (MyNetwokProtocol *)selectedNetworkApi
{
    NSInteger  index = _updatedRowIndex;
    return _networkAPIs[(int)index];
}

-(void)requestCompletedWithResponse:(NSURLResponse *)response andError:(NSError *)error{

    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
    NSString *outputView = nil;

    if (!error) {
        outputView = [NSString stringWithFormat:@" URL : %@\n(Status : %@)",
                  httpResponse.URL,@(httpResponse.statusCode)];
    } else {
        outputView = [NSString stringWithFormat:@"(err %@) %@\n", httpResponse.URL,
                      @(error.code)];
    }
    
    NSLog(@"%@", outputView);
   // _ConsoleTextView.text = output;
    _output = [outputView mutableCopy];

    @synchronized(_output){
        [self performSelectorOnMainThread:@selector(updateTextView) withObject:nil waitUntilDone:NO];
    }
}


-(void)updateTextView{
    _ConsoleTextView.text = _output;
}

#pragma mark - AlertView Delegate
- (void)alertView:(UIAlertView *)alertView
clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex ==0){
        
    }else if(buttonIndex ==1){
        
    }else if(buttonIndex == 2){
        
    }else if(buttonIndex ==3){
        
    }else if(buttonIndex ==4){
        
    }
}


#pragma mark - TextField Delegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [_tfURLField resignFirstResponder];
    return YES;
}


- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    
    
    CGRect textFieldRect =
    [self.view.window convertRect:textField.bounds fromView:textField];
    CGRect viewRect =
    [self.view.window convertRect:self.view.bounds fromView:self.view];
    CGFloat midline = textFieldRect.origin.y + 0.5 * textFieldRect.size.height;
    CGFloat numerator =
    midline - viewRect.origin.y
    - MINIMUM_SCROLL_FRACTION * viewRect.size.height;
    CGFloat denominator =
    (MAXIMUM_SCROLL_FRACTION - MINIMUM_SCROLL_FRACTION)
    * viewRect.size.height;
    CGFloat heightFraction = numerator / denominator;
    if (heightFraction < 0.0)
    {
        heightFraction = 0.0;
    }
    else if (heightFraction > 1.0)
    {
        heightFraction = 1.0;
    }
    UIInterfaceOrientation orientation =
    [[UIApplication sharedApplication] statusBarOrientation];
    if (orientation == UIInterfaceOrientationPortrait ||
        orientation == UIInterfaceOrientationPortraitUpsideDown)
    {
        _animatedDistance = floor(PORTRAIT_KEYBOARD_HEIGHT * heightFraction);
    }
    else
    {
        _animatedDistance = floor(LANDSCAPE_KEYBOARD_HEIGHT * heightFraction);
    }
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y -= _animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [self.view setFrame:viewFrame];
    [UIView commitAnimations];
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y += _animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    [self.view setFrame:viewFrame];
    [UIView commitAnimations];
}


#pragma mark - IBAction Methods.
- (IBAction)selectConnectionOnSegment:(id)sender {

    if([_httpProcotoclSegment selectedSegmentIndex]==0){
        _protocol = @"http";
    }else{
        _protocol = @"https";
    }
}




- (BOOL) validateHttpUrl: (NSString *) candidate {
    NSString *urlRegEx =
    @"(http|https)://((\\w)*|([0-9]*)|([-|_])*)+([\\.|/]((\\w)*|([0-9]*)|([-|_])*))+";
    NSPredicate *urlTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", urlRegEx];
    return [urlTest evaluateWithObject:candidate];
}

- (BOOL) validateWWWUrl: (NSString *) candidate {

    NSString *urlRegEx =  @"(www\\.)[\\w\\d\\-_]+\\.\\w{2,3}(\\.\\w{2})?(/(?<=/)(?:[\\w\\d\\-./_]+)?)?";
    NSPredicate *urlTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", urlRegEx];
    return [urlTest evaluateWithObject:candidate];
}

-(BOOL)validateUrl{


    if([self validateHttpUrl:_tfURLField.text]){
        return true;
    }

    if(![_tfURLField.text containsString:@"http://"] && [self validateWWWUrl:_tfURLField.text]){
        _tfURLField.text = [@"http://" stringByAppendingString:_tfURLField.text];
        return true;
    }

    if(![_tfURLField.text containsString:@"https://"] && ![self validateWWWUrl:_tfURLField.text]){
        _tfURLField.text = [@"https://www." stringByAppendingString:_tfURLField.text];
        return true;
    }

    return false;
}
- (IBAction)GetRequest:(id)sender {


    [_ConsoleTextView setText:@"Status code :0"];
    if([self validateUrl]){
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setHTTPMethod:@"GET"];
    [request setURL:[NSURL URLWithString:_tfURLField.text]];
    NSError *error = [[NSError alloc] init];
    NSHTTPURLResponse *responseCode = nil;
    [NSURLConnection sendSynchronousRequest:request returningResponse:&responseCode error:&error];
    long responsecode = [responseCode statusCode];
    NSString *ouput = [NSString stringWithFormat:@"Status Code : %lu",responsecode];
    [_ConsoleTextView setText:ouput];
    }
}



#pragma mark - UIViewController Methods.

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma  mark - PopView 


-(void)setupPopViewController{
    self.visiblePopTipViews = [NSMutableArray array];

    self.contents = [NSDictionary dictionaryWithObjectsAndKeys:
                     // Rounded rect buttons
                     @"Follow the steps below : \n 1. Select Protocol \n 2. Select Connection Type \n 3. Select Request Type with Data Size and view the output on the console", [NSNumber numberWithInt:4],
                     @"Enter the url and send a GET Request", [NSNumber numberWithInt:5],
                     @"Console.", [NSNumber numberWithInt:6],
                     nil];
    self.titles = [NSDictionary dictionaryWithObjectsAndKeys:
                   @"Info", [NSNumber numberWithInt:4],
                   @"Info", [NSNumber numberWithInt:5],
                   @"Info", [NSNumber numberWithInt:6],
                   nil];

    // Array of (backgroundColor, textColor) pairs.
    // NSNull for either means leave as default.
    // A color scheme will be picked randomly per CMPopTipView.
    self.colorSchemes = [NSArray arrayWithObjects:
                         [NSArray arrayWithObjects:[NSNull null], [NSNull null], nil],
                         [NSArray arrayWithObjects:[UIColor colorWithRed:134.0/255.0 green:74.0/255.0 blue:110.0/255.0 alpha:1.0], [NSNull null], nil],
                         [NSArray arrayWithObjects:[UIColor darkGrayColor], [NSNull null], nil],
                         [NSArray arrayWithObjects:[UIColor lightGrayColor], [UIColor darkTextColor], nil],
                         [NSArray arrayWithObjects:[UIColor orangeColor], [UIColor blueColor], nil],
                         [NSArray arrayWithObjects:[UIColor colorWithRed:220.0/255.0 green:0.0/255.0 blue:0.0/255.0 alpha:1.0], [NSNull null], nil],
                         nil];

}



#pragma mark - PopView Controller

- (void)dismissAllPopTipViews
{
    while ([self.visiblePopTipViews count] > 0) {
        CMPopTipView *popTipView = [self.visiblePopTipViews objectAtIndex:0];
        [popTipView dismissAnimated:YES];
        [self.visiblePopTipViews removeObjectAtIndex:0];
    }
}

- (IBAction)openPopUp:(id)sender
{
    [self dismissAllPopTipViews];

    if (sender == self.currentPopTipViewTarget) {
        // Dismiss the popTipView and that is all
        self.currentPopTipViewTarget = nil;
    }
    else {
        NSString *contentMessage = nil;
        UIView *contentView = nil;
        NSNumber *key = [NSNumber numberWithInteger:[(UIView *)sender tag]];
        id content = [self.contents objectForKey:key];
        if ([content isKindOfClass:[UIView class]]) {
            contentView = content;
        }
        else if ([content isKindOfClass:[NSString class]]) {
            contentMessage = content;
        }
        else {
            contentMessage = @"A CMPopTipView can automatically point to any view or bar button item.";
        }
        NSArray *colorScheme = [self.colorSchemes objectAtIndex:3];
        UIColor *backgroundColor = [colorScheme objectAtIndex:0];
        UIColor *textColor = [colorScheme objectAtIndex:1];

        NSString *title = [self.titles objectForKey:key];

        CMPopTipView *popTipView;
        if (contentView) {
            popTipView = [[CMPopTipView alloc] initWithCustomView:contentView];
        }
        else if (title) {
            popTipView = [[CMPopTipView alloc] initWithTitle:title message:contentMessage];
        }
        else {
            popTipView = [[CMPopTipView alloc] initWithMessage:contentMessage];
        }
        popTipView.delegate = self;

        /* Some options to try.
         */
        //popTipView.disableTapToDismiss = YES;
        //popTipView.preferredPointDirection = PointDirectionUp;
        //popTipView.hasGradientBackground = NO;
        //popTipView.cornerRadius = 2.0;
        //popTipView.sidePadding = 30.0f;
        //popTipView.topMargin = 20.0f;
        //popTipView.pointerSize = 50.0f;
        //popTipView.hasShadow = NO;

        if (backgroundColor && ![backgroundColor isEqual:[NSNull null]]) {
            popTipView.backgroundColor = backgroundColor;
        }
        if (textColor && ![textColor isEqual:[NSNull null]]) {
            popTipView.textColor = textColor;
        }

        popTipView.animation = arc4random() % 2;
        popTipView.has3DStyle = (BOOL)(arc4random() % 2);

        popTipView.dismissTapAnywhere = YES;
        [popTipView autoDismissAnimated:YES atTimeInterval:3.0];

        if ([sender isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)sender;
            [popTipView presentPointingAtView:button inView:self.view animated:YES];
        }
        else {
            UIBarButtonItem *barButtonItem = (UIBarButtonItem *)sender;
            [popTipView presentPointingAtBarButtonItem:barButtonItem animated:YES];
        }

        [self.visiblePopTipViews addObject:popTipView];
        self.currentPopTipViewTarget = sender;
    }
}


#pragma mark - CMPopTipViewDelegate methods

- (void)popTipViewWasDismissedByUser:(CMPopTipView *)popTipView
{
    [self.visiblePopTipViews removeObject:popTipView];
    self.currentPopTipViewTarget = nil;
}


#pragma mark - UIViewController methods

- (void)willAnimateRotationToInterfaceOrientation:(__unused UIInterfaceOrientation)toInterfaceOrientation duration:(__unused NSTimeInterval)duration
{
    for (CMPopTipView *popTipView in self.visiblePopTipViews) {
        id targetObject = popTipView.targetObject;
        [popTipView dismissAnimated:NO];

        if ([targetObject isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)targetObject;
            [popTipView presentPointingAtView:button inView:self.view animated:NO];
        }
        else {
            UIBarButtonItem *barButtonItem = (UIBarButtonItem *)targetObject;
            [popTipView presentPointingAtBarButtonItem:barButtonItem animated:NO];
        }
    }
}

#pragma mark - BFPaperMethods.
-(void)makePaperButton:(BFPaperButton *)button{
    button.backgroundColor = [UIColor paperColorBlue];
    button.isRaised=YES;
    button.cornerRadius =5;
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
}

#pragma mark - Radio Button Methods 
-(UIView *)addRequestTypeGroup{
    
    TNRectangularRadioButtonData *getButton= [TNRectangularRadioButtonData new];
    getButton.labelText = @"Get";
    getButton.identifier = @"GET";
    getButton.selected = YES;
    getButton.borderColor = [UIColor blackColor];
    getButton.rectangleColor = [UIColor blackColor];
    getButton.borderWidth =getButton.borderHeight = 12;
    getButton.rectangleWidth = getButton.rectangleHeight = 5;
    
    TNRectangularRadioButtonData *postButton= [TNRectangularRadioButtonData new];
    postButton.labelText = @"Post";
    postButton.identifier = @"POST";
    postButton.selected = NO;
    postButton.borderColor = [UIColor blackColor];
    postButton.rectangleColor = [UIColor blackColor];
    postButton.borderWidth = postButton.borderHeight = 12;
    postButton.rectangleWidth = postButton.rectangleHeight = 5;
    

    
    self.requestGroup = [[TNRadioButtonGroup alloc] initWithRadioButtonData:@[getButton,postButton] layout:TNRadioButtonGroupLayoutHorizontal];
    self.requestGroup.identifier = @"Hobbies group";
    [self.requestGroup create];
    self.requestGroup.position = CGPointMake(0, self.requestTypeView.bounds.size.height/2);
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(requestGroupUpdated:) name:SELECTED_RADIO_BUTTON_CHANGED object:self.requestGroup];
    
    return self.requestGroup;
    
}

-(UIView *)addDataSizeTypeGroup{
    
    TNRectangularRadioButtonData *b1KB= [TNRectangularRadioButtonData new];
    b1KB.labelText = @"1KB";
    b1KB.identifier = @"1KB";
    b1KB.selected = YES;
    b1KB.borderColor = [UIColor blackColor];
    b1KB.rectangleColor = [UIColor blackColor];
    b1KB.borderWidth =b1KB.borderHeight = 12;
    b1KB.rectangleWidth = b1KB.rectangleHeight = 5;
    
    TNRectangularRadioButtonData *b10KB= [TNRectangularRadioButtonData new];
    b10KB.labelText = @"10KB";
    b10KB.identifier = @"10KB";
    b10KB.selected = NO;
    b10KB.borderColor = [UIColor blackColor];
    b10KB.rectangleColor = [UIColor blackColor];
    b10KB.borderWidth = b10KB.borderHeight = 12;
    b10KB.rectangleWidth = b10KB.rectangleHeight = 5;
    
    TNRectangularRadioButtonData *b100KB= [TNRectangularRadioButtonData new];
    b100KB.labelText = @"100KB";
    b100KB.identifier = @"100KB";
    b100KB.selected = NO;
    b100KB.borderColor = [UIColor blackColor];
    b100KB.rectangleColor = [UIColor blackColor];
    b100KB.borderWidth = b100KB.borderHeight = 12;
    b100KB.rectangleWidth = b100KB.rectangleHeight = 5;
    
    TNRectangularRadioButtonData *b1MB= [TNRectangularRadioButtonData new];
    b1MB.labelText = @"1MB";
    b1MB.identifier = @"1MB";
    b1MB.selected = NO;
    b1MB.borderColor = [UIColor blackColor];
    b1MB.rectangleColor = [UIColor blackColor];
    b1MB.borderWidth = b1MB.borderHeight = 12;
    b1MB.rectangleWidth = b1MB.rectangleHeight = 5;
    
    
    
    self.dataSizeGroup = [[TNRadioButtonGroup alloc] initWithRadioButtonData:@[b1KB,b10KB,b100KB,b1MB] layout:TNRadioButtonGroupLayoutHorizontal];
    self.dataSizeGroup.identifier = @"dataSizeGroup";
    [self.dataSizeGroup create];
    //  self.requestGroup.position = CGPointMake(25, 265);
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(dataSizeGroupUpdated:) name:SELECTED_RADIO_BUTTON_CHANGED object:self.dataSizeGroup];
    
    return self.dataSizeGroup;
    
}




-(UIView *)addProtocolGroup{
    
    TNRectangularRadioButtonData *b1KB= [TNRectangularRadioButtonData new];
    b1KB.labelText = @"HTTP";
    b1KB.identifier = @"http";
    b1KB.selected = YES;
    b1KB.borderColor = [UIColor blackColor];
    b1KB.rectangleColor = [UIColor blackColor];
    b1KB.borderWidth =b1KB.borderHeight = 12;
    b1KB.rectangleWidth = b1KB.rectangleHeight = 5;
    
    TNRectangularRadioButtonData *b10KB= [TNRectangularRadioButtonData new];
    b10KB.labelText = @"HTTPS";
    b10KB.identifier = @"https";
    b10KB.selected = NO;
    b10KB.borderColor = [UIColor blackColor];
    b10KB.rectangleColor = [UIColor blackColor];
    b10KB.borderWidth = b10KB.borderHeight = 12;
    b10KB.rectangleWidth = b10KB.rectangleHeight = 5;
    
    self.protocolGroup = [[TNRadioButtonGroup alloc] initWithRadioButtonData:@[b1KB,b10KB] layout:TNRadioButtonGroupLayoutHorizontal];
    self.protocolGroup.identifier = @"HTTPGroup";
    [self.protocolGroup create];
    self.protocolGroup.position = CGPointMake(0, _protocolView.bounds.size.height/2);
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(protocolGroupUpdated:) name:SELECTED_RADIO_BUTTON_CHANGED object:self.protocolGroup];
    
    return self.protocolGroup;
}

-(UIView *)addConnectionType{
    TNRectangularRadioButtonData *b1KB= [TNRectangularRadioButtonData new];
    b1KB.labelText = @"NSURL AsynchronousRequest]";
    b1KB.identifier = @"0";
    b1KB.selected = YES;
    b1KB.borderColor = [UIColor blackColor];
    b1KB.rectangleColor = [UIColor blackColor];
    b1KB.borderWidth =b1KB.borderHeight = 12;
    b1KB.rectangleWidth = b1KB.rectangleHeight = 5;
    
    TNRectangularRadioButtonData *b10KB= [TNRectangularRadioButtonData new];
    b10KB.labelText = @"[NSURL SynchRequest]";
    b10KB.identifier = @"1";
    b10KB.selected = NO;
    b10KB.borderColor = [UIColor blackColor];
    b10KB.rectangleColor = [UIColor blackColor];
    b10KB.borderWidth = b10KB.borderHeight = 12;
    b10KB.rectangleWidth = b10KB.rectangleHeight = 5;
    
    TNRectangularRadioButtonData *b100KB= [TNRectangularRadioButtonData new];
    b100KB.labelText = @"[NSURLSession dataTask]";
    b100KB.identifier = @"2";
    b100KB.selected = NO;
    b100KB.borderColor = [UIColor blackColor];
    b100KB.rectangleColor = [UIColor blackColor];
    b100KB.borderWidth = b100KB.borderHeight = 12;
    b100KB.rectangleWidth = b100KB.rectangleHeight = 5;
    
    TNRectangularRadioButtonData *b1MB= [TNRectangularRadioButtonData new];
    b1MB.labelText = @"[NSURLSession downloadTask]";
    b1MB.identifier = @"3";
    b1MB.selected = NO;
    b1MB.borderColor = [UIColor blackColor];
    b1MB.rectangleColor = [UIColor blackColor];
    b1MB.borderWidth = b1MB.borderHeight = 12;
    b1MB.rectangleWidth = b1MB.rectangleHeight = 5;
    
    
    
    self.connectionGroup = [[TNRadioButtonGroup alloc] initWithRadioButtonData:@[b1KB,b10KB,b100KB,b1MB] layout:TNRadioButtonGroupLayoutVertical];
    self.connectionGroup.identifier = @"connectionSizeGroup";
    [self.connectionGroup create];
     self.connectionGroup.position = CGPointMake(0, 0);
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(connectionGroupUpdated:) name:SELECTED_RADIO_BUTTON_CHANGED object:self.connectionGroup];
    
    return self.connectionGroup;
    
}



- (IBAction)makeRequest:(id)sender {
    [self performCommand:_requestString withDataSize:_dataSizeString];
}

- (void)protocolGroupUpdated:(NSNotification *)notification {
    NSLog(@"[MainView] Protocol group updated to %@", self.protocolGroup.selectedRadioButton.data.identifier);
    _httpString =self.protocolGroup.selectedRadioButton.data.identifier;
}
- (void)dataSizeGroupUpdated:(NSNotification *)notification {
    NSLog(@"[MainView] Data group updated to %@", self.dataSizeGroup.selectedRadioButton.data.identifier);
    _dataSizeString =self.dataSizeGroup.selectedRadioButton.data.identifier;
}

- (void)connectionGroupUpdated:(NSNotification *)notification {
    NSLog(@"[MainView] Connection group updated to %@", self.connectionGroup.selectedRadioButton.data.identifier);
    //_updatedRowIndex
    _connectionString =self.connectionGroup.selectedRadioButton.data.identifier;
    if([_connectionString isEqualToString:@"0"]){
        _updatedRowIndex = 0;
    }else if([_connectionString isEqualToString:@"1"]){
        _updatedRowIndex = 1;
    }else if([_connectionString isEqualToString:@"2"]){
        _updatedRowIndex = 2;
    }else if([_connectionString isEqualToString:@"3"]){
        _updatedRowIndex = 3;
    }
    
}
- (void)requestGroupUpdated:(NSNotification *)notification {
    NSLog(@"[MainView] Request group updated to %@", self.requestGroup.selectedRadioButton.data.identifier);
    _requestString =self.requestGroup.selectedRadioButton.data.identifier;
    
}

@end
