//
//  SegmentControlCollectionViewCell.h
//  MAAKitchenSink
//
//  Created by Nilesh Agrawal on 6/27/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BFPaperCollectionViewCell.h"
#import "UIColor+BFPaperColors.h"

@interface SegmentControlCollectionViewCell : BFPaperCollectionViewCell
- (void)customSetup;
@end
