//
//  FirstViewController.m
//  CAMAADemoApp
//
//  Created by Nilesh on 4/4/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import "CrashViewController.h"
//#import <CAMobileAppAnalytics/CAMDOReporter.h>
#import "CMPopTipView.h"
#import "UIView+ViewEffects.h"
#import "UIButton+ButtonEffects.h"
#import "UILabel+LabelEffects.h"
#import "FXBlurView.h"
#import "UIColor+BFPaperColors.h"
#import "BFPaperButton.h"
//#import "CAMDOKitchenSinkDBMngr.h"

//TAG:DECTRAINING
//#import "CAMDOReporter.h"


#define foo4random() (1.0 * (arc4random() % ((unsigned)RAND_MAX + 1)) / RAND_MAX)

@interface CrashViewController ()
@property (weak, nonatomic) IBOutlet FXBlurView *blurView;
@property (weak, nonatomic) IBOutlet UIView *crashTitle;

/*Buttons*/
/*
@property (weak, nonatomic) IBOutlet UIButton *bUncaughtException;
@property (weak, nonatomic) IBOutlet UIButton *bStackOverflowError;
@property (weak, nonatomic) IBOutlet UIButton *bArrayOutOfIndex;
@property (weak, nonatomic) IBOutlet UIButton *bSegmentationFault;
@property (weak, nonatomic) IBOutlet UIButton *bMethodA;
@property (weak, nonatomic) IBOutlet UIButton *bMethodB;
*/

@property (weak, nonatomic) IBOutlet BFPaperButton *bUncaughtException;
@property (weak, nonatomic) IBOutlet BFPaperButton *bSegmentationFault;
@property (weak, nonatomic) IBOutlet BFPaperButton *bStackOverflowError;
@property (weak, nonatomic) IBOutlet BFPaperButton *bArrayOutOfIndex;
@property (weak, nonatomic) IBOutlet BFPaperButton *bMethodA;
@property (weak, nonatomic) IBOutlet BFPaperButton *bMethodB;



/*Info Buttons*/
@property (weak, nonatomic) IBOutlet UIButton *bCrashInfoButton;
@property (weak, nonatomic) IBOutlet UIButton *biOSSymbolicationInfo;
@property (weak, nonatomic) IBOutlet UIButton *nInAppFeedbackInfo;

/*Lables*/
@property (weak, nonatomic) IBOutlet UILabel *lCrashes;
@property (weak, nonatomic) IBOutlet UILabel *liOSCrashSymbolication;
@property (weak, nonatomic) IBOutlet UILabel *lInAppFeedback;
@property (weak, nonatomic) IBOutlet UILabel *lUnCaughtExeception;
@property (weak, nonatomic) IBOutlet UILabel *lArrayOutOFIndexBounds;
@property (weak, nonatomic) IBOutlet UILabel *lStackOVerFlowError;
@property (weak, nonatomic) IBOutlet UILabel *lSegmentationFault;
@property (weak, nonatomic) IBOutlet UILabel *lMethodA;
@property (weak, nonatomic) IBOutlet UILabel *lMethodB;
@property (weak, nonatomic) IBOutlet UILabel *lCrashTitle;

/*Views*/
@property (weak, nonatomic) IBOutlet UIView *vCrashView;
@property (weak, nonatomic) IBOutlet UIView *viOSCrashSymbolicationView;

@property (weak, nonatomic) IBOutlet UIImageView *vImageView;

/*IgnoreViews*/
@property (weak, nonatomic) IBOutlet UIView *ignoreView1;
@property (weak, nonatomic) IBOutlet UIView *ignoreView2;
@property (weak, nonatomic) IBOutlet UIView *ignoreView3;
@property (weak, nonatomic) IBOutlet UIView *ignoreView4;
@property (weak, nonatomic) IBOutlet UIView *ignoreView5;
@property (weak, nonatomic) IBOutlet UIView *ignoreView6;
@property (weak, nonatomic) IBOutlet UIView *ignoreView7;


/*PopViewController Variables */
@property (nonatomic, strong)	NSArray			*colorSchemes;
@property (nonatomic, strong)	NSDictionary	*contents;
@property (nonatomic, strong)	id				currentPopTipViewTarget;
@property (nonatomic, strong)	NSDictionary	*titles;
@property (nonatomic, strong)	NSMutableArray	*visiblePopTipViews;

@end

@implementation CrashViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//TAG:DECTRAINING
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleCrashEvent:) name:CAMAA_CRASH_OCCURRED object:nil];

    /*Kitchen Sink DB Manager*/
//    [[CAMDOKitchenSinkDBMngr sharedDatabase] addTestDataWithTestName:@"test1" withTester:@"tester1"];
//    [[CAMDOKitchenSinkDBMngr sharedDatabase] addTestDataWithTestName:@"test2" withTester:@"tester2"];

    [self setupView];
}

#pragma  mark - view setup methods

-(void)setupView{
    /*PopViewController*/
    [self setupPopViewController];
   
    /*View*/
    [_vCrashView setUpTransperantViewBlackBorder];
    [_viOSCrashSymbolicationView setUpTransperantViewBlackBorder];

    /*Buttons*/
    [_bUncaughtException makePaperButton];
    [_bStackOverflowError makePaperButton];
    [_bArrayOutOfIndex makePaperButton];
    [_bSegmentationFault makePaperButton];
    [_bMethodA makePaperButton];
    [_bMethodB makePaperButton];

    //[self makePaperButton:_bUncaughtException];
    
    /*Labels*/
    [_lUnCaughtExeception makeLabelBlack];
    [_lArrayOutOFIndexBounds makeLabelBlack];
    [_lSegmentationFault makeLabelBlack];
    [_lStackOVerFlowError makeLabelBlack];
    [_lMethodA makeLabelBlack];
    [_lMethodB makeLabelBlack];
    [_lCrashes makeLabelBlack];
    [_liOSCrashSymbolication makeLabelBlack];
    [_lInAppFeedback makeLabelBlack];
    _lCrashTitle.textColor = [UIColor whiteColor];

    /*IgnoreViews*/
    [_ignoreView1 hideIgnoreView];
    [_ignoreView2 hideIgnoreView];
    [_ignoreView3 hideIgnoreView];
    [_ignoreView5 hideIgnoreView];
    [_ignoreView4 hideIgnoreView];
    [_ignoreView6 hideIgnoreView];
    [_ignoreView7 hideIgnoreView];
    
    [_crashTitle setBackgroundColor:[UIColor paperColorBlue]];
    
}


#pragma mark - InAppFeedback

 -(void)handleCrashEvent:(NSNotification *)note{

     @try {
         // Try something
         NSLog(@"Handle Crash Event");
         NSDictionary *crashData  = [note userInfo];
         if(crashData !=nil){
             //Implement any UI Logic to get any response from the user. e.g. AlertView, TextFields.
             //Once the feedback is received convert it into NSString and send the data.
             // Show a text entry alert with two custom buttons.

             NSString *title = NSLocalizedString(@"In App Feedback", nil);
             NSString *message = NSLocalizedString(@"A message should be a short, complete sentence.", nil);
             NSString *cancelButtonTitle = NSLocalizedString(@"Cancel", nil);
             NSString *otherButtonTitle = NSLocalizedString(@"OK", nil);
             UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];

             [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                 // If you need to customize the text field, you can do so here.
                 textField.placeholder = @"crashString";
             }];

             // Create the action.
             UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:cancelButtonTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
                 NSLog(@"The simple alert's cancel action occured.");

             }];

             UIAlertAction *otherAction = [UIAlertAction actionWithTitle:otherButtonTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                 NSLog(@"The \"Text Entry\" alert's other action occured.");
                 NSLog(@"textField = %@",[[[alertController textFields] objectAtIndex:0] text]);
                 NSString *string =[[[alertController textFields] objectAtIndex:0] text];
                 if(string!=nil){
                     NSString *feedback=string;
                     
//                     [CAMDOReporter setCustomerFeedback:feedback];
                 }
                 else{
//                     [CAMDOReporter setCustomerFeedback:@"No Feedback Entered"];
                 }
             }];
             
             // Add the action.
             [alertController addAction:cancelAction];
             [alertController addAction:otherAction];
             [self presentViewController:alertController animated:YES completion:nil];
             
         }

     }
     @catch (NSException * e) {
         NSLog(@"Exception: %@", e);
     }
  }







#pragma mark - IBActions
- (IBAction)generateUnCaughtException:(id)sender {
    //Creating UnCaught Exception.
    [NSException raise:@"Raised Exception" format:@"This is a forced uncaught exception"];
}
- (IBAction)generateArrayOutOfIndex:(id)sender {
    NSString *huh = @[][1];
    NSLog(@"be quiet warnings: %@", huh);

}
- (IBAction)generateStackOverFlowError:(id)sender {
    //Creating Stack Overflow Error
    [CrashViewController recurse];

}


+(void)recurse{
    [self recurse];
}

- (IBAction)segmentationFault:(id)sender {
    //Creating Segmentation Fault Error.
    kill(getpid(), SIGSEGV);
}

- (IBAction)methodA:(id)sender {
    NSString *huh = @[][1];
    NSLog(@"be quiet warnings: %@", huh);
}
- (IBAction)methodB:(id)sender {
    //Creating Segmentation Fault Error.
    kill(getpid(), SIGSEGV);
}

#pragma  mark - Pop ViewController 

-(void)setupPopViewController{
    self.visiblePopTipViews = [NSMutableArray array];

    self.contents = [NSDictionary dictionaryWithObjectsAndKeys:
                     // Rounded rect buttons
                     @"Simulate the Crashes by clicking on the buttons in crash section", [NSNumber numberWithInt:1],
                     @"Clicking on the buttons Method A / B will generate crashes. If the user has uploaded the .dsym file to the mdo console then user can visualise in which method the crash has occurred along with the symbolicated stack trace.", [NSNumber numberWithInt:2],
                     @"The SDK provides a mechanism to relay info that 'previous session crashed' to the App Developer. This information can be used to provide mechanism to collect information from user"
                     , [NSNumber numberWithInt:3],
                     nil];
    self.titles = [NSDictionary dictionaryWithObjectsAndKeys:
                   @"Generate Crashes", [NSNumber numberWithInt:1],
                   @"Crash Symbolicate", [NSNumber numberWithInt:2],
                   @"In App Feedback",[NSNumber numberWithInt:3],
                   nil];

    // Array of (backgroundColor, textColor) pairs.
    // NSNull for either means leave as default.
    // A color scheme will be picked randomly per CMPopTipView.
    self.colorSchemes = [NSArray arrayWithObjects:
                         [NSArray arrayWithObjects:[NSNull null], [NSNull null], nil],
                         [NSArray arrayWithObjects:[UIColor colorWithRed:134.0/255.0 green:74.0/255.0 blue:110.0/255.0 alpha:1.0], [NSNull null], nil],
                         [NSArray arrayWithObjects:[UIColor darkGrayColor], [NSNull null], nil],
                         [NSArray arrayWithObjects:[UIColor lightGrayColor], [UIColor darkTextColor], nil],
                         [NSArray arrayWithObjects:[UIColor orangeColor], [UIColor blueColor], nil],
                         [NSArray arrayWithObjects:[UIColor colorWithRed:220.0/255.0 green:0.0/255.0 blue:0.0/255.0 alpha:1.0], [NSNull null], nil],
                         nil];

}



#pragma mark - PopView Controller

- (void)dismissAllPopTipViews
{
    while ([self.visiblePopTipViews count] > 0) {
        CMPopTipView *popTipView = [self.visiblePopTipViews objectAtIndex:0];
        [popTipView dismissAnimated:YES];
        [self.visiblePopTipViews removeObjectAtIndex:0];
    }
}

- (IBAction)openPopUp:(id)sender
{
    [self dismissAllPopTipViews];

    if (sender == self.currentPopTipViewTarget) {
        // Dismiss the popTipView and that is all
        self.currentPopTipViewTarget = nil;
    }
    else {
        NSString *contentMessage = nil;
        UIView *contentView = nil;
        NSNumber *key = [NSNumber numberWithInteger:[(UIView *)sender tag]];
        id content = [self.contents objectForKey:key];
        if ([content isKindOfClass:[UIView class]]) {
            contentView = content;
        }
        else if ([content isKindOfClass:[NSString class]]) {
            contentMessage = content;
        }
        else {
            contentMessage = @"A CMPopTipView can automatically point to any view or bar button item.";
        }
        NSArray *colorScheme = [self.colorSchemes objectAtIndex:3];
        UIColor *backgroundColor = [colorScheme objectAtIndex:0];
        UIColor *textColor = [colorScheme objectAtIndex:1];

        NSString *title = [self.titles objectForKey:key];

        CMPopTipView *popTipView;
        if (contentView) {
            popTipView = [[CMPopTipView alloc] initWithCustomView:contentView];
        }
        else if (title) {
            popTipView = [[CMPopTipView alloc] initWithTitle:title message:contentMessage];
        }
        else {
            popTipView = [[CMPopTipView alloc] initWithMessage:contentMessage];
        }
        popTipView.delegate = self;

        /* Some options to try.
         */
        //popTipView.disableTapToDismiss = YES;
        //popTipView.preferredPointDirection = PointDirectionUp;
        //popTipView.hasGradientBackground = NO;
        //popTipView.cornerRadius = 2.0;
        //popTipView.sidePadding = 30.0f;
        //popTipView.topMargin = 20.0f;
        //popTipView.pointerSize = 50.0f;
        //popTipView.hasShadow = NO;

        if (backgroundColor && ![backgroundColor isEqual:[NSNull null]]) {
            popTipView.backgroundColor = backgroundColor;
        }
        if (textColor && ![textColor isEqual:[NSNull null]]) {
            popTipView.textColor = textColor;
        }

        popTipView.animation = arc4random() % 2;
        popTipView.has3DStyle = (BOOL)(arc4random() % 2);

        popTipView.dismissTapAnywhere = YES;
        [popTipView autoDismissAnimated:YES atTimeInterval:3.0];

        if ([sender isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)sender;
            [popTipView presentPointingAtView:button inView:self.view animated:YES];
        }
        else {
            UIBarButtonItem *barButtonItem = (UIBarButtonItem *)sender;
            [popTipView presentPointingAtBarButtonItem:barButtonItem animated:YES];
        }

        [self.visiblePopTipViews addObject:popTipView];
        self.currentPopTipViewTarget = sender;
    }
}


#pragma mark - CMPopTipViewDelegate methods

- (void)popTipViewWasDismissedByUser:(CMPopTipView *)popTipView
{
    [self.visiblePopTipViews removeObject:popTipView];
    self.currentPopTipViewTarget = nil;
}


#pragma mark - UIViewController methods

- (void)willAnimateRotationToInterfaceOrientation:(__unused UIInterfaceOrientation)toInterfaceOrientation duration:(__unused NSTimeInterval)duration
{
    for (CMPopTipView *popTipView in self.visiblePopTipViews) {
        id targetObject = popTipView.targetObject;
        [popTipView dismissAnimated:NO];
        
        if ([targetObject isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)targetObject;
            [popTipView presentPointingAtView:button inView:self.view animated:NO];
        }
        else {
            UIBarButtonItem *barButtonItem = (UIBarButtonItem *)targetObject;
            [popTipView presentPointingAtBarButtonItem:barButtonItem animated:NO];
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - BFPaperMethods.
-(void)makePaperButton:(BFPaperButton *)button{
    button.backgroundColor = [UIColor paperColorBlue];
    button.isRaised=YES;
    button.cornerRadius =5;
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
}


#pragma mark -
#pragma mark - Database Creation Methods.




















@end
