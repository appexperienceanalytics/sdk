//
//  MyTabBarViewController.h
//  MAAKitchenSink
//
//  Created by Nilesh Agrawal on 6/26/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BFPaperTabBarController.h"

@interface MAAKitchenSinkTabBarViewController : BFPaperTabBarController

@end
