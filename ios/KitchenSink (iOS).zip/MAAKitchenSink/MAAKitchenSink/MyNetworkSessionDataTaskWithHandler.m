//
//  MyNetworkSessionDataTaskWithHandler.m
//  CAMSMDemo
//
//  Created by Nilesh on 3/27/15.
//  Copyright (c) 2015 CA Technologies, Inc. All rights reserved.
//

#import "MyNetworkSessionDataTaskWithHandler.h"

@implementation MyNetworkSessionDataTaskWithHandler

- (void)performRequest:(NSURLRequest *)request onQueue:(NSOperationQueue *)queue
{
    NSURLSessionConfiguration *config =[NSURLSessionConfiguration defaultSessionConfiguration];

    NSURLSession *session = [NSURLSession sessionWithConfiguration:config
                                                          delegate:nil
                                                     delegateQueue:queue];

    [[session dataTaskWithRequest:request completionHandler:^(NSData *data,
                                                              NSURLResponse *response,
                                                              NSError *error)
      {
          [self.delegate requestCompletedWithResponse:response andError:error];
      }] resume];
}

@end
