//
//  WebViewController.h
//  CAMAADemoApp
//
//  Created by Nilesh on 4/5/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebViewController : UIViewController<UITextFieldDelegate,UIWebViewDelegate, NSURLSessionDelegate>

@end
