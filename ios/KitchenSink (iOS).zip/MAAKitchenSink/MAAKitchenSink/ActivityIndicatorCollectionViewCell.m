//
//  ActivityIndicatorCollectionViewCell.m
//  MAAKitchenSink
//
//  Created by Nilesh Agrawal on 6/27/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import "ActivityIndicatorCollectionViewCell.h"

@implementation ActivityIndicatorCollectionViewCell



- (void)customSetup
{
    
    self.backgroundColor = [UIColor whiteColor];
    self.layer.borderWidth = 1.0f;
    self.layer.borderColor = [UIColor grayColor].CGColor;
    
//    self.backgroundColor = [UIColor whiteColor];
//    UIBezierPath *shadowPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds cornerRadius:2.0];
//    self.layer.shadowRadius= 5.00;
//    self.layer.shadowOpacity=0.5;
//    self.layer.cornerRadius = 4.0;
//    self.layer.masksToBounds = false;
//    self.layer.shadowColor = [UIColor blackColor].CGColor;
//    self.layer.shadowOffset = CGSizeMake(0.00,3.00);
//    self.layer.shadowPath = shadowPath.CGPath;
    
    self.tapCircleColor = [[UIColor paperColorLimeA400] colorWithAlphaComponent:0.6f];
    self.tapCircleDiameter = bfPaperCollectionViewCell_tapCircleDiameterSmall;
    self.rippleFromTapLocation = NO;
    self.backgroundFadeColor = [[UIColor  paperColorDeepPurple] colorWithAlphaComponent:0.3f];
    self.letBackgroundLinger = NO;
    self.touchDownAnimationDuration = 0.25f;
    self.touchUpAnimationDuration = 2 * self.touchDownAnimationDuration;
    self.alwaysCompleteFullAnimation = YES;
    self.tapDelay = 0.0f;
    self.tapCircleBurstAmount = self.frame.size.width/10;
    
}
- (IBAction)startActivityIndicator:(id)sender {
    
    [_sampleActivityIndicator startAnimating];
    
}

- (IBAction)stopActivityIndicator:(id)sender {
    [_sampleActivityIndicator stopAnimating];
}




@end
