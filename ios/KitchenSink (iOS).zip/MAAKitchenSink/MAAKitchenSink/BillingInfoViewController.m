//
//  BillingInfoViewController.m
//  MAAKitchenSink
//
//  Created by Nilesh Agrawal on 6/27/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import "BillingInfoViewController.h"
#import "UIColor+BFPaperColors.h"

@interface BillingInfoViewController ()
@property (weak, nonatomic) IBOutlet UILabel *purchaseInfo;
@property (weak, nonatomic) IBOutlet UIView *titleView;

@property (weak, nonatomic) IBOutlet UIButton *bPurchase;
@end

@implementation BillingInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupView];
    }

-(void)setupView{
    [_purchaseInfo setBackgroundColor:[UIColor paperColorBlue500]];
    [_bPurchase setBackgroundColor:[UIColor paperColorBlue500]];
    [_titleView setBackgroundColor:[UIColor paperColorBlue500]];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
