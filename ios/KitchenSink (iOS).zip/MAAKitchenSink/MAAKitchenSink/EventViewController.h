//
//  EventViewController.h
//  CAMAADemoApp
//
//  Created by Nilesh on 4/5/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CMPopTipView.h"

@interface EventViewController : UIViewController<CMPopTipViewDelegate,UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>

@end
