//
//  AppDelegate.h
//  CAMAADemoApp
//
//  Created by Nilesh on 4/4/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

