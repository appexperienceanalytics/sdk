//
//  CarDetailsViewController.m
//  MAAKitchenSink
//
//  Created by Nilesh Agrawal on 6/27/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import "CarDetailsViewController.h"
#import "UIColor+BFPaperColors.h"

@interface CarDetailsViewController ()

@property (weak, nonatomic) IBOutlet UIButton *bdone;
@property (weak, nonatomic) IBOutlet UIView *titleView;

@end

@implementation CarDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [_lCarDescription setText:[self getCarDescription:_carID]];
    [_ivCarImage setImage:[self getCarImage:_carID]];
    [_lCarName setText:[self getCarName:_carID]];
    [_titleView setBackgroundColor:[UIColor paperColorBlue500]];
    [_bdone setBackgroundColor:[UIColor paperColorBlue500]];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(NSString *)getCarDescription:(int)carId{
    switch (carId) {
        case 0:
            return @"Model : 2014 \nSalesPerson : Alex \nPrice:32000$";
             break;
        case 1:
            return @"Model : 2010 \nSalesPerson : Roger \nPrice:30000$";
            break;
        case 2:
            return @"Model : 2015 \nSalesPerson : Mary \nPrice:28000$";

            break;
        case 3:
            return @"Model : 2008 \nSalesPerson : Diana \nPrice:27000$";

            break;
        case 4:
            return @"Model : 2011 \nSalesPerson : Alex \nPrice:26000$";

            break;
        case 5:
            return @"Model : 2013 \nSalesPerson : Ania \nPrice:30000$";

            break;
        default:
            return @"";
            break;
    }
}


-(UIImage *)getCarImage:(int)carId{
    switch (carId) {
        case 0:
            return [UIImage imageNamed:@"audia4"];
            break;
        case 1:
            return [UIImage imageNamed:@"audir8"];
            break;
        case 2:
            return [UIImage imageNamed:@"bmw"];
            
            break;
        case 3:
            return [UIImage imageNamed:@"bmwx5"];
            
            break;
        case 4:
            return [UIImage imageNamed:@"marc1"];
            
            break;
        case 5:
            return [UIImage imageNamed:@"marc2"];
            
            break;
        default:
            return nil;
            break;
    }

}

-(NSString *)getCarName:(int)carId{
    switch (carId) {
        case 0:
            return @"Audi A4";
            break;
        case 1:
            return @"Audi R8";
            break;
        case 2:
            return @"BMW i8";
            
            break;
        case 3:
            return @"BMW X5";
            break;
        case 4:
            return @"Mercedes";
            break;
        case 5:
            return @"Mercedes 2";
            break;
        default:
            return @"";
            break;
    }

}
@end
