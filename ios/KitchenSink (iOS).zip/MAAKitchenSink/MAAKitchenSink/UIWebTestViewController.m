//
//  JSAPIViewController.m
//  CAMobileAppAnalytics
//
//  Created by Shyammohan Sugathan on 5/11/16.
//  Copyright © 2016 CA Technologies. All rights reserved.
//

#import "UIWebTestViewController.h"

@interface UIWebTestViewController ()
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end

@implementation UIWebTestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadUIWebView];
}

-(void)loadUIWebView{
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"index" ofType:@"html"]]];
    
    [_webView setDelegate:self];
    [_webView loadRequest:request];}

@end
