//
//  WebViewController.m
//  CAMAADemoApp
//
//  Created by Nilesh on 4/5/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import "WebViewController.h"
#import "UIView+ViewEffects.h"
#import "UIButton+ButtonEffects.h"
#import "UILabel+LabelEffects.h"
#import "FXBlurView.h"
#import "UIColor+BFPaperColors.h"
//TAG:DECTRAINING
//#import "CAMDOReporter.h"


@interface WebViewController ()

/*TextField*/
@property (weak, nonatomic) IBOutlet UITextField *tfWebUrl;
@property (weak, nonatomic) IBOutlet FXBlurView *blurView;
@property (weak, nonatomic) IBOutlet UIView *webviewTitle;

/*WebView*/
@property (weak, nonatomic) IBOutlet UIWebView *webViewScreen;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *webviewLoadIndicator;

/*Buttons */
@property (weak, nonatomic) IBOutlet UIButton *bGo;
@property (weak, nonatomic) IBOutlet UIButton *bYoutube;
@property (weak, nonatomic) IBOutlet UIButton *bMDO;
@property (weak, nonatomic) IBOutlet UIButton *bTechCrunch;
@property (weak, nonatomic) IBOutlet UIButton *bStackOverflow;
@property (weak, nonatomic) IBOutlet UIView *ignoreView1;
@property (weak, nonatomic) IBOutlet UIView *ignoreView2;
@property (weak, nonatomic) IBOutlet UIView *ignoreView3;
@property (weak, nonatomic) IBOutlet UIView *ignoreView4;
@property (weak, nonatomic) IBOutlet UIView *ignoreView5;
@property BOOL Authenticated;
@property NSURLRequest *FailedRequest;
@property NSString *BaseRequest;

@end

@interface WebViewController()<UIWebViewDelegate,NSURLConnectionDelegate>
@end
@implementation WebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //[self setupBlurBackground];
    _tfWebUrl.delegate = self;
    [self setupView];
    self.webViewScreen.delegate = self;
    _webviewTitle.backgroundColor = [UIColor paperColorBlue];
}

-(void)setupView{
    [_bGo makePaperButton];
    [_bYoutube makePaperButton];
    [_bMDO makePaperButton];
    [_bTechCrunch makePaperButton];
    [_bStackOverflow makePaperButton];
    [self loadWeviewatStartup];
    [_ignoreView1 hideIgnoreView];
    [_ignoreView2 hideIgnoreView];
    [_ignoreView3 hideIgnoreView];
    [_ignoreView4 hideIgnoreView];
    [_ignoreView5 hideIgnoreView];
    //[self setFloatingTextField:_tfWebUrl];
}


/*Validation*/

- (BOOL) validateHttpUrl: (NSString *) candidate {
    NSString *urlRegEx =
    @"(http|https)://((\\w)*|([0-9]*)|([-|_])*)+([\\.|/]((\\w)*|([0-9]*)|([-|_])*))+";
    NSPredicate *urlTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", urlRegEx];
    return [urlTest evaluateWithObject:candidate];
}

- (BOOL) validateWWWUrl: (NSString *) candidate {

    NSString *urlRegEx =  @"(www\\.)[\\w\\d\\-_]+\\.\\w{2,3}(\\.\\w{2})?(/(?<=/)(?:[\\w\\d\\-./_]+)?)?";
    NSPredicate *urlTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", urlRegEx];
    return [urlTest evaluateWithObject:candidate];
}

-(BOOL)isValidURLString:(NSString *)candidate{
    NSString *urlRegEx = @"^(http(s)?://)?((www)?\\.)?[\\w]+\\.[\\w]+";
    NSPredicate *urlTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",urlRegEx];
    return [urlTest evaluateWithObject:candidate];
}

-(BOOL)validateUrl{

    if([self validateHttpUrl:_tfWebUrl.text]){
        return true;
    }

    if(![_tfWebUrl.text containsString:@"http://"] && [self validateWWWUrl:_tfWebUrl.text]){
        _tfWebUrl.text = [@"http://" stringByAppendingString:_tfWebUrl.text];
        return true;
    }

    if(![_tfWebUrl.text containsString:@"http://"] && ![self validateWWWUrl:_tfWebUrl.text]){
        _tfWebUrl.text = [@"http://www." stringByAppendingString:_tfWebUrl.text];
        return true;
    }

    return false;
}

#pragma mark - IBActions:
- (IBAction)openWebViewWithThatURL:(id)sender {
    NSString *textFieldURL = [_tfWebUrl text];
    _BaseRequest = textFieldURL;
    if([self validateUrl]){
         [_webViewScreen loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:textFieldURL]]];
    }
}

-(void)loadWeviewatStartup{
//    [CAMDOReporter setNSURLSessionDelegate:self];
    _tfWebUrl.text = @"http://www.google.com";
    _BaseRequest =@"http://www.google.com";

    [_webViewScreen loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:_tfWebUrl.text]]];
}

- (IBAction)loadCATechPage:(id)sender {
    _tfWebUrl.text = @"https://mdo.mobility.ca.com/sppclient/#/signin/mdo?demo=true";
    [_webViewScreen loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"https://mdo.mobility.ca.com/sppclient/#/signin/mdo?demo=true"]]];
}

- (IBAction)loadStackOverFlowPage:(id)sender {
    _tfWebUrl.text =@"http://stackoverflow.com/";
    [_webViewScreen loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://stackoverflow.com/"]]];

}

- (IBAction)loadTechCrunchPage:(id)sender {
    _tfWebUrl.text = @"http://techcrunch.com/";
    [_webViewScreen loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://techcrunch.com/"]]];
}

- (IBAction)loadYoutubePage:(id)sender {
    _tfWebUrl.text = @"http://www.youtube.com/";
    [_webViewScreen loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"https://www.youtube.com/"]]];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - TextField Delegate 
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [_tfWebUrl resignFirstResponder];
    return NO; }


#pragma mark - web view delegate methods.

-(void)webViewDidStartLoad:(UIWebView *)webView{
    [self.webviewLoadIndicator startAnimating];

}

-(void)webViewDidFinishLoad:(UIWebView *)webView{
    [self.webviewLoadIndicator stopAnimating];
    self.webviewLoadIndicator.hidden = YES;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

/*-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    BOOL result = _Authenticated;
    if (!_Authenticated) {
        _FailedRequest = request;
        [[NSURLConnection alloc] initWithRequest:request delegate:self];
    }
    return result;
}

-(void)connection:(NSURLConnection *)connection willSendRequestForAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge {
    if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]) {
        NSURL* baseURL = [NSURL URLWithString:_BaseRequest];
        if ([challenge.protectionSpace.host isEqualToString:baseURL.host]) {
            NSLog(@"trusting connection to host %@", challenge.protectionSpace.host);
            [challenge.sender useCredential:[NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust] forAuthenticationChallenge:challenge];
        } else
            NSLog(@"Not trusting connection to host %@", challenge.protectionSpace.host);
    }
    [challenge.sender continueWithoutCredentialForAuthenticationChallenge:challenge];
}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)pResponse {
    _Authenticated = YES;
    [connection cancel];
    [_webViewScreen loadRequest:_FailedRequest];
}
*/

- (void)URLSession:(NSURLSession *)session didReceiveChallenge:(NSURLAuthenticationChallenge *)challenge
 completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition disposition, NSURLCredential * __nullable credential))completionHandler {
//    NSLog(@"didReceiveChallenge");
    completionHandler(NSURLSessionAuthChallengePerformDefaultHandling, nil);
}

@end
