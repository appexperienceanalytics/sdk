//
//  PersonProfileViewController.h
//  MAAKitchenSink
//
//  Created by Nilesh Agrawal on 6/27/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonProfileViewController : UIViewController

@end
