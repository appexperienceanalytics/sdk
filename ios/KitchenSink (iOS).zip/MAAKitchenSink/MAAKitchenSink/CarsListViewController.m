//
//  CarsListViewController.m
//  MAAKitchenSink
//
//  Created by Nilesh Agrawal on 6/27/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import "CarsListViewController.h"
#import "MainCarsApp.h"
#import "CarDetailsViewController.h"
#import "UIColor+BFPaperColors.h"

@interface CarsListViewController ()
@property (weak, nonatomic) IBOutlet UIView *titleView;

@property (weak, nonatomic) IBOutlet UICollectionView *carsListCollectionView;
@end

@implementation CarsListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
        CGFloat width = (CGRectGetWidth(self.view.frame));
        CGFloat height = (CGRectGetHeight(self.view.frame));
        [flowLayout setItemSize:CGSizeMake(width/2, height/3)];
        [flowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
        flowLayout.minimumInteritemSpacing = 10.0f;
    flowLayout.minimumLineSpacing=10.0f;
     [_carsListCollectionView setCollectionViewLayout:flowLayout];
    [self setUpView];
}

-(void)setUpView{
    [_titleView setBackgroundColor:[UIColor paperColorBlue500]];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 6;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    
    MainCarsApp *activityViewCell = nil;
    //Cell from the prototype
    if(indexPath.row == 0){
        activityViewCell=[collectionView dequeueReusableCellWithReuseIdentifier:@"CarsCell" forIndexPath:indexPath];
        activityViewCell.ivCarFeature.image = [UIImage imageNamed:@"audia4"];
        activityViewCell.lCarAppFeature.text = @"Audi R8";
    }else if(indexPath.row == 1){
        activityViewCell =[collectionView dequeueReusableCellWithReuseIdentifier:@"CarsCell"forIndexPath:indexPath];
        activityViewCell.ivCarFeature.image = [UIImage imageNamed:@"audir8"];
        activityViewCell.lCarAppFeature.text = @"Audi R8";
    }else if(indexPath.row ==2){
        activityViewCell =[collectionView dequeueReusableCellWithReuseIdentifier:@"CarsCell" forIndexPath:indexPath];
        activityViewCell.ivCarFeature.image = [UIImage imageNamed:@"bmw"];
        activityViewCell.lCarAppFeature.text = @"BMW i8";
    }else if(indexPath.row == 3){
        activityViewCell =[collectionView dequeueReusableCellWithReuseIdentifier:@"CarsCell" forIndexPath:indexPath];
        activityViewCell.ivCarFeature.image = [UIImage imageNamed:@"bmwx5"];
        activityViewCell.lCarAppFeature.text = @"BMW X5";
    }
    else if(indexPath.row == 4){
        activityViewCell =[collectionView dequeueReusableCellWithReuseIdentifier:@"CarsCell" forIndexPath:indexPath];
        activityViewCell.ivCarFeature.image = [UIImage imageNamed:@"merc1"];
        activityViewCell.lCarAppFeature.text = @"Mercedes";
    }
    else if(indexPath.row == 5){
        activityViewCell =[collectionView dequeueReusableCellWithReuseIdentifier:@"CarsCell" forIndexPath:indexPath];
        activityViewCell.ivCarFeature.image = [UIImage imageNamed:@"merc2"];
        activityViewCell.lCarAppFeature.text = @"Mercedes 2";
    }
    activityViewCell.layer.borderWidth=1;
    activityViewCell.layer.borderColor=[UIColor blackColor].CGColor;
    
    return activityViewCell;
}

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    
    if([segue.identifier isEqualToString:@"MasterToDetail"]){
        NSIndexPath *indexPath = [_carsListCollectionView indexPathsForSelectedItems].firstObject;
        if(indexPath){
           CarDetailsViewController  *carViewController = segue.destinationViewController;
           // Location *location = [_locationArray objectAtIndex:indexPath.row];
           // requestViewController.location = location.locationCaption;
            
            if(indexPath.row == 0){
                
                carViewController.ivCarImage.image =[UIImage imageNamed:@"audia4"];
                carViewController.lCarName.text = @"Audi A4";
                carViewController.carID = 0;
                
               
            }else if(indexPath.row == 1){
            
                carViewController.ivCarImage.image =[UIImage imageNamed:@"audir8"];
                carViewController.lCarName.text = @"Audi R8";
                carViewController.carID = 1;
                
            }else if(indexPath.row ==2){
           
                carViewController.ivCarImage.image =[UIImage imageNamed:@"bmw"];
                carViewController.lCarName.text = @"BMW i8";
                carViewController.carID = 2;
                
            }else if(indexPath.row == 3){
            
                carViewController.ivCarImage.image =[UIImage imageNamed:@"bmwx5"];
                carViewController.lCarName.text = @"BMW X5";
                carViewController.carID = 3;
            }
            else if(indexPath.row == 4){
                carViewController.ivCarImage.image =[UIImage imageNamed:@"marc1"];
                carViewController.lCarName.text = @"Mercedes";
                carViewController.carID = 4;
            }
            else if(indexPath.row == 5){
                carViewController.ivCarImage.image =[UIImage imageNamed:@"marc2"];
                carViewController.lCarName.text = @"Mercedes 2";
                carViewController.carID = 5;
            }
            
        }
    }
    
    
}


@end
