//
//  MyNetworkSessionDataTaskWithDelegate.m
//  CAMSMDemo
//
//  Created by Nilesh on 3/27/15.
//  Copyright (c) 2015 CA Technologies, Inc. All rights reserved.
//

#import "MyNetworkSessionDataTaskWithDelegate.h"
#import "MyNetworkSessionDelegate.h"

@implementation MyNetworkSessionDataTaskWithDelegate
- (void)performRequest:(NSURLRequest *)request onQueue:(NSOperationQueue *)queue
{
    NSURLSessionConfiguration *config =[NSURLSessionConfiguration defaultSessionConfiguration];
    MyNetworkSessionDelegate *delegate = [[MyNetworkSessionDelegate alloc] initWithDelegate:self.delegate];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:config
                                                          delegate:delegate
                                                     delegateQueue:queue];
    [[session dataTaskWithRequest:request] resume];
}
@end
