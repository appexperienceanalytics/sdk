//
//  MyNetworkConnectionWithAsyncHandler.m
//  CAMSMDemo
//
//  Created by Nilesh on 3/27/15.
//  Copyright (c) 2015 CA Technologies, Inc. All rights reserved.
//

#import "MyNetworkConnectionWithAsyncHandler.h"

@implementation MyNetworkConnectionWithAsyncHandler

- (void)performRequest:(NSURLRequest *)request onQueue:(NSOperationQueue *)queue
{
    [NSURLConnection sendAsynchronousRequest:request
                                       queue:queue
                           completionHandler:^(NSURLResponse *response,
                                               NSData *data,
                                               NSError *error)
     {
         [self.delegate requestCompletedWithResponse:response andError:error];
     }];
}

@end
