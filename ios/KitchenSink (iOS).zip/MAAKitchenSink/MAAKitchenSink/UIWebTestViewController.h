//
//  JSAPIViewController.h
//  CAMobileAppAnalytics
//
//  Created by Shyammohan Sugathan on 5/11/16.
//  Copyright © 2016 CA Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIWebTestViewController : UIViewController <UIWebViewDelegate>

@end
