/**
 * @file Javascript Integration apis for CA-MAA-SDK.
 * @copyright Copyright (C) 2015, CA.  All rights reserved.
 *
 * @global
 * @name CaMDOIntegration
 */

CaMDOIntegration = {}


CaMDOIntegration.quality = {high:"90",medium:"50",low:"20" ,default_:"-1"};



/**
 * CaMDOIntegaration all apis call takes callback function as parameter.
 * Callback function will be inovked from Native SDK after finishing api call.
 * Callback function takes 3 parameters : function callback(action,returnValue,error);
 *
 * @callback callback
 * @param {string} action
 * @param {string} returnValue
 * @param {string} error
 *
 */


/**
 * @name isScreenshotPolicyEnabled
 * @param {callback} - callback
 *    @example
 *    isScreenshotPolicyEnabled(callback);
 */

/**
 * @function isScreenshotPolicyEnabled
 * @description Returns TRUE if screenshots are enabled by policy.  Otherwise return FALSE
 *      @example
 *      CaMDOIntegration.isScreenshotPolicyEnabled(callback);
 */
CaMDOIntegration.isScreenshotPolicyEnabled = function(callback) {
    var dictionary = {};
    dictionary.action = "isScreenshotPolicyEnabled";
    dictionary.callback = callback;
    sendIntegrationEvent(dictionary);
};

/**
 *   @name Screenshot
 *   @property {string}  screenName     -    Name of Screen , for which a screenshot to be taken.
 *   @property {string}  quality        -    Quality of Screenshot to be taken. You can pass  @name {CAMDOIntegration.quality.high},CAMDOIntegration.quality.medium ,CAMDOIntegration.quality.low, CAMDOIntegration.quality.default_ or a value between 1 and 100.
 *
 */


/**
 * @function sendScreenshot
 * @description Takes screenshot of current screen and adds an event to analytics.
 * @param {string} screenName - name of the screen for which screenshot will be taken.
 * @param {CaMDOIntegration.quality} quality - Quality of the screenshot to be taken. You can use CaMDOIntegration.quality.high ,CaMDOIntegration.quality.medium , CaMDOIntegration.quality.low
 * @param {callback} callback - callback.
 *      @example
 *      CaMDOIntegration.sendScreenShot("Shopping",CaMDOIntegration.quality.medium,callback);
 */

CaMDOIntegration.sendScreenShot = function(screenName,quality,callback) {
    var dictionary = {};
    dictionary.action = "sendScreenShot";
    dictionary.screenname = screenName;
    dictionary.quality = quality;
    dictionary.callback = callback;
    sendIntegrationEvent(dictionary);
};


/**
 *   @name SessionEvent
 *   @property {string}  type       -    Event type valid values are double , string
 *   @property {string}  key        -    Event key , name of event.
 *   @property {string}  value      -    Event value
 *   @property {object}  attributes -    Event attribute JSON (optional)
 *
 */

/**
 * @function    addSessionEvent
 * @description Sends a new session event
 * @param {SessionEvent}  - Event object
 * @param {callback} - callback
 *
 *
 *
 *
 * Usage example :
 * @example
 *  CaMDOIntegration.addSessionEvent({
 *       "type" : "typeA",
 *        "key" : "key",
 *        "value": "value"},callback);
 *
 *   With attributes :
 *   @example
 *  CaMDOIntegration.addSessionEvent({
 *       "type" : "typeA",
 *        "key" : "key",
 *        "value": "value",
 *        "attributes" : { "k" : "v" }
 *       },callback);
 *
 *
 *
 */
CaMDOIntegration.addSessionEvent = function(eventObj, callback) {
    if (!eventObj) {
        //console.error("CaMDOIntegration:: Event object is missing.");
        return;
    }
    
    var type = eventObj.type;
    var key = eventObj.key;
    var value = eventObj.value;
    var attributes = eventObj.attributes;
    
    if (type && key && value) {
        var dictionary = {};
        dictionary.action = "addSessionEvent";
        dictionary.type = type;
        dictionary.key = key;
        dictionary.value = value;
        dictionary.callback = callback;
        if(attributes) {
            dictionary.attributes = attributes;
        }
        sendIntegrationEvent(dictionary);
        
    } else {
        //console.error("CaMDOIntegration:: addSessionEvent requires type,key,value one of the required input is missing in event object");
    }
    
};


/**
 * @function    logTextMetrics
 * @description adds a text metrics to the current session.
 * @param {SessionEvent}  - Event object
 * @param {callback} - callback
 *
 *
 *
 *
 * Usage example :
 * @example
 *  CaMDOIntegration.logTextMetrics({
 *        "key" : "key",
 *        "value": "value"},callback);
 *
 *   With attributes :
 *   @example
 *  CaMDOIntegration.logTextMetrics({
 *        "key" : "key",
 *        "value": "value",
 *        "attributes" : { "k" : "v" }
 *       },callback);
 *
 *
 *
 */
CaMDOIntegration.logTextMetrics = function(eventObj, callback) {
    if (!eventObj) {
        return;
    }
    
    var key = eventObj.key;
    var value = eventObj.value;
    var attributes = eventObj.attributes;
    
    if (key && value) {
        var dictionary = {};
        dictionary.action = "logTextMetric";
        dictionary.key = key;
        dictionary.value = value;
        dictionary.callback = callback;
        if(attributes) {
            dictionary.attributes = attributes;
        }
        sendIntegrationEvent(dictionary);
        
    }
};

/**
 * @function    logNumericMetrics
 * @description adds a numeric metrics to the current session.
 * @param {SessionEvent}  - Event object
 * @param {callback} - callback
 *
 *
 *
 *
 * Usage example :
 * @example
 *  CaMDOIntegration.logNumericMetrics({
 *        "key" : "key",
 *        "value": "value"},callback);
 *
 *   With attributes :
 *   @example
 *  CaMDOIntegration.logNumericMetrics({
 *        "key" : "key",
 *        "value": value,
 *        "attributes" : { "k" : "v" }
 *       },callback);
 *
 *
 *
 */
CaMDOIntegration.logNumericMetrics = function(eventObj, callback) {
    if (!eventObj) {
        return;
    }
    
    var key = eventObj.key;
    var value = eventObj.value;
    var attributes = eventObj.attributes;
    
    if (key && value) {
        var dictionary = {};
        dictionary.action = "logNumericMetric";
        dictionary.key = key;
        dictionary.value = value;
        dictionary.callback = callback;
        if(attributes) {
            dictionary.attributes = attributes;
        }
        sendIntegrationEvent(dictionary);
        
    }
};


/**
 *   @name Location
 *   @property {string}  zipCode       -    Zipcode
 *   @property {string}  countryCode   -    Country code
 *   @property {callback} callback - callback.
 *
 */

/**
 * @function    setCustomerLocation
 * @description Sets the location of the device
 * @param {Location}  - Location object
 * @param {callback} - callback
 *
 *    @example
 *    CaMDOIntegration.setCustomerLocation({
 *        "zipCode" : "94063",
 *       "countryCode" : "US",
 *     },callback);
 *
 *
 */

CaMDOIntegration.setCustomerLocation = function(locationObj, callback) {
    if (locationObj) {
        
        var dictionary = {};
        dictionary.action = "setCustomerLocation";
        dictionary.zipcode = locationObj.zipCode
        dictionary.countryCode = locationObj.countryCode;
        if (!dictionary.zipcode) {
            //console.error("CaMDOIntegration:: zipCode is missing in location");
            return;
        }
        if (!dictionary.countryCode) {
            //console.error("CaMDOIntegration:: countryCode is missing in location");
            return;
        }
        
        if (callback) {
            dictionary.callback = callback;
        }
        sendIntegrationEvent(dictionary);
    } else {
        //console.error("CaMDOIntegration:: Location is missing.")
    }
    
};

/**
 *   @name SessionInfo
 *   @property {string}  type       -    Session info  type valid values are customerId, double , string.
 *   @property {string}  key        -    Session info  key
 *   @property {string}  value      -    Session info  value
 *
 */

/**
 * @function    setSessionInfo
 * @description Set session information with the value.  If type is customerId, deviceID is replaced
 * @param {SessionInfo}  - Location object
 * @param {callback} - callback
 *
 *  @example
 *  CaMDOIntegration.setSessionInfo({
 *  "type" : "customerId", // can be one of customerId, double , string
 *   "key"  : "exampleKey",
 *     "value": "exampleValue",
 *   },callback);
 *
 *
 */

CaMDOIntegration.setSessionInfo = function(sessionInfo, callback) {
    
    if (sessionInfo) {
        var dictionary = {};
        dictionary.action = "setSessionInfo";
        dictionary.type = sessionInfo.type;
        dictionary.key = sessionInfo.key;
        dictionary.value = sessionInfo.value;
        if (!dictionary.type) {
            //console.error("CaMDOIntegration:: type is required in sessionInfo");
            return;
        }
        if (!dictionary.value) {
            //console.error("CaMDOIntegration:: value is required in sessionInfo");
            return;
        }
        if (callback) {
            dictionary.callback = callback;
        }
        sendIntegrationEvent(dictionary);
        
    } else {
        //console.error("CaMDOIntegration:: sessionInfo is missing.");
    }
    
};

/**
 *   @name Transaction
 *   @property {string}  transactionName       -  Name of the transaction.
 *   @property {string}  serviceName           -  Name of service/screen.
 *   @property {string}  failure               -  Failure reason in case of stop transaction.
 */

/**
 * @function    startApplicationTransaction
 * @description Starts a new application transaction that bounds all the subsequent events.Application name is used as the service name
 *
 * @param {Transaction}  - Transaction Object
 * @param {callback} - callback
 * @example
 * CaMDOIntegration.startApplicationTransaction({
 * "transactionName" : "itemAddedToShoppingCart",
 * "serviceName" : "CheckoutScreen"
 *    },callback);
 *
 *
 */
CaMDOIntegration.startApplicationTransaction = function(transactionObj, callback) {
    
    if (transactionObj) {
        if (!transactionObj.transactionName) {
            //console.error("CaMDOIntegration:: transactionName is required in transactionObj");
            return;
        }
        var dictionary = {};
        var callback, serviceName;
        dictionary.action = "startApplicationTransaction";
        dictionary.transactionName = transactionObj.transactionName;
        
        if (callback) {
            dictionary.callback = callback;
        }
        if (transactionObj.serviceName) {
            dictionary.serviceName = transactionObj.serviceName;
        }
        sendIntegrationEvent(dictionary);
    } else {
        //console.error("CaMDOIntegration:: transactionObj is missing.");
    }
    
};


/**
 * @function    stopApplicationTransaction
 * @description Stops the application transaction.  Subsequent events will be part of the previous transaction
 * if there is one.
 *
 * @param {Transaction}  - Transaction Object
 * @param {callback} - callback
 *
 * @example
 * CaMDOIntegration.stopApplicationTransaction({
 * "transactionName" : "itemAddedToShoppingCart",
 * "serviceName" : "CheckoutScreen",
 * "failure" : "Cart was deleted."
 *    },callback);
 
 */

CaMDOIntegration.stopApplicationTransaction = function(transactionObj, callback) {
    if (transactionObj) {
        var dictionary = {};
        dictionary.action = "stopApplicationTransaction";
        dictionary.transactionName = transactionObj.transactionName;
        
        
        if (!dictionary.transactionName) {
            //console.error("CaMDOIntegration:: transactionName is required in transactionObj");
            return;
        }
        if (callback) {
            dictionary.callback = callback;
        }
        if (transactionObj.serviceName) {
            dictionary.serviceName = transactionObj.serviceName;
        }
        if (transactionObj.failure) {
            dictionary.failure = transactionObj.failure;
        }
        sendIntegrationEvent(dictionary);
        
    } else {
        //console.error("CaMDOIntegration:: transactionObj is missing.");
    }
    return true;
};

/**
 * @function setCustomerFeedback
 * @description sets the feedback from the user about a crash
 * @param {string } feedback - Feedback to be sent
 * @param {callback} callback - callback
 *       @example
 *       CaMDOIntegration.setCustomerFeedback("Users feedback about app",callback);
 */
CaMDOIntegration.setCustomerFeedback = function(feedback, callback) {
    if (!feedback) {
        //console.error("feedback is missing.");
        return;
    }
    var dictionary = {};
    dictionary.feedback = feedback;
    dictionary.action = "setCustomerFeedback";
    if (callback) {
        dictionary.callback = callback;
    }
    sendIntegrationEvent(dictionary);
};

/**
 * @function isSDKEnabled
 * @description Checks if SDK is enabled or not
 * @param {callback} - callback (Required)
 * @example
 * CaMDOIntegration.isSDKEnabled(callback);
 */
CaMDOIntegration.isSDKEnabled = function(callback) {
    var dictionary = {};
    dictionary.action = "isSDKEnabled";
    if (callback) {
        dictionary.callback = callback;
        sendIntegrationEvent(dictionary);
    } else {
        //console.error("CaMDOIntegration:: callback is required to return value from isSDKEnabled() call. ");
    }
    
};

/**
 * @function isInPrivateZone
 * @description Checks if app is in private zone state.
 * @param {callback} - callback (Required)
 * @example
 * CaMDOIntegration.isInPrivateZone(callback);
 */
CaMDOIntegration.isInPrivateZone = function(callback) {
    var dictionary = {};
    dictionary.action = "isInPrivateZone";
    if (callback) {
        dictionary.callback = callback;
        sendIntegrationEvent(dictionary);
    } else {
        //console.error("CaMDOIntegration:: callback is required to return value from isInPrivateZone() call. ");
    }
};

/**
 * @function enableSDK
 * @description Enable SDK if its not enabled.When SDK is enabled, sdk will collect data for analytics.
 * @param {callback} - callback
 * @example
 * CaMDOIntegration.enableSDK(callback);
 */
CaMDOIntegration.enableSDK = function(callback) {
    var dictionary = {};
    dictionary.action = "enableSDK";
    if (callback) {
        dictionary.callback = callback;
    }
    sendIntegrationEvent(dictionary);
};

/**
 * @function exitPrivateZone
 * @description  Exiting private zone.
 * @param {callback} - callback
 * @example
 * CaMDOIntegration.exitPrivateZone(callback);
 */
CaMDOIntegration.exitPrivateZone = function(callback) {
    var dictionary = {};
    dictionary.action = "exitPrivateZone";
    if (callback) {
        dictionary.callback = callback;
    }
    sendIntegrationEvent(dictionary);
};

/**
 * @function disableSDK
 * @description  Disables SDK if its enabled.
 * When SDK is disabled, SDK will not intercept any calls and wont collect any data from App.
 * @param {callback} - callback
 * @example
 * CaMDOIntegration.disableSDK(callback);
 *
 */
CaMDOIntegration.disableSDK = function(callback) {
    var dictionary = {};
    dictionary.action = "disableSDK";
    if (callback) {
        dictionary.callback = callback;
    }
    sendIntegrationEvent(dictionary);
};



/**
 * @function stopCurrentAndStartNewSession
 * @description  Stops Current session and starts a new session.
 * @param {callback} - callback
 * @example
 * CaMDOIntegration.stopCurrentAndStartNewSession(callback);
 *
 */
CaMDOIntegration.stopCurrentAndStartNewSession = function(callback) {
    var dictionary = {};
    dictionary.action = "stopCurrentAndStartNewSession";
    if (callback) {
        dictionary.callback = callback;
    }
    sendIntegrationEvent(dictionary);
};

/**
 * @function uploadEvents
 * @description  Initiates an upload of the aggregated event(s). Don't expect a callback, on the
 * status of this operation.
 * @example
 * CaMDOIntegration.uploadEvents();
 *
 */
CaMDOIntegration.uploadEvents = function() {
    var dictionary = {};
    dictionary.action = "uploadEvents";
    sendIntegrationEvent(dictionary);
};


/**
 * @function logNetworkEvent
 * @description  Logs a network event.
 * @param {callback} - callback
 * @param {evt} - evt
 * @example
 * CaMDOIntegration.logNetworkEvent({
 * "url" : "http://httpbin.org/",
 * "status" : "200",
 * "inbytes" : "23"
 * "outbytes" : "23"
 * "time" : "45"   //time in ms
 *    },callback);
 *
 */
CaMDOIntegration.logNetworkEvent = function(evt,callback) {
    var dictionary = {};
    dictionary.action = "logNetworkEvent";
    dictionary.url = evt.url;
    dictionary.status = evt.status;
    dictionary.inbytes = evt.inbytes;
    dictionary.outbytes = evt.outbytes;
    dictionary.responsetime = evt.time;
    if (callback) {
        dictionary.callback = callback;
    }
    sendIntegrationEvent(dictionary);
};



/**
 * @function viewLoaded
 * @description Adds a lifecycle event that page or screen is loaded , Takes screenshot of current screen and adds an event to analytics.
 * @param {string} screenName - name of the screen for which screenshot will be taken.
 * @param {callback} callback - callback.
 *      @example
 *      CaMDOIntegration.viewLoaded("Shopping",callback);
 */

CaMDOIntegration.viewLoaded = function(screenName,screenloadtime,callback) {
    var dictionary = {};
    dictionary.action = "viewLoaded";
    dictionary.screenname = screenName;
    dictionary.screenloadtime=screenloadtime;
    dictionary.callback = callback;
    sendIntegrationEvent(dictionary);
};

/**
 * @function enterPrivateZone
 * @description  In Private Zone screenshots and other sensitive information will not be recorded.
 * @param {callback} - callback
 * @example
 * CaMDOIntegration.disableSDK(callback);
 */
CaMDOIntegration.enterPrivateZone = function(callback) {
    var dictionary = {};
    dictionary.action = "enterPrivateZone";
    if (callback) {
        dictionary.callback = callback;
    }
    sendIntegrationEvent(dictionary);
};

function sendIntegrationEvent(dictionary) {
    sendMAASDKEvent(dictionary);
}

/**
 * @function : winow.onError : A Call back method that detects js related errors/ crashes.
 * @param : {message} : Error message obtained after crash
 * @param : {url} : url on which the error has occured.
 * @param : {lineNumber} : line on which the error has occured.
 * @param : {columnNumber} : column on which the error has occured.
 * @param : {errorObj} : Error object received after error has occured.
 */

window.onerror = function(message, url, lineNumber,columnNumber,errorObj) {
    var dictionary = {};
    dictionary.action = "addSessionEvent";
    dictionary.type = "string";
    dictionary.key = "jserror";
    dictionary.value = message;
    var stacktrace = undefined;
    if(errorObj){
        stacktrace = errorObj["stack"].toString();
    }
    if(stacktrace) {
        dictionary.attributes = {"l":lineNumber,"u":url , "s": stacktrace};
    }
    else {
        dictionary.attributes = {"l":lineNumber,"u":url};
    }
    sendIntegrationEvent(dictionary);
    
    return true;
};


/**
 
 * @private
 * Creates unique name global function and assign user passed callback function
 * to that.
 *
 */
var preProcess = function(nativeCallInfo,isIOS) {
    try {
        if (nativeCallInfo.callback && typeof nativeCallInfo.callback === "function") {
            var callbackfn_name = callback_uuid();
            window[callbackfn_name] = nativeCallInfo.callback;
            nativeCallInfo.callback = "";
            //iOS & SDK Code needs to remove this global object by calling delete window[callbackfn_name];
            //this is the name of callback function native SDK will use.
            nativeCallInfo.callbackfn_name = callbackfn_name;
        }
        
        if(isIOS && nativeCallInfo.quality) {
            var intQuality = parseInt(nativeCallInfo.quality);
            var iosQuality = (intQuality/100)+"";
            nativeCallInfo.quality = iosQuality;
        }
        
    } catch (e) {}
};

/*
 Calls the UIWebView
 */
function SendMAAEventToUIWebView(dictionaryObj) {
    //just making sure action is present and not using it further.
    var action = dictionaryObj.action;
    if (action == null) {
        return;
    }
    var iframe = document.createElement('iframe');
    iframe.setAttribute('src', "camaa://" + JSON.stringify(dictionaryObj));
    document.documentElement.appendChild(iframe);
    iframe.parentNode.removeChild(iframe);
    iframe = null;
}

/**
 * @private
 *
 */

var sendMAASDKEvent = function(nativeCallInfo) {
    //Android Integration
    if (typeof CaMaaAndroidIntegration != 'undefined') {
        preProcess(nativeCallInfo,false);
        CaMaaAndroidIntegration.postMessage(JSON.stringify(nativeCallInfo));
    }
    //iOS WKWebview
    else if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.camaa) {
        preProcess(nativeCallInfo,true);
        try {
            window.webkit.messageHandlers.camaa.postMessage(nativeCallInfo);
        }
        catch (e) {
        }
    }
    //UI Webview
    else if (window.camaawebview) { // if in ios webview
        preProcess(nativeCallInfo,true);
        SendMAAEventToUIWebView(nativeCallInfo);
    }
    //Do not call , just call callback passed.
    else {
        // For any other mobiles as well as api got called without wrapping.t
        if (nativeCallInfo.callback) {
            nativeCallInfo.callback(nativeCallInfo.action, null, "NATIVE_CALL_NOT_EXECUTED");
        }
    }
};

/**
 * @private
 */
var callback_uuid = function() {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
    }
    return "callback_" + s4() + s4() + '_' + s4() + '_' + s4() + '_' + s4() + '_' + s4() + s4() + s4();
};