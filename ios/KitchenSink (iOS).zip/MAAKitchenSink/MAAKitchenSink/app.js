//app js


function screenshotApi() {
    alert('call screenshot');
    try {
        CaMDOIntegration.sendScreenShot("CA Agile Value!!",CaMDOIntegration.quality.high,callback);
    } catch (e) {
        alert(e);
    }
    
}
function screenshotApiM() {
    alert('call screenshot');
    try {
        CaMDOIntegration.sendScreenShot("CA Agile Value!! (Medium)",CaMDOIntegration.quality.medium,callback);
    } catch (e) {
        alert(e);
    }
    
}

function screenshotApiL() {
    alert('call screenshot');
    try {
        CaMDOIntegration.sendScreenShot("CA Agile Value!! (Low)",CaMDOIntegration.quality.low,callback);
    } catch (e) {
        alert(e);
    }
    
}

function isSDKEnabled() {
    
    try{
        
        CaMDOIntegration.isSDKEnabled(callback);
        
    }
    catch(e){
        alert(e);
    }
}


function isInPrivateZone() {
    
    try{
        
        CaMDOIntegration.isInPrivateZone(callback);
        
    }
    catch(e){
        alert(e);
    }
}




function callback(action, value , error) {
    //    alert("Return value for " + action + " = " + value);
    if(value) {
        alert('Callback called. and error .'+JSON.stringify(value )+'-'+error);
    }
    else {
        alert('Callback called..no return val..and error'+JSON.stringify(error));
    }
}

function addSessionEvent() {
    alert('add session');
    try {
        var evt = {};
        evt.type = document.getElementById("addsessioneventtypeid").value;
        evt.key = document.getElementById("addsessioneventnameid").value;
        evt.value = document.getElementById("addsessioneventvalueid").value;
        CaMDOIntegration.addSessionEvent(evt, callback);
    } catch (e) {
        alert(e);
    }
}

/**
 *   @name SessionInfo
 *   @property {string}  type       -    Session info  type valid values are customerId, double , string.
 *   @property {string}  key        -    Session info  key
 *   @property {string}  value      -    Session info  value
 *
 */
function setSessionInfo() {
    try {
        var evt = {};
        evt.type = document.getElementById("setsessiontype").value;
        evt.key = document.getElementById("setsessionname").value;
        evt.value = document.getElementById("setsessionval").value;
        CaMDOIntegration.setSessionInfo(evt, callback);
    } catch (e) {
        alert(e);
    }
}

/**
 *   @name Location
 *   @property {string}  zipCode       -    Zipcode
 *   @property {string}  countryCode   -    Country code
 *
 */
function setCustomerLocation() {
    try {
        var evt = {};
        evt.zipCode = document.getElementById("zipCode").value;
        evt.countryCode = document.getElementById("countryCode").value;
        CaMDOIntegration.setCustomerLocation(evt, callback);
    } catch (e) {
        alert(e);
    }
}



function setCustomerFeedback() {
    try {
        var fb = document.getElementById("customerFeedback").value;
        CaMDOIntegration.setCustomerFeedback(fb, callback);
    } catch (e) {
        alert(e);
    }
}


function enableSDK() {
    try {
        CaMDOIntegration.enableSDK(callback);
    } catch (e) {
        alert(e);
    }
    
}

function disableSDK() {
    try {
        CaMDOIntegration.disableSDK(callback);
    } catch (e) {
        alert(e);
    }
}

function enterPrivateZone() {
    try {
        CaMDOIntegration.enterPrivateZone(callback);
    } catch (e) {
        alert(e);
    }
}

function exitPrivateZone() {
    try {
        CaMDOIntegration.exitPrivateZone(callback);
    } catch (e) {
        alert(e);
    }
}

function stopCurrentAndStartNewSession(){
    try{
        CaMDOIntegration.stopCurrentAndStartNewSession(callback);
    }catch(e){
        alert(e);
    }
}

/**
 *   @name Transaction
 *   @property {string}  transactionName       -  Name of the transaction.
 *   @property {string}  serviceName           -  Name of service/screen.
 *   @property {string}  failure               -  Failure reason in case of stop transaction.
 */

function startApplicationTransaction() {
    try {
        var evt = {};
        evt.transactionName = document.getElementById("stransactionname").value;
        evt.serviceName = document.getElementById("stransactionservice").value;
        evt.failure = document.getElementById("stransactionfail").value;
        CaMDOIntegration.startApplicationTransaction(evt, callback);
    } catch (e) {
    }
}

function stopApplicationTransaction() {
    try {
        var evt = {};
        evt.transactionName = document.getElementById("stpransactionname").value;
        evt.serviceName = document.getElementById("stpransactionservice").value;
        evt.failure = document.getElementById("stpransactionfail").value;
        CaMDOIntegration.stopApplicationTransaction(evt, callback);
    } catch (e) {
        alert(e);
    }
    
}

function logNetworkEvent(){
    try{
        var evt = {};
        evt.url = document.getElementById("networkurl").value;
        evt.status = document.getElementById("networkstatus").value;
        evt.inbytes = document.getElementById("networkinbytes").value;
        evt.outbytes = document.getElementById("networkoutbytes").value;
        evt.time = document.getElementById("networkresponsetime").value;
        CaMDOIntegration.logNetworkEvent(evt,callback);
    }catch(e){
        alert(e);
    }
}

function makeError(){
     adddlert("Welcome guest!");
}
