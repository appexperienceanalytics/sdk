//
//  MyNetworkSessionDownloadTaskWithHandler.m
//  CAMSMDemo
//
//  Created by Nilesh on 3/27/15.
//  Copyright (c) 2015 CA Technologies, Inc. All rights reserved.
//

#import "MyNetworkSessionDownloadTaskWithHandler.h"

@implementation MyNetworkSessionDownloadTaskWithHandler

- (void)performRequest:(NSURLRequest *)request onQueue:(NSOperationQueue *)queue
{
    NSURLSessionConfiguration *config =[NSURLSessionConfiguration defaultSessionConfiguration];

    NSURLSession *session = [NSURLSession sessionWithConfiguration:config
                                                          delegate:nil
                                                     delegateQueue:queue];

    [[session downloadTaskWithRequest:request completionHandler:^(NSURL *location,
                                                                  NSURLResponse *response,
                                                                  NSError *error)
      {
          [self.delegate requestCompletedWithResponse:response andError:error];
      }] resume];
}

@end
