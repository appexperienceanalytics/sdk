//
//  MyNetworkSyncHandler.m
//  CAMSMDemo
//
//  Created by Nilesh on 3/27/15.
//  Copyright (c) 2015 CA Technologies, Inc. All rights reserved.
//

#import "MyNetworkSyncHandler.h"

@implementation MyNetworkSyncHandler

- (void)performRequest:(NSURLRequest *)request onQueue:(NSOperationQueue *)queue
{
    NSBlockOperation *op = [NSBlockOperation blockOperationWithBlock:^(void) {
        NSURLResponse *response = nil;
        NSError *error = nil;

        [NSURLConnection sendSynchronousRequest:request
                              returningResponse:&response
                                          error:&error];

        [self.delegate requestCompletedWithResponse:response andError:error];
    }];
        [queue addOperation:op];
}

@end
