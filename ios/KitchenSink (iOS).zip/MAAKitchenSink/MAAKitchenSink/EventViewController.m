//
//  EventViewController.m
//  CAMAADemoApp
//
//  Created by Nilesh on 4/5/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import "EventViewController.h"
#import "CMPopTipView.h"
#import "UIView+ViewEffects.h"
#import "UIButton+ButtonEffects.h"
#import "UILabel+LabelEffects.h"
#import "FXBlurView.h"
#import "UIColor+FlatUI.h"
#import "UISlider+FlatUI.h"
#import "FUIButton.h"
#import "UIFont+FlatUI.h"
#import "UIStepper+FlatUI.h"

#import "ButtonViewCell.h"
#import "SliderCollectionViewCell.h"
#import "StepperCollectionViewCell.h"
#import "SegmentControlCollectionViewCell.h"
#import "ActivityIndicatorCollectionViewCell.h"
#import "SwitchCollectionViewCell.h"
#import "DatePickerCollectionViewCell.h"
#import "UIView+ViewEffects.h"
#import "BFPaperButton.h"
#import "UIColor+BFPaperColors.h"



#define foo4random() (1.0 * (arc4random() % ((unsigned)RAND_MAX + 1)) / RAND_MAX)

@interface EventViewController ()
@property (weak, nonatomic) IBOutlet UIView *eventsTitleBar;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet FXBlurView *blurView;
@property (weak, nonatomic) IBOutlet UILabel *lbutton;
@property (weak, nonatomic) IBOutlet UILabel *lSwitch;
@property (weak, nonatomic) IBOutlet UILabel *lSlider;
@property (weak, nonatomic) IBOutlet UILabel *lStepper;
@property (weak, nonatomic) IBOutlet UILabel *lSegmentedControl;
@property (weak, nonatomic) IBOutlet UILabel *lDatePicker;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *sampleActivityIndicator;


@property (weak, nonatomic) IBOutlet UIDatePicker *dpDatePicker;
@property (weak, nonatomic) IBOutlet UISwitch *bSwitch;
@property (weak, nonatomic) IBOutlet UISlider *bSlider;
@property (weak, nonatomic) IBOutlet UIStepper *bStepper;
@property (weak, nonatomic) IBOutlet UISegmentedControl *bSegmentedControl;
@property (weak, nonatomic) IBOutlet FUIButton *bStart;
@property (weak, nonatomic) IBOutlet FUIButton *bStop;

@property (weak, nonatomic) IBOutlet FUIButton *bButton;


/*Pop view Controller */
@property (nonatomic, strong)	NSArray			*colorSchemes;
@property (nonatomic, strong)	NSDictionary	*contents;
@property (nonatomic, strong)	id				currentPopTipViewTarget;
@property (nonatomic, strong)	NSDictionary	*titles;
@property (nonatomic, strong)	NSMutableArray	*visiblePopTipViews;


/*Ignore Views */
@property (weak, nonatomic) IBOutlet UIView *ignoreView1;
@property (weak, nonatomic) IBOutlet UIView *ignoreView2;
@property (weak, nonatomic) IBOutlet UIView *ignoreView3;
@property (weak, nonatomic) IBOutlet UIView *ignoreView4;
@property (weak, nonatomic) IBOutlet UIView *ignoreView5;

/*Divider Views */
@property (weak, nonatomic) IBOutlet UIView *dividerView1;
@property (weak, nonatomic) IBOutlet UIView *dividerView2;
@property (weak, nonatomic) IBOutlet UIView *dividerView3;
@property (weak, nonatomic) IBOutlet UIView *dividerView4;
@property (weak, nonatomic) IBOutlet UIView *dividerView5;
@property (weak, nonatomic) IBOutlet UIView *dividerView6;
@property (weak, nonatomic) IBOutlet UIView *dividerView7;
@property (weak, nonatomic) IBOutlet UIView *dividerView8;

@property (weak, nonatomic) IBOutlet UICollectionView *eventsCollectionView;



@end

@implementation EventViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //[self setupBlurBackground];

    
    [self setupView];

    }

-(void)setupView{

    
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    CGFloat width = (CGRectGetWidth(self.view.frame));
    CGFloat height = (CGRectGetHeight(self.view.frame));
    [flowLayout setItemSize:CGSizeMake(width, height/7)];
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
    
    flowLayout.minimumInteritemSpacing = 10.0f;
    flowLayout.minimumLineSpacing=0.0f;
    
    [_eventsCollectionView setCollectionViewLayout:flowLayout];
    _eventsTitleBar.backgroundColor = [UIColor paperColorBlue];
    [_dividerView1 makeSquareTransperant];
    [_dividerView2 makeSquareTransperant];
    [_dividerView3 makeSquareTransperant];
    [_dividerView4 makeSquareTransperant];
    [_dividerView5 makeSquareTransperant];
    [_dividerView6 makeSquareTransperant];
    [_dividerView7 makeSquareTransperant];
    [_dividerView8 makeSquareTransperant];


    /*Setup IgnoreViews*/
    [_ignoreView1 hideIgnoreView];
    [_ignoreView2 hideIgnoreView];
    [_ignoreView3 hideIgnoreView];
    [_ignoreView4 hideIgnoreView];
    [_ignoreView5 hideIgnoreView];

    /*Setup  Labels*/
    [_lbutton makeLabelBlack];
    [_lSwitch makeLabelBlack];
    [_lStepper makeLabelBlack];
    [_lSlider makeLabelBlack];
    [_lSegmentedControl makeLabelBlack];
    [_lDatePicker makeLabelBlack];

    /*Setup PopViewController*/
    [self setupPopViewController];

 
    
    [self makeFlatButton:_bButton];
    [self makeFlatButton:_bStart];
    [self makeFlatButton:_bStop];
    
    /*Slider*/
    [_bSlider setTintColor:[UIColor blackColor]];
    [_bSlider configureFlatSliderWithTrackColor:[UIColor silverColor]
                                  progressColor:[UIColor alizarinColor]
                                     thumbColor:[UIColor pomegranateColor]];

    /*Stepper*/
    //[_bStepper setTintColor:[UIColor blackColor]];
    [self makeFlatStepper:_bStepper];
    /*Switch*/
    [_bSwitch setTintColor:[UIColor blackColor]];
    

    /*SegmentedControl*/
    [_bSegmentedControl setTintColor:[UIColor blackColor]];
    
    /*DatePicker*/
    [_dpDatePicker setTintColor:[UIColor blackColor]];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - IBActions .

#pragma mark - PopViewcontroller Methods.


-(void)setupPopViewController{
    self.visiblePopTipViews = [NSMutableArray array];

    self.contents = [NSDictionary dictionaryWithObjectsAndKeys:
                     // Rounded rect buttons
                     @"A CMPopTipView will automatically position itself within the container view.", [NSNumber numberWithInt:11],
                     @"A CMPopTipView will automatically orient itself above or below the target view based on the available space.", [NSNumber numberWithInt:12],
                     @"A CMPopTipView always tries to point at the center of the target view.", [NSNumber numberWithInt:13],
                     @"A CMPopTipView can point to any UIView subclass.", [NSNumber numberWithInt:14],
                     @"A CMPopTipView will automatically size itself to fit the text message.", [NSNumber numberWithInt:15],
                     [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"appicon57.png"]], [NSNumber numberWithInt:16],	// content can be a UIView
                     // Nav bar buttons
                     @"This CMPopTipView is pointing at a leftBarButtonItem of a navigationItem.", [NSNumber numberWithInt:21],
                     @"Two popup animations are provided: slide and pop. Tap other buttons to see them both.", [NSNumber numberWithInt:22],
                     // Toolbar buttons
                     @"CMPopTipView will automatically point at buttons either above or below the containing view.", [NSNumber numberWithInt:31],
                     @"The arrow is automatically positioned to point to the center of the target button.", [NSNumber numberWithInt:32],
                     @"CMPopTipView knows how to point automatically to UIBarButtonItems in both nav bars and tool bars.", [NSNumber numberWithInt:33],
                     nil];
    self.titles = [NSDictionary dictionaryWithObjectsAndKeys:
                   @"Title", [NSNumber numberWithInt:14],
                   @"Auto Orientation", [NSNumber numberWithInt:12],
                   nil];

    // Array of (backgroundColor, textColor) pairs.
    // NSNull for either means leave as default.
    // A color scheme will be picked randomly per CMPopTipView.
    self.colorSchemes = [NSArray arrayWithObjects:
                         [NSArray arrayWithObjects:[NSNull null], [NSNull null], nil],
                         [NSArray arrayWithObjects:[UIColor colorWithRed:134.0/255.0 green:74.0/255.0 blue:110.0/255.0 alpha:1.0], [NSNull null], nil],
                         [NSArray arrayWithObjects:[UIColor darkGrayColor], [NSNull null], nil],
                         [NSArray arrayWithObjects:[UIColor lightGrayColor], [UIColor darkTextColor], nil],
                         [NSArray arrayWithObjects:[UIColor orangeColor], [UIColor blueColor], nil],
                         [NSArray arrayWithObjects:[UIColor colorWithRed:220.0/255.0 green:0.0/255.0 blue:0.0/255.0 alpha:1.0], [NSNull null], nil],
                         nil];

}



#pragma mark - PopView Controller

- (void)dismissAllPopTipViews
{
    while ([self.visiblePopTipViews count] > 0) {
        CMPopTipView *popTipView = [self.visiblePopTipViews objectAtIndex:0];
        [popTipView dismissAnimated:YES];
        [self.visiblePopTipViews removeObjectAtIndex:0];
    }
}

- (IBAction)openPopUp:(id)sender
{
    [self dismissAllPopTipViews];

    if (sender == self.currentPopTipViewTarget) {
        // Dismiss the popTipView and that is all
        self.currentPopTipViewTarget = nil;
    }
    else {
        NSString *contentMessage = nil;
        UIView *contentView = nil;
        NSNumber *key = [NSNumber numberWithInteger:[(UIView *)sender tag]];
        id content = [self.contents objectForKey:key];
        if ([content isKindOfClass:[UIView class]]) {
            contentView = content;
        }
        else if ([content isKindOfClass:[NSString class]]) {
            contentMessage = content;
        }
        else {
            contentMessage = @"A CMPopTipView can automatically point to any view or bar button item.";
        }
        NSArray *colorScheme = [self.colorSchemes objectAtIndex:foo4random()*[self.colorSchemes count]];
        UIColor *backgroundColor = [colorScheme objectAtIndex:0];
        UIColor *textColor = [colorScheme objectAtIndex:1];

        NSString *title = [self.titles objectForKey:key];

        CMPopTipView *popTipView;
        if (contentView) {
            popTipView = [[CMPopTipView alloc] initWithCustomView:contentView];
        }
        else if (title) {
            popTipView = [[CMPopTipView alloc] initWithTitle:title message:contentMessage];
        }
        else {
            popTipView = [[CMPopTipView alloc] initWithMessage:contentMessage];
        }
        popTipView.delegate = self;

        /* Some options to try.
         */
        //popTipView.disableTapToDismiss = YES;
        //popTipView.preferredPointDirection = PointDirectionUp;
        //popTipView.hasGradientBackground = NO;
        //popTipView.cornerRadius = 2.0;
        //popTipView.sidePadding = 30.0f;
        //popTipView.topMargin = 20.0f;
        //popTipView.pointerSize = 50.0f;
        //popTipView.hasShadow = NO;

        if (backgroundColor && ![backgroundColor isEqual:[NSNull null]]) {
            popTipView.backgroundColor = backgroundColor;
        }
        if (textColor && ![textColor isEqual:[NSNull null]]) {
            popTipView.textColor = textColor;
        }

        popTipView.animation = arc4random() % 2;
        popTipView.has3DStyle = (BOOL)(arc4random() % 2);

        popTipView.dismissTapAnywhere = YES;
        [popTipView autoDismissAnimated:YES atTimeInterval:3.0];

        if ([sender isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)sender;
            [popTipView presentPointingAtView:button inView:self.view animated:YES];
        }
        else {
            UIBarButtonItem *barButtonItem = (UIBarButtonItem *)sender;
            [popTipView presentPointingAtBarButtonItem:barButtonItem animated:YES];
        }

        [self.visiblePopTipViews addObject:popTipView];
        self.currentPopTipViewTarget = sender;
    }
}


#pragma mark - CMPopTipViewDelegate methods

- (void)popTipViewWasDismissedByUser:(CMPopTipView *)popTipView
{
    [self.visiblePopTipViews removeObject:popTipView];
    self.currentPopTipViewTarget = nil;
}


#pragma mark - UIViewController methods

- (void)willAnimateRotationToInterfaceOrientation:(__unused UIInterfaceOrientation)toInterfaceOrientation duration:(__unused NSTimeInterval)duration
{
    for (CMPopTipView *popTipView in self.visiblePopTipViews) {
        id targetObject = popTipView.targetObject;
        [popTipView dismissAnimated:NO];

        if ([targetObject isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)targetObject;
            [popTipView presentPointingAtView:button inView:self.view animated:NO];
        }
        else {
            UIBarButtonItem *barButtonItem = (UIBarButtonItem *)targetObject;
            [popTipView presentPointingAtBarButtonItem:barButtonItem animated:NO];
        }
    }
}

#pragma mark - UICollection View DataSource Methods
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 7;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    //Cell from the prototype
    //UICollectionViewCell *Cell;
    if(indexPath.row==0){
        ButtonViewCell *buttonCell = [collectionView dequeueReusableCellWithReuseIdentifier:@"buttonCell" forIndexPath:indexPath];
        [buttonCell customSetup];
        buttonCell.eventButton.isRaised = YES;
        buttonCell.eventButton.backgroundColor = [UIColor paperColorBlue];
        
        return buttonCell;
    }else if(indexPath.row == 2){
        SegmentControlCollectionViewCell *segmentViewCell =[collectionView dequeueReusableCellWithReuseIdentifier:@"segmentControlCell" forIndexPath:indexPath];
       // [segmentViewCell setUpTransperantViewBlackBorder];
        [segmentViewCell customSetup];
        return segmentViewCell;
    }else if(indexPath.row ==3){
        SliderCollectionViewCell *sliderViewCell = [collectionView dequeueReusableCellWithReuseIdentifier:@"sliderCell" forIndexPath:indexPath];
        [sliderViewCell customSetup];
        [sliderViewCell.eventSlider configureFlatSliderWithTrackColor:[UIColor silverColor]
                                      progressColor:[UIColor paperColorBlue]
                                         thumbColor:[UIColor paperColorBlue]];
              [sliderViewCell customSetup];
        return sliderViewCell;
    }else if(indexPath.row ==4){
        StepperCollectionViewCell *stepperViewCell =[collectionView dequeueReusableCellWithReuseIdentifier:@"stepperCell" forIndexPath:indexPath];
        [self makeFlatStepper:stepperViewCell.myStepper];
      
        [stepperViewCell customSetup];
        return stepperViewCell;
    }else if(indexPath.row ==5){
        SwitchCollectionViewCell *switchViewCell =[collectionView dequeueReusableCellWithReuseIdentifier:@"switchCell" forIndexPath:indexPath];
        
        [switchViewCell customSetup];
        return switchViewCell;
    }else if(indexPath.row == 6){
        DatePickerCollectionViewCell *dateViewCell = [collectionView dequeueReusableCellWithReuseIdentifier:@"datePickerCell" forIndexPath:indexPath];
      
        [dateViewCell customSetup];
        return dateViewCell;
    }else{
        ActivityIndicatorCollectionViewCell *activityViewCell =[collectionView dequeueReusableCellWithReuseIdentifier:@"activityIndicatorCell" forIndexPath:indexPath];
        
        activityViewCell.bStart.isRaised = YES;
        activityViewCell.bStop.isRaised = YES;
        activityViewCell.bStart.backgroundColor = [UIColor paperColorBlue];
        activityViewCell.bStop.backgroundColor = [UIColor paperColorBlue];
        
        [activityViewCell customSetup];
        return activityViewCell;
    }
    
    
    return nil;
    //Prepare the Cell UI.
    
    // return buttonCell;
}




#pragma mark - Flat Button 
-(void)makeFlatButton:(FUIButton *)myButton{
    myButton.buttonColor = [UIColor turquoiseColor];
    myButton.shadowColor = [UIColor greenSeaColor];
    myButton.shadowHeight = 3.0f;
    myButton.cornerRadius = 6.0f;
    myButton.titleLabel.font = [UIFont boldFlatFontOfSize:16];
    [myButton setTitleColor:[UIColor cloudsColor] forState:UIControlStateNormal];
    [myButton setTitleColor:[UIColor cloudsColor] forState:UIControlStateHighlighted];
}


-(void)makeFlatStepper:(UIStepper *)myStepper{
    
    [myStepper configureFlatStepperWithColor:[UIColor paperColorBlue]                            highlightedColor:[UIColor paperColorBlue]
                               disabledColor:[UIColor amethystColor]
                                   iconColor:[UIColor cloudsColor]];}




@end
