//
//  JSErrorViewController.m
//  CAMobileAppAnalytics
//
//  Created by Nilesh Agrawal on 5/24/16.
//  Copyright © 2016 CA Technologies. All rights reserved.
//

#import "JSErrorViewController.h"

@interface JSErrorViewController ()
@property (weak, nonatomic) IBOutlet UIWebView *jsErrorWebView;

@end

@implementation JSErrorViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _jsErrorWebView.delegate = self;
    [self loadUIWebViewFromURL];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(void)loadUIWebViewFromURL{
    NSString *urlString = @"http://desma12-u172793:8080/brt/index.html";
    [_jsErrorWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:urlString]]];
}

@end
