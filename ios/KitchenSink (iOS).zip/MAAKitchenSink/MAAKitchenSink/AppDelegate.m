//
//  AppDelegate.m
//  CAMAADemoApp
//
//  Created by Nilesh on 4/4/15.
//  Copyright (c) 2015 NDA. All rights reserved.
//

#import "AppDelegate.h"
//TAG:DECTRAINING
//#import "CAMDOReporter.h"

#import <Fabric/Fabric.h>
#import <Crashlytics/Crashlytics.h>

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
   // sleep(1);
    CrashlyticsKit.delegate = self;

    [Fabric with:@[[Crashlytics class]]];
    
//    [CAMDOReporter initializeSDKWithOptions:(SDKLogLevelVerbose)];
    //TAG:DECTRAINING
//    [CAMDOReporter initializeSDKWithOptions:(SDKLogLevelVerbose| SDKNoCrashReporting)];
    
    NSLog(@"%@",[[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject]); 
    return YES;
}


- (void)crashlyticsDidDetectReportForLastExecution:(CLSReport *)report completionHandler:(void (^)(BOOL))completionHandler {
    // Use this opportunity to take synchronous action on a crash. See Crashlytics.h for
    // details and implications.
    
    // Maybe consult NSUserDefaults or show a UI prompt.
    
    // But, make ABSOLUTELY SURE you invoke completionHandler, as the SDK
    // will not submit the report until you do. You can do this from any
    // thread, but that's optional. If you want, you can just call the
    // completionHandler and return.
    NSLog(@" CKKKKKK ...in callback %@ %@ ",[report identifier], [report debugDescription]);
    for(NSString *key in [[report customKeys] allKeys]) {
        NSLog(@"CKKKKKKK %@",[[report customKeys] objectForKey:key]);
    }
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *cachePath = [paths objectAtIndex:0];
    
    
    NSLog(@"CKKKKK Path ....%@",cachePath);
    

    
    // else you can give your folder path as well, if you know
    // for example like this NSString *docsDir = @"user/desktop/testFolder"
    
    NSFileManager *localFileManager = [NSFileManager defaultManager];
    NSDirectoryEnumerator *dirEnum = [localFileManager enumeratorAtPath:cachePath];
    NSString *file = nil;
    NSData *fileContents = [NSData data];
    while ((file = [dirEnum nextObject]))
    {
        NSLog(@"CKKKK your file name%@",file); // This will give your filename
        // Now for getting file path follow below.
        // here we are adding pathcachePathto filename.
        NSString *fileNamePath = [cachePath stringByAppendingPathComponent:file];
        NSLog(@"CKKKK your fileNamePath%@",fileNamePath); // This will give your filename path
        fileContents = [NSData dataWithContentsOfFile:fileNamePath]; // This will store file contents in form of bytes
        
    }
    
    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
        completionHandler(NO);
    }];
}

//- (void)applicationWillResignActive:(UIApplication *)application {
//    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
//    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
//}

//- (void)applicationDidEnterBackground:(UIApplication *)application {
//    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
//    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
//}

//- (void)applicationWillEnterForeground:(UIApplication *)application {
//    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
//}

//- (void)applicationDidBecomeActive:(UIApplication *)application {
//    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
//}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
