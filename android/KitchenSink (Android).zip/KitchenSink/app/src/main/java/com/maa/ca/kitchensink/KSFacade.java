package com.maa.ca.kitchensink;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Application;
import android.os.Bundle;

import java.util.ArrayList;

/**
 * Created by kanch06 on 6/14/16.
 */

@TargetApi(16)
public class KSFacade  implements Application.ActivityLifecycleCallbacks{


    ArrayList<Application.ActivityLifecycleCallbacks> clientCallbacks = new ArrayList();


    public void registerActivityLifecycleCallbacks(Application.ActivityLifecycleCallbacks callbacks) {
        this.clientCallbacks.add(callbacks);
    }

    public void unregisterActivityLifecycleCallbacks(Application.ActivityLifecycleCallbacks callbacks) {
        this.clientCallbacks.remove(callbacks);
    }

    public void onActivityCreated(Activity activity, Bundle bundle)
    {
        if (this.clientCallbacks.size() > 0)
            for (Application.ActivityLifecycleCallbacks callbacks : this.clientCallbacks)
                callbacks.onActivityCreated(activity, bundle);
    }

    public void onActivityStarted(Activity activity)
    {
        if (this.clientCallbacks.size() > 0)
            for (Application.ActivityLifecycleCallbacks callbacks : this.clientCallbacks)
                callbacks.onActivityStarted(activity);
    }

    public void onActivityResumed(Activity activity)
    {
        if (this.clientCallbacks.size() > 0)
            for (Application.ActivityLifecycleCallbacks callbacks : this.clientCallbacks)
                callbacks.onActivityResumed(activity);
    }

    public void onActivityPaused(Activity activity)
    {
        if (this.clientCallbacks.size() > 0)
            for (Application.ActivityLifecycleCallbacks callbacks : this.clientCallbacks)
                callbacks.onActivityPaused(activity);
    }

    public void onActivityStopped(Activity activity)
    {
        if (this.clientCallbacks.size() > 0)
            for (Application.ActivityLifecycleCallbacks callbacks : this.clientCallbacks)
                callbacks.onActivityStopped(activity);
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle bundle)
    {
        if (this.clientCallbacks.size() > 0)
            for (Application.ActivityLifecycleCallbacks callbacks : this.clientCallbacks)
                callbacks.onActivitySaveInstanceState(activity, bundle);
    }

    public void onActivityDestroyed(Activity activity)
    {
        if (this.clientCallbacks.size() > 0)
            for (Application.ActivityLifecycleCallbacks callbacks : this.clientCallbacks)
                callbacks.onActivityDestroyed(activity);
    }
}
