package com.maa.ca.kitchensink;

/**
 * Created by NileshAgrawal on 5/12/15.
 */
public class Constants {

    public static final String LOG_TAG = "CAMAAKitchenSink";


}
