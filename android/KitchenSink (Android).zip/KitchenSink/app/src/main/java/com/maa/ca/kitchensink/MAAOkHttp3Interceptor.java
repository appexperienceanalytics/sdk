package com.maa.ca.kitchensink;

import com.ca.integration.CaMDOIntegration;

import java.io.IOException;

//import okhttp3.Interceptor;
//import okhttp3.Request;
//import okhttp3.Response;

/**
 * Created by Rutvijkumar Shah  on 5/19/16.
 *
 */

/**
 * OkHttp 3 Application Interceptor for MAA Android SDK.
 *
 * This class is only required if your project is using okhttp directly or via other lib dependency.
 *
 * Integrate this class in your project to capture Network traffic sent over OkHttp Library
 * Copy this source code to your project's source directory. This source file has dependency on
 * Okhttp 3.2 or above, please ensure that okhttp dependency is there in gradle file.
 *
 * <p>
 *     Please note that this Interceptor is supported only for OkHttp 3.2 and above.
 * </p>
 *
 * @author  Rutvijkumar Shah
 * @version 1.0
 */
public class MAAOkHttp3Interceptor {//implements Interceptor {


//    @Override
//    public Response intercept(Chain chain) throws IOException {
//        long startTime = System.currentTimeMillis();
//        Request request = chain.request();
//        long urlBodyBytes,urlBytes;
//
//        long inBytes=0;
//        long outBytes=0;
//        int statusCode=0;
//        String  url=null;
//
//        if(request !=null && request.url()!=null ) {
//           url = request.url().toString();
//            urlBytes = url.length();
//            if (request.body() != null) {
//                urlBodyBytes = request.body().contentLength();
//            }else {
//                urlBodyBytes=0;
//            }
//            inBytes = urlBytes + urlBodyBytes;
//        }
//        Response response = chain.proceed(request);
//        if(response!=null){
//            statusCode=response.code();
//            if(response.body()!=null ) {
//                outBytes=response.body().contentLength();
//            }
//        }
//        long responseTime=System.currentTimeMillis() -startTime;
//        if(url!=null) {
//            CaMDOIntegration.logNetworkEvent(url, statusCode, (int) responseTime, (int) inBytes, (int) outBytes);
//        }
//         return response;
//    }
}
