package com.maa.ca.kitchensink;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;

import com.ca.integration.CaMDOIntegration;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class WebViewActivity extends BaseActivity implements View.OnClickListener{


    Button bYoutube,bTechCrunch, bStackOverflow,bGo, bJSApi,bCrashActivity,bNetworkActivity,bAPIActivity,bWebViewAcitivity,bEventsActivity;
    EditText etWebViewUrlField;
    WebView wvWEbPage;
    //post server data = http://posttestserver.com/data/JS_HOOKS/

    String defaultURl = "http://www.google.com";
    String techCrunchUrl="http://www.techCrunch.com";
    String jsAPIUrl = "file:///android_asset/jsApi.html";
    String youtubeUrl = "http://www.youtube.com";
    String stackoverflowUrl = "http://www.stackoverflow.com";
    private ViewGroup.LayoutParams orgLayoutParams;

    private void IntitialiseNavigation(){
        /**Activity based buttons*/
        bCrashActivity = (Button)findViewById(R.id.bCrashActivity);
        bAPIActivity = (Button)findViewById(R.id.bAPIsActivity);
        bWebViewAcitivity = (Button)findViewById(R.id.bWebViewActivity);
        bEventsActivity = (Button)findViewById(R.id.bEventsActivity);
        bNetworkActivity = (Button)findViewById(R.id.bNetworkActivity);
        bCrashActivity.setOnClickListener(this);
        bAPIActivity.setOnClickListener(this);
        bWebViewAcitivity.setOnClickListener(this);
        bEventsActivity.setOnClickListener(this);
        bNetworkActivity.setOnClickListener(this);
    }

    @SuppressLint("NewApi")
    public void initialize(){
        bYoutube = (Button)findViewById(R.id.bYoutube);
        bTechCrunch = (Button)findViewById(R.id.bTechCrunch);
        bStackOverflow = (Button)findViewById(R.id.bStackOverFlow);
        bJSApi = (Button)findViewById(R.id.bJSApi);
        bGo = (Button)findViewById(R.id.bGo);
        etWebViewUrlField = (EditText)findViewById(R.id.etWebViewUrlField);
        /*WebView Settings*/
        wvWEbPage = (WebView)findViewById(R.id.wvWebPage);
       wvWEbPage.setWebViewClient(new camaaWebViewClient());
//        wvWEbPage.setWebChromeClient(new WebChromeClient());

        wvWEbPage.getSettings().setJavaScriptEnabled(true);

        wvWEbPage.getSettings().setAllowContentAccess(true);
        wvWEbPage.getSettings().setAllowUniversalAccessFromFileURLs(true);
        wvWEbPage.setVerticalScrollBarEnabled(true);
        wvWEbPage.setHorizontalScrollBarEnabled(true);
        wvWEbPage.loadUrl(defaultURl);

        bYoutube.setOnClickListener(this);
        bTechCrunch.setOnClickListener(this);
        bStackOverflow.setOnClickListener(this);
        bJSApi.setOnClickListener(this);
        bGo.setOnClickListener(this);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);
        initialize();
        IntitialiseNavigation();
        CaMDOIntegration.registerAppFeedBack(Feedback.getBroadCastReciever());
    }

    Boolean validateUrl(String url){
        String pattern1 = "/^(http(s)?:\\/\\/.)?(www\\.)?[-a-zA-Z0-9@:%._\\+~#=]{2,256}\\.[a-z]{2,6}\\b([-a-zA-Z0-9@:%_\\+.~#?&//=]*)";
        String pattern2 = "(http:\\/\\/|https:\\/\\/)?(www.)?([a-zA-Z0-9]+).[a-zA-Z0-9]*.[a-z]{3}.?([a-z]+)?";
        Pattern p = Pattern.compile(pattern1);
        Matcher m=p.matcher(url);
        if (m.find()){
            return true;
        }
        return false;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.bYoutube:
                wvWEbPage.loadUrl(youtubeUrl);
                break;
            case R.id.bTechCrunch:
                wvWEbPage.loadUrl(techCrunchUrl);
                break;
            case R.id.bStackOverFlow:
                wvWEbPage.loadUrl(stackoverflowUrl);
                break;
            case R.id.bGo:
                loadPageFromUrl();
                break;
            case R.id.bJSApi:

                wvWEbPage.loadUrl(jsAPIUrl);
                break;
            case R.id.bCrashActivity:
                Log.d(Constants.LOG_TAG,"Starting CrashActivity from the Webactivity");
                Intent crashIntent  = new Intent(this,CrashActivity.class);
                startActivity(crashIntent);
                break;
            case R.id.bWebViewActivity:

                break;
            case R.id.bAPIsActivity:
                Log.d(Constants.LOG_TAG,"Starting APIActivity from the Webactivity");
                Intent apiIntent = new Intent(this,APISActivity.class);
                startActivity(apiIntent);
                break;
            case R.id.bNetworkActivity:
                Log.d(Constants.LOG_TAG,"Starting NetworkActivity from the Webactivity");
                Intent networkIntent = new Intent(this,NetActivity.class);
                startActivity(networkIntent);
                break;
            case R.id.bEventsActivity:
                Log.d(Constants.LOG_TAG,"Starting EventsActivity from the Webactivity");
                Intent eventIntent = new Intent(this, EventsActivity.class);
                startActivity(eventIntent);
                break;
        }
    }

    private void loadPageFromUrl() {
        String url = etWebViewUrlField.getText().toString();
        if(validateUrl(url)){
            wvWEbPage.loadUrl(url);
            Log.d(Constants.LOG_TAG,"loading page with url"+url);
        }else{
            Log.d(Constants.LOG_TAG,"Not a valid url");
        }
    }




    private class camaaWebViewClient extends WebViewClient{
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return super.shouldOverrideUrlLoading(view, url);
        }
    }
}
