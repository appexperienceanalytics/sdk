package com.maa.ca.kitchensink;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.widget.ImageView;
import android.widget.Toast;

import com.ca.integration.CaMDOIntegration;


public class LauncherActivity extends Activity {
    ImageView imBackGroundImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_launcher);
        imBackGroundImage = (ImageView) findViewById(R.id.imLauncherView);
        CaMDOIntegration.registerAppFeedBack(Feedback.getBroadCastReciever());

    }


    @Override
    protected void onResume() {
        super.onResume();
        Log.d(Constants.LOG_TAG, "Loaded LauncherActivity");
        final Context context = this;
        new Thread() {
            @Override
            public void run() {
                try {
                    Log.d(Constants.LOG_TAG,"Sleeping Launcher activity for 2 seconds");
                    Thread.sleep(2000);
                    // Do some stuff
                } catch (Exception e) {
                    e.getLocalizedMessage();
                }
                new Thread() {
                    public void run() {
                        Log.d(Constants.LOG_TAG,"Starting Crash Activity from the launcher activity");
                        Intent i = new Intent(context,CrashActivity.class);
                        startActivity(i);
                    }
                }.start();
            }
        }.start();
    }
}
