package com.maa.ca.kitchensink;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.ca.integration.CaMDOIntegration;

/**
 * Created by sharu03 on 8/13/15.
 */
public class BaseActivity extends ActionBarActivity {

    public static String TAG = "BaseActivity";
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.global,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.appInfoMenu){
            Intent intent = new Intent(this, AppInfoActivity.class);
            startActivity(intent);
        }else  if(item.getItemId() == R.id.action_settings){
            return true;
        }else  if(item.getItemId() == R.id.action_forceUpload){
            try {
                Log.i(TAG,"calling uploadEvents");
                CaMDOIntegration.uploadEvents();
                Log.i(TAG,"done calling uploadEvents");
            } catch (Exception e) {
                Log.e(TAG,"Error in uploadEvents: "+e);
            }
            return true;
        }else if(item.getItemId() == R.id.action_viewloaded){
            try {
                Log.i(TAG,"calling viewloaded");
                CaMDOIntegration.viewLoaded("test",10);
                Log.i(TAG,"done calling viewloaded");
            } catch (Exception e) {
                Log.e(TAG,"Error in viewloaded: "+e);
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
