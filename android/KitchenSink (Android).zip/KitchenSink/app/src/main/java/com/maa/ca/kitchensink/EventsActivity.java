package com.maa.ca.kitchensink;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

import com.ca.integration.CaMDOIntegration;

import java.util.Random;


public class EventsActivity extends BaseActivity implements View.OnClickListener {

    Button bCrashActivity,bNetworkActivity,bAPIActivity,bWebViewAcitivity,bEventsActivity,bStartProgressBarButton,bStopProgressBarButton,bEnterPrivateZone, bExitPrivateZone;
    ProgressBar pbSampleBar;

    int i = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);
        Intitalise();
        IntitialiseNavigation();
        CaMDOIntegration.registerAppFeedBack(Feedback.getBroadCastReciever());

    }


    @Override
    protected void onResume() {
        super.onResume();
        CaMDOIntegration.addSessionEvent(CaMDOIntegration.CAMAA_STRING,"Custom Event Name "+i++, "Custom Event Value "+i++ );
        CaMDOIntegration.setSessionInfo(CaMDOIntegration.CAMAA_STRING ,"Header Event Name "+i++, "Header Event Value "+i++);
//        makeDummyProfileCall();
    }



    public  int randInt(int min, int max) {

        // NOTE: Usually this should be a field rather than a method
        // variable so that it is not re-seeded every call.
        Random rand = new Random();

        // nextInt is normally exclusive of the top value,
        // so add 1 to make it inclusive
        int randomNum = rand.nextInt((max - min) + 1) + min;

        return randomNum;
    }

    @Override
    protected void onPause() {
        super.onPause();
       // CaMDOIntegration.setSessionInfo("Header Customer Device NAme"+i++, "Header Customer Device Val "+i++,CaMDOIntegration.CAMAA_CUSTOMER_ID );

    }

    private void IntitialiseNavigation(){
        /**Activity based buttons*/
        bCrashActivity = (Button)findViewById(R.id.bCrashActivity);
        bAPIActivity = (Button)findViewById(R.id.bAPIsActivity);
        bWebViewAcitivity = (Button)findViewById(R.id.bWebViewActivity);
        bEventsActivity = (Button)findViewById(R.id.bEventsActivity);
        bNetworkActivity = (Button)findViewById(R.id.bNetworkActivity);
        bCrashActivity.setOnClickListener(this);
        bAPIActivity.setOnClickListener(this);
        bWebViewAcitivity.setOnClickListener(this);
        bEventsActivity.setOnClickListener(this);
        bNetworkActivity.setOnClickListener(this);
    }
    private void Intitalise() {
        bStartProgressBarButton = (Button)findViewById(R.id.bStartProgressBar);
        bStopProgressBarButton = (Button)findViewById(R.id.bStopProgressBar);
        pbSampleBar = (ProgressBar)findViewById(R.id.pbsamplebar);
        bEnterPrivateZone = (Button)findViewById(R.id.bEnterPrivateZone);
        bExitPrivateZone = (Button)findViewById(R.id.bExitPrivateZone);
        bEnterPrivateZone.setOnClickListener(this);
        bExitPrivateZone.setOnClickListener(this);
        bStartProgressBarButton.setOnClickListener(this);
        bStopProgressBarButton.setOnClickListener(this);
        pbSampleBar.setVisibility(View.GONE);
    }



    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.bCrashActivity:
                Log.d(Constants.LOG_TAG, "Starting CrashActivity from the Events Activity");
                Intent crashIntent  = new Intent(this,CrashActivity.class);
                startActivity(crashIntent);
                break;
            case R.id.bWebViewActivity:
                Log.d(Constants.LOG_TAG,"Starting WebViewActivity from the EventsActivity");
                Intent webViewIntent = new Intent(this,WebViewActivity.class);
                startActivity(webViewIntent);
                break;
            case R.id.bAPIsActivity:
                Log.d(Constants.LOG_TAG,"Starting APIActivity from the EventsActivity");
                Intent apiIntent = new Intent(this,APISActivity.class);
                startActivity(apiIntent);
                break;
            case R.id.bNetworkActivity:
                Log.d(Constants.LOG_TAG,"Starting NetworkActivity from the EventsActivity");
                Intent networkIntent = new Intent(this,NetActivity.class);
                startActivity(networkIntent);
                break;
            case R.id.bEventsActivity:
                break;

            case R.id.bStartProgressBar:
                pbSampleBar.setVisibility(View.VISIBLE);
                break;
            case R.id.bStopProgressBar:
                pbSampleBar.setVisibility(View.GONE);
                break;

            case R.id.bEnterPrivateZone:
                CaMDOIntegration.enterPrivateZone();
                break;
            case R.id.bExitPrivateZone:
                CaMDOIntegration.exitPrivateZone();
                break;

        }
    }
}
