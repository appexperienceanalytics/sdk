package com.maa.ca.kitchensink;

import android.app.Application;
import android.content.res.Configuration;
import android.util.Log;

import com.facebook.stetho.Stetho;

/**
 * Created by kanch06 on 5/28/15.
 */
public class KitchenSinkApp extends Application {


    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("MYAPPLICATIONTAG", "KitchenSinkApp.onCreate");
        Stetho.initialize(
                Stetho.newInitializerBuilder(this)
                        .enableDumpapp(Stetho.defaultDumperPluginsProvider(this))
                        .enableWebKitInspector(Stetho.defaultInspectorModulesProvider(this))
                        .build());
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        Log.d("KitchenSinkApp", "KitchenSinkApp.onLowMemory");

    }

    @Override
    public void onTerminate() {
        Log.d("KitchenSinkApp", "KitchenSinkApp.onTerminate");
        super.onTerminate();


    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        Log.d("KitchenSinkApp", "KitchenSinkApp.onTrimMemory(level)");

    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Log.d("KitchenSinkApp", "KitchenSinkApp.onConfigurationChanged(config)");

    }

}
