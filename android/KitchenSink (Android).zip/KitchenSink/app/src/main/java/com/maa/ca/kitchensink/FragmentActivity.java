package com.maa.ca.kitchensink;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by sugsh04 on 5/25/16.
 */
public class FragmentActivity extends BaseActivity{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment_layout);
    }

}
