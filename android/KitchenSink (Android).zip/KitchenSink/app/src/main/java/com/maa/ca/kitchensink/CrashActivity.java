package com.maa.ca.kitchensink;

import android.app.Fragment;
import android.app.usage.UsageEvents;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.ca.integration.CaMDOIntegration;
import com.maa.ca.kitchensink.ToolTip.ToolTip;
import com.maa.ca.kitchensink.ToolTip.ToolTipRelativeLayout;
import com.maa.ca.kitchensink.ToolTip.ToolTipView;

import java.util.UnknownFormatConversionException;
import android.os.Handler;
import android.widget.Toast;

public class CrashActivity extends BaseActivity implements View.OnClickListener,ToolTipView.OnToolTipViewClickedListener{


    Button bUncaughtException, bSegmentationFault,bStackOverflow,bArrayOutOfIndex,bMethodA,bMethodB,bCrashActivity,bNetworkActivity,bAPIActivity,bWebViewAcitivity,bEventsActivity, bFragmentActivity;
    ImageButton bInfoCrashes,bInfoCrashSymbolication,bInfoInAppFeedback;
    private ToolTipView mOrangeToolTipView;
    private ToolTipRelativeLayout mToolTipFrameLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crash);
        UIInitialize();
        IntitialiseNavigation();
//        CaMDOIntegration.registerAppFeedBack(mMessageReceiver);

    }


    private void IntitialiseNavigation(){
        /**Activity based buttons*/
        Log.d(Constants.LOG_TAG,"Initializing the Navigation for Crash Activity");
        bCrashActivity = (Button)findViewById(R.id.bCrashActivity);
        bAPIActivity = (Button)findViewById(R.id.bAPIsActivity);
        bWebViewAcitivity = (Button)findViewById(R.id.bWebViewActivity);
        bEventsActivity = (Button)findViewById(R.id.bEventsActivity);
        bNetworkActivity = (Button)findViewById(R.id.bNetworkActivity);
        bFragmentActivity = (Button)findViewById(R.id.bFragmentActivity);
        bCrashActivity.setOnClickListener(this);
        bAPIActivity.setOnClickListener(this);
        bWebViewAcitivity.setOnClickListener(this);
        bEventsActivity.setOnClickListener(this);
        bNetworkActivity.setOnClickListener(this);
        bFragmentActivity.setOnClickListener(this);

    }
    private void UIInitialize(){
        Log.d(Constants.LOG_TAG,"Initializing UI Elements for Crash Activity");
        bSegmentationFault = (Button)findViewById(R.id.bSegmentationFault);
        bStackOverflow = (Button)findViewById(R.id.bStackOverFlowError);
        bUncaughtException = (Button)findViewById(R.id.bUncaughtException);
        bArrayOutOfIndex = (Button)findViewById(R.id.bArrayOutOfIndex);
        bMethodA = (Button)findViewById(R.id.bMethodA);
        bMethodB = (Button)findViewById(R.id.bMethodB);
        bInfoCrashes = (ImageButton)findViewById(R.id.ibInfoCrashes);
        bInfoCrashSymbolication = (ImageButton)findViewById(R.id.ibInfoCrashesSymbolication);
        bInfoInAppFeedback = (ImageButton)findViewById(R.id.ibInfoInAppFeedback);
        mToolTipFrameLayout = (ToolTipRelativeLayout)findViewById(R.id.fl_crash_tooltipframelayout);

        bSegmentationFault.setOnClickListener(this);
        bStackOverflow.setOnClickListener(this);
        bUncaughtException.setOnClickListener(this);
        bArrayOutOfIndex.setOnClickListener(this);
        bMethodA.setOnClickListener(this);
        bMethodB.setOnClickListener(this);
        bInfoCrashes.setOnClickListener(this);
        bInfoCrashSymbolication.setOnClickListener(this);
        bInfoInAppFeedback.setOnClickListener(this);
    }


    @Override
    public void onClick(View v){
        switch (v.getId()){
            case R.id.bUncaughtException:
                createUnCaughtException();
                break;
            case R.id.bArrayOutOfIndex:
                createArrayOutOfIndex();
                break;
            case R.id.bSegmentationFault:
                createSegmentationFault();
                break;
            case R.id.bStackOverFlowError:
                createStackOverflow();
                break;
            case R.id.bMethodA:
                createMethodA();
                break;
            case R.id.bMethodB:
                createMethodB();
                break;

            case R.id.ibInfoCrashes:
                Toast.makeText(getApplicationContext(),"Simulate the Crashes by clicking \n" +
                        "on the buttons in crash section" , Toast.LENGTH_LONG).show();
                break;
            case R.id.ibInfoCrashesSymbolication:
                Toast.makeText(getApplicationContext(), "Clicking on the buttons Method A / B will generate crashes. \n" +
                        "If the user has uploaded the .dsym file to the mdo console then user can visualise in which\n" +
                        " method the crash has occurred along with the symbolicated stack trace", Toast.LENGTH_LONG).show();
                break;
            case R.id.ibInfoInAppFeedback:
                Toast.makeText(getApplicationContext(), "The SDK provides a mechanism to relay info that 'previous session crashed' to the App Developer.\n" +
                        " This information can be used to provide mechanism to collect information from user", Toast.LENGTH_LONG).show();
                break;
            case R.id.bCrashActivity:
                break;
            case R.id.bWebViewActivity:
                Intent webViewIntent = new Intent(this,WebViewActivity.class);
                startActivity(webViewIntent);
                Log.d(Constants.LOG_TAG,"Opening WebView Activity from CrashActivity");
                break;
            case R.id.bAPIsActivity:
                Intent apiIntent = new Intent(this,APISActivity.class);
                startActivity(apiIntent);
                Log.d(Constants.LOG_TAG,"Opening APIS Activity from CrashActivity");
                break;
            case R.id.bNetworkActivity:
                Intent networkIntent = new Intent(this,NetActivity.class);
                startActivity(networkIntent);
                Log.d(Constants.LOG_TAG,"Opening Network Activity from CrashActivity");
                break;
            case R.id.bEventsActivity:
                Intent eventIntent = new Intent(this, EventsActivity.class);
                startActivity(eventIntent);
                Log.d(Constants.LOG_TAG,"Opening Events Activity from CrashActivity");
                break;
            case R.id.bFragmentActivity:
                {
                    Intent fragIntent = new Intent(this, FragmentActivity.class);
                    startActivity(fragIntent);
                    Log.d(Constants.LOG_TAG,"Opening Fragment Activity");
                    break;
                }

            default:
               break;
        }
    }


    /** Crash creating methods */
    private void createUnCaughtException()throws UnknownError{
        Log.d(Constants.LOG_TAG,"Creating UnCaught Exception");
        throw new UnknownError();

    }

    private void createArrayOutOfIndex()throws ArrayIndexOutOfBoundsException{
        Log.d(Constants.LOG_TAG,"Creating Array out of index error");
        throw new ArrayIndexOutOfBoundsException();
    }
    private void createSegmentationFault() throws IllegalAccessError{
       Log.d(Constants.LOG_TAG,"Creating Segmentation Fault");
        throw new IllegalAccessError();

    }
    private void createStackOverflow() throws StackOverflowError{
        Log.d(Constants.LOG_TAG,"Creating StackOverFlow");
        throw new StackOverflowError();
    }

    private void createMethodA()throws ArrayIndexOutOfBoundsException{
        Log.d(Constants.LOG_TAG,"Create crash in the Method A");
        throw new ArrayIndexOutOfBoundsException();
    }

    private void createMethodB()throws IllegalAccessError{
        Log.d(Constants.LOG_TAG,"Create crash in the Method B");
        throw new IllegalAccessError();
    }


    private void addInfo(int id,String message){
        ToolTip toolTip = new ToolTip()
                .withText(message)
                .withColor(getResources().getColor(R.color.holo_orange));
        mOrangeToolTipView = mToolTipFrameLayout.showToolTipForView(toolTip, findViewById(id));
        mOrangeToolTipView.setOnToolTipViewClickedListener(this);
    }



    @Override
    public void onToolTipViewClicked(ToolTipView toolTipView) {
        if (mOrangeToolTipView == toolTipView) {
            mOrangeToolTipView = null;
        }
    }
}
