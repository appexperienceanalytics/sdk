package com.maa.ca.kitchensink;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Handler;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.ca.integration.CaMDOCallback;
import com.ca.integration.CaMDOIntegration;
import com.maa.ca.kitchensink.ToolTip.ToolTip;
import com.maa.ca.kitchensink.ToolTip.ToolTipRelativeLayout;
import com.maa.ca.kitchensink.ToolTip.ToolTipView;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;


public class APISActivity extends BaseActivity implements View.OnClickListener,ToolTipView.OnToolTipViewClickedListener {

    Button bSetCustomerId, bSetCustomerLocation, bAddSessionEvent, bAddSessionInfo, bEnableSDK, bDisableSDK, bStartApplicationTransaction, bStopApplicationTransaction, bLogin, bCrashActivity, bNetworkActivity, bAPIActivity, bWebViewAcitivity, bEventsActivity, bStopSession, bStartSession;
    EditText etCustomerID, etCustomerLocationCountry, etCustomerLocationZipCode, etSessionEventDataType, etSessionEventValue, etSessionEventName, etSessionInfoValue, etSessionInfoName, etSessionInfoDataType, etApplicationTransaction, etUserName, etPassword;
    ImageButton ibCustomerIDInfo, ibCustomerLocationInfo, ibSessionEvent, ibSessionInfo, ibStartApplicationTransaction;
    private ToolTipView mOrangeToolTipView;
    private ToolTipRelativeLayout mToolTipFrameLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apis);
        Initialize();
        IntitialiseNavigation();
        CaMDOIntegration.registerAppFeedBack(Feedback.getBroadCastReciever());

    }

    private void IntitialiseNavigation() {
        /**Activity based buttons*/
        bCrashActivity = (Button) findViewById(R.id.bCrashActivity);
        bAPIActivity = (Button) findViewById(R.id.bAPIsActivity);
        bWebViewAcitivity = (Button) findViewById(R.id.bWebViewActivity);
        bEventsActivity = (Button) findViewById(R.id.bEventsActivity);
        bNetworkActivity = (Button) findViewById(R.id.bNetworkActivity);
        bCrashActivity.setOnClickListener(this);
        bAPIActivity.setOnClickListener(this);
        bWebViewAcitivity.setOnClickListener(this);
        bEventsActivity.setOnClickListener(this);
        bNetworkActivity.setOnClickListener(this);
    }

    private void Initialize() {
        bSetCustomerId = (Button) findViewById(R.id.bSetCustomerId);
        bSetCustomerLocation = (Button) findViewById(R.id.bSetCustomerLocation);
        bAddSessionEvent = (Button) findViewById(R.id.bAddSessionEvent);
        bAddSessionInfo = (Button) findViewById(R.id.bAddSessionInfo);
        bEnableSDK = (Button) findViewById(R.id.bEnableSDK);
        bDisableSDK = (Button) findViewById(R.id.bDisEnableSDK);
        bStartApplicationTransaction = (Button) findViewById(R.id.bStartTransactionApplication);
        bStopApplicationTransaction = (Button) findViewById(R.id.bEndTransaction);
        bLogin = (Button) findViewById(R.id.bLogin);
        bStopSession = (Button) findViewById(R.id.bStopSession);
        bStartSession = (Button) findViewById(R.id.bStartSession);

        ibCustomerIDInfo = (ImageButton) findViewById(R.id.ibCustomerIDInfo);
        ibCustomerLocationInfo = (ImageButton) findViewById(R.id.ibCustomerIDInfo);
        ibSessionEvent = (ImageButton) findViewById(R.id.ibCustomerIDInfo);
        ibSessionInfo = (ImageButton) findViewById(R.id.ibCustomerIDInfo);
        ibStartApplicationTransaction = (ImageButton) findViewById(R.id.ibCustomerIDInfo);

        etCustomerID = (EditText) findViewById(R.id.etCustomerID);
        etCustomerLocationCountry = (EditText) findViewById(R.id.etCustomerLocationCountry);
        etCustomerLocationZipCode = (EditText) findViewById(R.id.etCustomerLocationZipCode);
        etSessionEventDataType = (EditText) findViewById(R.id.etSessionEventDatatype);
        etSessionEventDataType.setText(CaMDOIntegration.CAMAA_STRING);
        etSessionEventValue = (EditText) findViewById(R.id.etSessionEventValue);
        etSessionEventName = (EditText) findViewById(R.id.etSessionEventName);
        etSessionInfoValue = (EditText) findViewById(R.id.etSessionInfoValue);
        etSessionInfoName = (EditText) findViewById(R.id.etSessionInfoName);
        etSessionInfoDataType = (EditText) findViewById(R.id.etSessionInfoDatatype);
        etSessionInfoDataType.setText(CaMDOIntegration.CAMAA_STRING);
        etUserName = (EditText)findViewById(R.id.etUsername);
        etPassword = (EditText) findViewById(R.id.etPassword);
        etApplicationTransaction = (EditText)findViewById(R.id.etApplicationTransactionName);

        bSetCustomerId.setOnClickListener(this);
        bSetCustomerLocation.setOnClickListener(this);
        bAddSessionEvent.setOnClickListener(this);
        bAddSessionInfo.setOnClickListener(this);
        bEnableSDK.setOnClickListener(this);
        bDisableSDK.setOnClickListener(this);
        bStartApplicationTransaction.setOnClickListener(this);
        bStopApplicationTransaction.setOnClickListener(this);
        bLogin.setOnClickListener(this);
        bStopSession.setOnClickListener(this);
        bStartSession.setOnClickListener(this);



        ibCustomerIDInfo.setOnClickListener(this);
        ibCustomerLocationInfo.setOnClickListener(this);
        ibSessionEvent.setOnClickListener(this);
        ibSessionInfo.setOnClickListener(this);
        ibStartApplicationTransaction.setOnClickListener(this);
        mToolTipFrameLayout = (ToolTipRelativeLayout)findViewById(R.id.fl_crash_tooltipframelayout);

    }


    private void addInfo(int id,String message){
        ToolTip toolTip = new ToolTip()
                .withText(message)
                .withColor(getResources().getColor(R.color.holo_orange));
        mOrangeToolTipView = mToolTipFrameLayout.showToolTipForView(toolTip, findViewById(id));
        mOrangeToolTipView.setOnToolTipViewClickedListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bSetCustomerId:
                String customerId = etCustomerID.getText().toString();
                if(customerId!=null){
                    CaMDOIntegration.setSessionInfo(CaMDOIntegration.CAMAA_CUSTOMER_ID,"KSName",customerId);
//                    CaMDOIntegration.setCustomerId(customerId);
                    Location location = new Location("user");
                    location.setLongitude(79.9865);
                    location.setLatitude(14.4426);
                    CaMDOIntegration.setCustomerLocation(location);
                    Handler handler = new Handler();
                    CaMDOCallback cb = new CaMDOCallback(handler) {
                        @Override
                        public void onError(int errorCode, Exception exception) {
                            Log.d("abc","asdasd");
                        }

                        @Override
                        public void onSuccess(Bundle data) {
                            Log.d("abc","asdasd");
                        }
                    };
                    CaMDOIntegration.sendScreenShot("Abc",12,cb);
                }
                break;
            case R.id.bSetCustomerLocation:
                String customerCountry = etCustomerLocationCountry.getText().toString();
                String customerZipCode = etCustomerLocationZipCode.getText().toString();
                if(customerCountry!=null && customerZipCode!=null){
                    Map<String,String> map = new HashMap<String,String>();
                    map.put(CaMDOIntegration.CAMAA_HEADER_ZIPCODE,"95051");
                    map.put(CaMDOIntegration.CAMAA_HEADER_COUNTRY,"USA");
                    CaMDOIntegration.setCustomerLocation(map);
                }
                break;
            case R.id.bAddSessionEvent:
                String sessionEventValue = etSessionEventValue.getText().toString();
                String sessionEventType = etSessionEventDataType.getText().toString();
                String sessionEventName=etSessionEventName.getText().toString();
                Map<String,String> attributeEvents = new HashMap<String,String>();
                attributeEvents.put("cseAttribute1","cseAttribute1Value");
                attributeEvents.put("cseAttribute2","cseAttribute2Value");
                attributeEvents.put("cseAttribute3","cseAttribute3Value");
                attributeEvents.put("cseAttribute4","cseAttribute4Value");
                CaMDOIntegration.logTextMetric(sessionEventName,sessionEventValue ,attributeEvents,null);
                CaMDOIntegration.logNumericMetric(sessionEventName,99.99 ,attributeEvents,null);
                CaMDOIntegration.logNetworkEvent("http://ck.com",33,33,33,200,null);

//                if(sessionEventName!=null && sessionEventType!=null && sessionEventValue!=null){
//                    CaMDOIntegration.addSessionEvent(sessionEventType,sessionEventName,sessionEventValue);
//                    CaMDOIntegration.addSessionEvent(sessionEventType,sessionEventName+"-withMap",sessionEventValue+"-withMap",attributeEvents);
//                }
                break;
            case R.id.bAddSessionInfo:
                String sessionInfoValue = etSessionInfoValue.getText().toString();
                String sesionInfoType = etSessionInfoDataType.getText().toString();
                String sessionInfoName = etSessionInfoName.getText().toString();
                if(sesionInfoType!=null && sessionInfoName!=null && sessionInfoValue!=null){
                    CaMDOIntegration.setSessionInfo(sesionInfoType,sessionInfoName,sessionInfoValue);


                }
                break;
            case R.id.bEnableSDK:
                    CaMDOIntegration.enableSDK();
                break;
            case R.id.bDisEnableSDK:
                CaMDOIntegration.disableSDK();
                break;
            case R.id.bStartTransactionApplication:
                String applicationTransactionName = etApplicationTransaction.getText().toString();
//                if(applicationTransactionName!=null){
                    CaMDOIntegration.startApplicationTransaction("Txnck","ServiceCK",null);
//                }
                break;
            case R.id.bLogin:
                Intent loginIntent = new Intent(this,TransactionActivity.class);
                startActivity(loginIntent);
                break;
           case R.id.bEndTransaction:
               String applicationTransactionName1 = etApplicationTransaction.getText().toString();
//               if(applicationTransactionName1!=null) {
//                   CaMDOIntegration.stopApplicationTransaction(applicationTransactionName1,getApplicationName(this));
                   CaMDOIntegration.stopApplicationTransaction("Txnck","ServiceCK","FailureCK");
//               }
                break;
            case R.id.bStopSession:{
                CaMDOIntegration.stopCurrentSession();
            }
            break;
            case R.id.bStartSession:{
                CaMDOIntegration.startNewSession();
            }
            break;

            case R.id.ibCustomerIDInfo:
                Toast.makeText(getApplicationContext(),"CAMobileDevOps.setSessionInfo(CAMobileDevOps.CAMAA_CUSTOMER_ID, “phone_number\", \"4085551212”);",Toast.LENGTH_LONG);
                break;
            case R.id.ibCustomerLocationInfo:
                Toast.makeText(getApplicationContext(),"Map<String, String > customerLocMap = new HashMap<String, String>();\n" +
                        "customerLocMap.put(CAMobileDevOps.CAMAA_HEADER_ZIPCODE, \"94538\");\n" +
                        "customerLocMap.put(CAMobileDevOps.CAMAA_HEADERCOUNTRY_CODE, \"US\");\n" +
                        "CAMobileDevOps.setCustomerLocation(customerLocMap)" , Toast.LENGTH_LONG).show();
                break;
            case R.id.ibSessionEvent:
                Toast.makeText(getApplicationContext(),"CAMobileDevOps.addSessionEvent(“Revenue\", “APAC, “100k\");",Toast.LENGTH_LONG);
                break;
            case R.id.ibSessionInfo:
                Toast.makeText(getApplicationContext(),"CAMobileDevOps.setSessionInfo(CAMobileDevOps.CAMAA_CUSTOMER_ID, “phone_number\", \"4085551212”);",Toast.LENGTH_LONG);
                break;
            case R.id.ibStartApplicationTransactionInfo:
                Toast.makeText(getApplicationContext(),"CAMobileDevOps.startApplicationTransaction(\"\"Shop - Add Item To Cart\");" +
                        "start Application Transaction by giving some transaction name, login and generate some events and end application transaction",Toast.LENGTH_LONG);
                break;
            case R.id.bCrashActivity:
                Intent crashIntent = new Intent(this, CrashActivity.class);
                startActivity(crashIntent);
                break;
            case R.id.bWebViewActivity:
                Intent webViewIntent = new Intent(this, WebViewActivity.class);
                startActivity(webViewIntent);
                break;
            case R.id.bAPIsActivity:
                break;
            case R.id.bNetworkActivity:
                Intent networkIntent = new Intent(this, NetActivity.class);
                startActivity(networkIntent);
                break;
            case R.id.bEventsActivity:
                Intent eventIntent = new Intent(this, EventsActivity.class);
                startActivity(eventIntent);
                break;
            default:
                break;
        }
    }

    protected static String getApplicationName(Context ctx) {
        final PackageManager pm = ctx.getPackageManager();
        ApplicationInfo ai;
        try {
            ai = pm.getApplicationInfo(ctx.getPackageName(), 0);
        } catch (final PackageManager.NameNotFoundException e) {
            ai = null;
        }
        return (String) (ai != null ? pm.getApplicationLabel(ai) : "unknown");

    }

    @Override
    public void onToolTipViewClicked(ToolTipView toolTipView) {
        if (mOrangeToolTipView == toolTipView) {
            mOrangeToolTipView = null;
        }
    }
}
